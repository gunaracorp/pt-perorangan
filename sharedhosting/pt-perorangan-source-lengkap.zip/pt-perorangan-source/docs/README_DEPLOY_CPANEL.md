# README DEPLOY CPANEL — Panduan Instalasi Tanpa Terminal

> Untuk pemula total. Tidak ada satu pun perintah terminal.
> Estimasi waktu: 15–20 menit. Prasyarat: akun hosting cPanel aktif + domain.

---

## LANGKAH 0 — Cek Dukungan PHP 8.5 (WAJIB, jangan dilewati)

1. Login cPanel.
2. Cari menu **Select PHP Version** (atau **MultiPHP Manager**).
3. Buka daftar versi → cari **8.5** (mis. 8.5.10 atau lebih baru).
4. **Keputusan:**
   - Ada **PHP 8.5** → pilih versi patch TERTINGGI (mis. 8.5.10) → lanjut Langkah 1.
   - TIDAK ada PHP 8.5 → **STOP**. Ini BLOCKER:
     - Buka tiket ke penyedia hosting: *"Mohon aktifkan PHP 8.5 (atau 8.5.x terbaru) di paket saya."*
     - Jika provider tidak mampu → pilih provider lain yang menyediakan PHP 8.5.
     - **JANGAN** menurunkan target ke 8.4/8.3 — proyek ini memakai fitur PHP 8.5 dan aturan proyek melarang penurunan versi secara diam-diam.
5. Masih di Select PHP Version → tab **Extensions** → pastikan AKTIF:
   `pdo`, `pdo_mysql`, `mbstring`, `json`, `fileinfo`, `openssl`, `gd`, `curl`, `zip`.
   (Centang yang belum aktif → Save.)

**Hasil yang diharapkan:** cPanel menampilkan PHP 8.5.x aktif untuk domain Anda.
**Cara menguji:** setelah situs jalan, buka `domain.com/install.php` — wizard menampilkan
✓ PHP versi + ✓ semua ekstensi.

---

## LANGKAH 1 — Siapkan Database

1. cPanel → **MySQL Databases**.
2. Kolom "Create a New Database" → nama: `ptperorangan` → **Create Database**.
   (Nama lengkapnya nanti jadi `usernamecpanel_ptperorangan` — catat.)
3. Scroll ke "MySQL Users" → buat user: `adminpt` + password KUAT → **Create User**.
4. Bagian "Add User To Database" → pilih user + database → **Add** → centang **ALL PRIVILEGES** → **Make Changes**.
5. Catat 3 hal: nama database lengkap, user lengkap, password.

## LANGKAH 2 — Unggah & Ekstrak Aplikasi

1. Unduh `pt-perorangan-deploy.zip` (paket yang disiapkan untuk Anda).
2. cPanel → **File Manager** → masuk ke `public_html/`.
3. **Upload** → unggah ZIP → klik kanan → **Extract**.
4. Klik kanan folder hasil ekstrak → **Rename** → `pt-perorangan` (bersih).

**Struktur setelah ekstrak (verifikasi):**
```
public_html/pt-perorangan/
├── public/   ← folder PENTING (ini document root)
├── app/      ├── themes/   ├── config/   ├── storage/
├── content/  ├── database/ ├── docs/     └── .htaccess
```

## LANGKAH 3 — Pilih Salah Satu Penempatan (Pilihan A disarankan)

### PILIHAN A (disarankan): subdomain/folder sebagai document root
1. cPanel → **Domains** (atau **Subdomains**) → buat `pt.domainanda.com`
   → arahkan **Document Root** ke: `public_html/pt-perorangan/public`
2. Selesai — folder `public/` menjadi akar web; folder privat (app/config/storage)
   TIDAK bisa diakses browser sama sekali. Keamanan paling bersih.

### PILIHAN B: situs utama di domain utama tanpa subdomain
Jika Anda ingin situs langsung di `domainanda.com` dan tidak bisa mengubah document root:
1. Biarkan semua di `public_html/pt-perorangan/`.
2. Pastikan `.htaccess` ROOT (sudah disertakan di dalam folder proyek) aktif —
   ia meneruskan pengunjung ke `public/` otomatis dan memblokir folder internal.
3. Uji: buka `domainanda.com/pt-perorangan/` → beranda tampil.
4. **Uji proteksi:** buka `domainanda.com/pt-perorangan/config/config.php` → harus **403/404** (bukan isi file).
   Bila isinya terbaca → HENTIKAN, hubungi support (mod_rewrite tidak aktif) — JANGAN isi data sensitif dulu.

## LANGKAH 4 — SSL (HTTPS)

1. cPanel → **SSL/TLS Status** → centang domain → **Run AutoSSL**.
2. Tunggu status berganti ✓ (5–30 menit).
3. Setelah HTTPS aktif: buka `public/.htaccess` → hapus tanda `#` pada 2 baris rewrite
   HTTPS yang disediakan → simpan → semua pengunjung diarahkan ke HTTPS.

## LANGKAH 5 — Jalankan Installer Web (3 menit)

1. Buka `https://alamat-situs-anda/` → otomatis diarahkan ke **/install.php**.
   (Jika tidak: buka manual `https://alamat-situs-anda/install.php`.)
2. **Langkah 1** wizard: pastikan semua ✓ (PHP 8.5, ekstensi, folder writable).
3. **Langkah 2 — Database:**
   - Driver: `MySQL`
   - Host: `localhost`
   - Port: `3306`
   - Nama database / user / password: dari Langkah 1 (nama lengkap dengan prefix cPanel)
   - URL situs: `https://alamat-situs-anda` (biarkan kosong juga bisa — terdeteksi otomatis)
4. **Langkah 3 — Akun Admin:** nama, email (untuk login), password ≥12 karakter → **Jalankan Instalasi**.
5. **Hasil yang diharapkan:** layar "SELESAI ✓" dengan 3 langkah berikutnya.

## LANGKAH 6 — Finalisasi Keamanan (5 menit, WAJIB)

1. File Manager → masuk `pt-perorangan/public/` → **HAPUS file `install.php`** (sudah self-lock, tapi menghapusnya lebih rapi).
2. Pastikan `config/config.php` tidak pernah dibagikan ke siapa pun.
3. Buka dashboard: `https://alamat-situs-anda/admin` → login →
   **Pengaturan** → lengkapi WhatsApp, email, alamat → Simpan.
4. **Tema** → sesuaikan warna/font → Simpan.
5. **Media** → unggah logo → **Pengaturan** → tempel path logo.

## LANGKAH 7 — Uji Acceptance (checklist 10 menit)

| Uji | Cara | Hasil yang benar |
|---|---|---|
| Beranda | Buka `/` | Hero gradient futuristik + navigasi |
| Layanan | `/layanan` + klik satu layanan | Kartu fakta (biaya resmi vs jasa) tampil |
| FAQ | `/faq` | Accordion membuka-tutup |
| Kontak | `/kontak` → kirim pesan | Toast sukses; muncul di **Pesan** admin |
| Sitemap | `/sitemap.xml` | XML indeks + 3 sub-sitemap |
| Robots | `/robots.txt` | Disallow /admin & /cari + baris Sitemap |
| 404 asli | `/halaman-ngasal` | Halaman 404 bertema (bukan halaman putih) |
| Login salah 5× | — | Pesan "terlalu banyak percobaan" (proteksi bekerja) |
| Editor | Buat halaman draft → pratinjau 📱 | Pratinjau berubah ukuran |
| Mobile | Buka situs di ponsel | Menu ☰; hero responsif |

## LANGKAH 8 — Setup Rutin

**Backup (sekali sebulan):**
- File Manager → pilih folder proyek → Compress → unduh.
- phpMyAdmin → database → Export → unduh SQL.

**Update konten:** semuanya dari `/admin` (lihat `docs/TUTORIAL_EDITOR_VISUAL.md`).

**Baca log bila ada masalah:** File Manager → `storage/logs/error-TANGGAL.log`
(jangan bagikan isinya ke publik — berikan ke developer bila perlu bantuan).

---

## Troubleshooting Cepat

| Gejala | Sebab | Solusi |
|---|---|---|
| "Koneksi database gagal" | Nama/user/pass salah (lupa prefix cPanel) | Ulangi Langkah 1 & isi nama LENGKAP |
| 403 di semua halaman | mod_rewrite tidak aktif / .htaccess terhapus | Tiket ke provider: "aktifkan mod_rewrite" |
| Install bilang "PHP < 8.5" | Provider belum aktifkan | Kembali ke Langkah 0 — jangan paksa |
| Halaman tampil tanpa CSS | Document root tidak mengarah ke `public/` | Periksa Langkah 3 |
| Email form tidak masuk | Fitur "contact_store" | Pesan tersimpan di **Pesan** admin (tanpa server email) — by design |
| Perlu rollback versi | Setelah update besar | Pulihkan ZIP + SQL backup (uji dulu di subfolder) |

## Yang TIDAK Bisa Dilakukan (batas provider — cara alternatifnya)

| Kebutuhan | Kenapa terhalang di shared hosting | Alternatif realistis |
|---|---|---|
| Cron menit-per-menit | Provider biasanya batasi cron | Gunakan kontrol manual di dashboard; sitemap sudah otomatis |
| Redis/object cache | Tidak tersedia | File cache bawaan (aktif by default) |
| Server email andal | Port 25 sering diblokir | Pesan kontak tersimpan ke database (sudah default) |
| SSH/terminal | Paket umum tanpa SSH | Semua langkah di dokumen ini via cPanel GUI |
