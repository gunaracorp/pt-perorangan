# ANIMATION INVENTORY — Inventaris & Peta Animasi

> Sesuai Bagian 4.1 Master Prompt: tidak ada animasi yang dihapus diam-diam.
> Status kejujuran penting: **repository sumber TERHALANG (404/privat)** sehingga
> animasi sumber TIDAK BISA diinventarisasi sampai ZIP repo diberikan.
> Dokumen ini memetakan animasi yang ADA di implementasi PHP ini + template audit
> yang siap diisi begitu kode sumber tersedia.

---

## A. Status Paritas terhadap Repository Sumber

| No | Halaman/Komponen repo sumber | Animasi sumber | Status | Keterangan |
|----|------------------------------|----------------|--------|------------|
| S1 | *(seluruh repo)* | *(tidak diketahui)* | **TERHALANG** | Repo `pusatperizinan/pt-perorangan` = 404/privat (GitHub API, dicek 2026-10-26). Tidak boleh mengarang. Ketika ZIP diberikan, tambahkan baris per animasi di tabel B2. |

**Komitmen:** begitu repository/ZIP diberikan, setiap animasi sumber akan dicatat di
tabel B2 dengan kolom pemicu, durasi/easing, perilaku sumber, implementasi pengganti,
status paritas, risiko performa, metode uji, dan keputusan bila tak bisa ditiru persis.

---

## B1. Inventaris Animasi IMPLEMENTASI BARU (aktif saat ini)

Semua animasi memakai **CSS transform/opacity** (GPU-friendly), vanilla JS tanpa
library, menghormati `prefers-reduced-motion`, dan **defensif** (cek keberadaan
elemen dulu — tidak error di halaman tanpa komponen terkait).

| # | Animasi | Lokasi | Pemicu | Durasi/Easing | Perilaku | Risiko performa | Metode uji | Status |
|---|---------|--------|--------|---------------|----------|-----------------|------------|--------|
| A1 | Reveal-on-scroll (fade + slide-up berjenjang) | Elemen `.reveal` semua halaman | Masuk viewport (IntersectionObserver, threshold 0.12) | `--motion-speed` (0.6s default), cubic-bezier(.22,1,.36,1), delay 90ms×data-delay | Opacity 0→1, translateY 26px→0; sekali saja (unobserve) | Rendah — IO, bukan scroll listener | Scroll halaman: elemen muncul halus; tanpa JS: tetap tampil (html.js gate) | ✅ AKTIF — LULUS uji manual |
| A2 | Header scrolled state (shadow + background pekat) | `#siteHeader` | scrollY > 12 (rAF throttled) | .3s ease | Box-shadow + background berubah | Rendah | Scroll → header memburam/berbayang | ✅ AKTIF |
| A3 | Scroll progress bar | `#scrollProgress` | scroll (rAF, passive) | width linear .1s | Garis gradient lebar mengikuti posisi baca | Rendah | Scroll → garis penuh di dasar halaman | ✅ AKTIF |
| A4 | Toggle menu mobile (hamburger→X, slide-down) | `.nav-toggle`, `#mainNav` | klik / Enter/Space / Escape | max-height .45s cubic-bezier(.22,1,.36,1); ikon transform .6s | 3 garis → X; panel max-height 0→70vh; ARIA-expanded sinkron | Rendah | Klik ☰ di ≤720px; Escape menutup + fokus kembali | ✅ AKTIF |
| A5 | Orb hero floating (gradient blur) | `.orb-a/.orb-b` | CSS keyframes 14s infinite alternate | ease-in-out | translate + scale pelan (parallax dasar) | Sedang-rendah — blur 90px; 2 elemen saja | Beranda → orb bergerak lembut; reduced-motion → diam | ✅ AKTIF |
| A6 | Parallax orb mengikuti scroll | `.orb` (pointer:fine saja) | scroll (rAF, passive) | realtime | translate3d kecepatan ±0.06–0.08 | Rendah (desktop mouse saja; ponsel tidak ikut) | Scroll beranda di desktop → orb bergerak beda arah | ✅ AKTIF |
| A7 | Counter statistik | `[data-counter]` | masuk viewport (IO 0.4) | 1.4s easeOutCubic | Angka 0→target + sufiks; format id-ID; reduced-motion → nilai akhir langsung | Rendah | Blok stats → angka berhitung naik | ✅ AKTIF |
| A8 | Hover kartu (lift + border accent + shadow) | `.card` | :hover / :focus-visible | .35s ease | translateY −6px, border aksen, shadow glow | Rendah | Hover kartu layanan | ✅ AKTIF |
| A9 | Micro-interaction tombol (lift + glow) | `.btn` | :hover/:active | .25s ease | translateY −2px / 0 saat klik | Rendah | Hover semua tombol | ✅ AKTIF |
| A10 | Accordion FAQ (+ ikon rotate 45°) | `details.faq-item` | klik summary (native `<details>`) | .6s; ikon .6s | Satu terbuka menutup yang lain (dalam satu grup); `+`→`×` | Rendah | Buka 2 FAQ bergantian | ✅ AKTIF |
| A11 | Hover step & stat | `.step`, `.stat-card` | :hover | .3s | translateX(6px) / translateY(−4px) | Rendah | Hover daftar langkah | ✅ AKTIF |
| A12 | Gallery zoom-on-hover | `.gallery-item img` | :hover | .6s | scale 1.04 | Rendah | Hover galeri | ✅ AKTIF |
| A13 | CTA glow bergerak | `.cta-glow` | CSS keyframes 10s alternate | ease-in-out | Radial gradient bergeser dalam panel | Rendah | Halaman dengan blok CTA | ✅ AKTIF |
| A14 | Title gradient shimmer (hero) | `.hero-title` | statis (background-clip) | — | Teks gradient 3 warna | Rendah | Beranda → judul gradient | ✅ AKTIF |
| A15 | Toast notifikasi slide-in | `.toast` | DOMContentLoaded (setelah submit kontak sukses) | .45s cubic-bezier | Slide-up + auto-hapus 6s | Rendah | Kirim form kontak | ✅ AKTIF |
| A16 | Nav underline active | `.main-nav a.active` | perbandingan path (server + JS fallback) | inset shadow instan | Garis bawah aksen pada item aktif | Rendah | Buka /layanan → menu "Layanan" aktif | ✅ AKTIF |
| A17 | Focus-visible ring aksen | semua elemen interaktif | :focus-visible | instan | Outline 2px aksen + offset | Rendah | Tab keyboard → ring jelas | ✅ AKTIF (aksesibilitas) |

### Aturan performa yang dipatuhi
1. Hanya `transform` & `opacity` dianimasikan (kompositor GPU; tidak ada layout thrashing).
2. Scroll listener memakai `{ passive: true }` + rAF throttle.
3. IntersectionObserver meng-`unobserve` setelah animasi selesai (tidak ada loop terus-menerus).
4. Parallax hanya untuk `pointer: fine` (bukan ponsel — hemat baterai).
5. Tidak ada autoplay video/lottie berat; tidak ada library animasi eksternal.
6. Fallback tanpa JS: konten tetap tampil (kelas `.reveal` hanya aktif bila `html.js`).
7. `prefers-reduced-motion: reduce` → semua animasi/transition ≤0.01ms, orb & glow berhenti, counter langsung nilai akhir.

---

## B2. TEMPLATE AUDIT ANIMASI SUMBER (isi setelah ZIP repo diberikan)

| Halaman/Komponen | Animasi sumber | Pemicu | Durasi/Easing | Perilaku sumber | Implementasi PHP-front-end pengganti | Status paritas | Status peningkatan | Risiko performa | Metode uji | Keputusan bila tak bisa ditiru |
|---|---|---|---|---|---|---|---|---|---|---|
| *(diisi dari audit)* | | | | | | DIPERTAHANKAN / DIPINDAHKAN / DITINGKATKAN / TERHALANG | | | hover+scroll+keyboard+mobile+reduced-motion | |

Cara mengisi: buka setiap halaman/komponen di repo sumber → catat animasi (CSS keyframes,
transition, library Framer Motion/GSAP/AOS **hanya bila benar-benar ditemukan di kode**) →
tandai satu baris per animasi → verifikasi paritas visual berdampingan (screenshot).

---

## C. Checklist Pengujian Gerakan (jalankan setelah perubahan tema)

- [ ] Desktop Chrome: reveal saat scroll beranda + halaman layanan (A1).
- [ ] Keyboard-only: Tab menampilkan ring fokus (A17); menu bisa dibuka-tutup Enter/Escape (A4).
- [ ] Mobile (≤720px): menu slide halus; TIDAK ada parallax (hemat baterai).
- [ ] `prefers-reduced-motion: ON` (DevTools → Rendering → Emulate): semua animasi mati, konten langsung tampil (A1,A5,A7,A13).
- [ ] Halaman TANPA komponen tertentu (mis. halaman tanpa stats): console BERSIH — tidak ada error JS (aturan defensif).
- [ ] Counter: nilai akhir benar dengan pemisah ribuan id-ID (mis. 5.000+) (A7).
- [ ] FAQ: buka item → item lain menutup; ikon + berputar (A10).
- [ ] Form kontak sukses → toast muncul & hilang otomatis (A15).
- [ ] Lighthouse (opsional): tidak ada "layout shift" dari animasi (elemen reveal memakai transform, bukan display:none).
