# TUTORIAL PEMULA — Memahami & Mengelola Website PT Perorangan

> Ditulis untuk Anda yang belum pernah mengelola website. Tidak ada asumsi.
> Baca sekali dari atas ke bawah, lalu simpan sebagai kamus referensi.

---

## 1. Glosarium Istilah (baca dulu, 5 menit)

| Istilah | Artinya dengan bahasa sehari-hari |
|---|---|
| **Hosting / cPanel** | Komputer server yang menyewa tempat untuk website Anda. cPanel = "ruang kendali" berbasis browser untuk mengelola server itu. |
| **Domain** | Alamat website Anda, misal `ptperusahaananda.com`. |
| **PHP 8.5** | Bahasa pemrograman server yang menjalankan website ini. Angka 8.5 adalah versi — versi baru = lebih cepat & aman. |
| **Database / MySQL** | Lemari arsip digital tempat data situs disimpan (halaman, layanan, pesan). |
| **phpMyAdmin** | Aplikasi web di cPanel untuk melihat/mengatur isi database. |
| **Document root** | Folder di hosting yang "dilihat" browser. Untuk proyek ini: folder `public/`. |
| **Front controller** | Pola di mana SEMUA kunjungan masuk lewat satu file (`public/index.php`) — seperti satu pintu resepsionis. |
| **Tema (theme)** | "Kulit" tampilan website. Folder `themes/pt-perorangan` mengendalikan seluruh tampilan pengunjung. |
| **Blok / Section** | Satu bagian halaman: hero (judul besar), fitur, langkah, FAQ, CTA. Disusun dari editor visual. |
| **Slug** | Bagian URL yang dibaca manusia, misal `/layanan/pendirian-pt-perorangan`. |
| **CSRF** | Serangan yang memaksa browser Anda mengirim form palsu. Situs ini melindungi semua form dengan token otomatis. |
| **Prepared statement** | Cara database menerima data pengguna dengan aman (anti SQL injection). Terpasang otomatis. |
| **Hash password** | Password disimpan dalam bentuk acak satu arah. Bahkan pemilik database tidak bisa membacanya. |
| **Sitemap XML** | Daftar URL situs untuk Google: `domain.com/sitemap.xml`. |
| **Canonical** | Tag yang menyatakan "URL resmi halaman ini" — mencegah duplikat di mata Google. |
| **Quality gate** | Pemeriksa otomatis: halaman tipis (< 2 blok / teks < 300 karakter / tanpa meta description) TIDAK boleh terbit. |
| **Draft / Review / Published** | Status konten: belum tayang / menunggu tinjauan / sudah tayang. |
| **Redirect 301** | "Alamat lama pindah permanen ke alamat baru" — menjaga pengunjung & peringkat Google. |
| **410** | "Konten ini dihapus permanen" — lebih jujur daripada 404. |
| **Cache** | Salinan cepat halaman/daftar URL. Otomatis dibersihkan saat Anda menyimpan konten. |
| **Reduced motion** | Pengaturan OS pengguna yang meminta animasi minimal — situs ini menghormatinya. |

## 2. Peta Folder — Apa yang TIDAK BOLEH Disentuh

```
public/       → folder web (document root). Hanya file di sini yang bisa diakses orang.
app/          → mesin aplikasi. TIDAK perlu disentuh untuk pemakaian rutin.
themes/pt-perorangan/ → tampilan. Hanya edit bila Anda mengerti HTML/CSS.
config/       → konfigurasi. Disentuh SEKALI saat instalasi (atau lewat installer).
storage/      → file internal (cache/log). JANGAN dihapus selain cache.
content/      → konten awal. Setelah instalasi, konten asli ada di DATABASE (ubah via dashboard).
database/     → skema SQL. Referensi saja.
docs/         → dokumen panduan (termasuk file ini).
tools/        → alat developer. TIDAK diunggah ke hosting.
```

**Aturan emas:** pekerjaan rutin 100% dari dashboard `domain.com/admin`. Edit file
hanya untuk penyesuaian desain tingkat lanjut.

## 3. Hubungan Frontend ↔ Backend ↔ Database ↔ Tema

```
Pengunjung → Browser → public/index.php (backend PHP)
                          ├─ baca/tulis → Database MySQL (data konten)
                          └─ pilih template di themes/pt-perorangan (tampilan)
Dashboard Admin (/admin) → juga backend → menulis ke database → situs publik berubah
```

- Mengubah konten di dashboard → tersimpan ke **database** → halaman publik langsung memakainya.
- Mengubah warna di Theme Customizer → disimpan sebagai pengaturan → dikirim ke tema sebagai CSS variables.
- File tema hanya berubah bila Anda (atau developer) menyunting file di `themes/`.

## 4. Alur Kerja Harian (resep cepat)

### 4.1 Mengganti logo & info kontak
1. Login `domain.com/admin`.
2. **Media** → unggah logo → salin path `/media/xxx.png`.
3. **Pengaturan** → tempatkan path di kolom "Logo" → isi WhatsApp/email/alamat → **Simpan**.
4. Buka situs → logo & footer berubah.

### 4.2 Membuat halaman baru dengan editor visual
1. **Halaman** → `+ Halaman Baru`.
2. Isi judul & meta description.
3. Tambah section: pilih jenis → `+ Tambah` → atur field → geser ↑↓ sesuai keinginan.
4. Lihat **Pratinjau Langsung** di kanan (🖥 / 📱 untuk desktop/mobile).
5. Status: simpan **Draft** dulu → review → pilih **Published** → **Simpan**.
6. Quality gate akan memblokir halaman tipis — ikuti saran perbaikannya (itu untuk kebaikan SEO Anda).

### 4.3 Menambah layanan
Sama seperti 4.2, tapi lewat menu **Layanan**. Keunggulannya ada kolom **Fakta Layanan**:
tarif resmi pemerintah, biaya jasa, estimasi waktu, syarat. Kartu fakta ini yang membuat
halaman Anda terlihat profesional dan terpercaya. Untuk banyak layanan sekaligus:
**Impor Massal** (CSV) → semua masuk sebagai draft.

### 4.4 Mengubah tampilan (warna/font)
**Tema** → pilih warna utama/aksen, font, radius, lebar, gaya header → **Simpan**.
Cache otomatis dibersihkan; efek langsung terlihat.

### 4.5 URL lama pindah alamat
**SEO** → isi URL lama, tipe `301`, URL baru → Simpan. Pengunjung & Google otomatis diarahkan.

### 4.6 Backup bulanan (WAJIB, 10 menit)
1. cPanel → **File Manager** → unduh ZIP seluruh folder situs.
2. cPanel → **phpMyAdmin** → pilih database → tab **Export** → format SQL → unduh.
3. Simpan keduanya di tempat lain (laptop/Google Drive).
4. Uji restore sekali (di subdomain percobaan) agar tidak cuma teori.

## 5. Kapan Harus Menghubungi Developer

- Ingin fitur baru (selain yang ada di dashboard).
- Muncul error 500 yang tidak hilang setelah `storage/cache` dibersihkan.
- Ingin migrasi hosting / perubahan domain besar.
- Ingin mengubah struktur tema secara mendalam.

## 6. Kesalahan Umum & Solusi Cepat

| Gejala | Penyebab umum | Solusi |
|---|---|---|
| Halaman putih / 500 | config database salah | cPanel → error log; periksa `config/config.php` |
| "Sesi keamanan formulir berakhir" (419) | Form terbuka terlalu lama | Muat ulang halaman, isi ulang form |
| Tidak bisa login, "terlalu banyak percobaan" | Rate limit 5×/15 menit (fitur keamanan) | Tunggu 15 menit |
| Perubahan tidak tampil | Cache browser | Ctrl+F5 / bersihkan cache |
| Halaman tipis tidak bisa terbit | Quality gate (fitur, bukan bug) | Perkaya konten: syarat, langkah, FAQ, sumber |
| Logo tidak muncul | Path bukan `/media/...` | Unggah lewat Media lalu salin path-nya |
| Gambar lambat | File MB besar | Kompres dulu (mis. squoosh.app) sebelum unggah |

## 7. Checklist Keamanan Pribadi Anda

- [ ] Password dashboard ≥ 12 karakter, unik.
- [ ] `public/install.php` sudah DIHAPUS dari hosting.
- [ ] `config/config.php` tidak pernah dibagikan / di-upload ke GitHub publik.
- [ ] Backup file+database rutin dan PERNAH diuji restore-nya.
- [ ] Selalu akses dashboard via HTTPS.
- [ ] Tambahkan editor baru dengan peran terkecil yang cukup (bukan semua `owner`).
