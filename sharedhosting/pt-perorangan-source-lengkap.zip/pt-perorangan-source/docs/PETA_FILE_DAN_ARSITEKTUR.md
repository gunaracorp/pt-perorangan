# PETA FILE DAN ARSITEKTUR — Website PT Perorangan (PHP 8.5)

> Dokumen wajib sesuai Bagian 4.3 Master Prompt: peta seluruh file proyek yang dibuat,
> fungsi teknis, sudut pandang pengguna, alasan keberadaan, pemanggil, file terkait,
> status publik/privat, kapan pemula perlu menyentuhnya, dan cara verifikasi.

---

## 1. Gambaran Arsitektur (bukan monorepo)

Proyek ini adalah **satu aplikasi modular sederhana**, bukan monorepo. Alasannya:
hanya ada satu aplikasi web (satu domain, satu database). Monorepo justru
menambah kompleksitas tanpa manfaat bagi satu pemilik situs di shared hosting.

```
pt-perorangan/
├── public/          ← SATU-SATUNYA folder yang boleh diakses browser (document root)
├── app/             ← Logika aplikasi (routing, keamanan, model, controller, view admin)
├── themes/          ← Tema tampilan publik (pt-perorangan) — benar-benar dipakai renderer
├── config/          ← Konfigurasi + peta route + schema blok
├── content/         ← Seed konten awal (JSON) — dimuat installer
├── database/        ← Skema SQL (MySQL) + skema SQLite (uji lokal)
├── storage/         ← PRIVAT: cache, log, database sqlite, rate-limit (tanpa akses publik)
├── docs/            ← Dokumentasi (folder ini)
└── tools/           ← Skrip CLI pengembangan (TIDAK diunggah ke hosting)
```

**Alur request (pahami sekali, berlaku untuk semua URL):**

1. Browser → `public/.htaccess` (Apache) meneruskan semua URL ke `public/index.php`.
2. `index.php` memuat `app/Core/bootstrap.php` (autoloader, konfigurasi, error handler).
3. `App::run()` → buka sesi aman → cek tabel redirect (301/302/410) → cocokkan URL dengan `config/routes.php` → panggil Controller.
4. Controller mengambil data via Model (PDO prepared statement) → membangun data SEO.
5. `View::render()` merender template di `themes/pt-perorangan/templates/...` di dalam layout → HTML dikirim ke browser.
6. Admin: `app/Controllers/Admin/*` → cek login/peran (`Auth`) → render view di `app/Views/admin/*` (layout admin terpisah dari tema publik).

---

## 2. Katalog File: `public/` (PUBLIK — document root)

| File | Fungsi teknis | Untuk apa / siapa memanggil | Publik? | Kapan pemula edit | Verifikasi setelah edit |
|---|---|---|---|---|---|
| `public/index.php` | Front controller: titik masuk semua request | Semua URL; dipanggil .htaccess | YA (wajib) | Tidak pernah | Buka beranda → 200 |
| `public/.htaccess` | Rewrite → index.php; security headers; kompresi; blokir file sensitif | Apache cPanel | YA | Saat aktifkan HTTPS (buka baris rewrite 301) | `curl -I domain` → header keamanan tampil |
| `public/media/.htaccess` | Matikan eksekusi PHP di folder upload | Apache | YA | Tidak pernah | Akses `/media/x.php` → 403 |
| `public/assets/admin/admin.css` | Tampilan dashboard admin | `<link>` dari layout admin | YA | Bila ingin mengubah gaya admin | Buka /admin → tampilan utuh |
| `public/assets/admin/admin.js` | Logika editor visual (page builder), autosave, viewport | Layout admin | YA | Tidak perlu | Buat halaman → tambah blok → tersimpan |
| `public/router-dev.php` | Router pengganti .htaccess untuk `php -S` (LOKAL SAJA) | Developer | Jangan diunggah | — | — |
| `public/install.php` | Wizard instalasi 4 langkah; self-lock setelah sukses | Pemilik, sekali | YA (sementara) | HAPUS setelah instalasi | Setelah install → 410/terkunci |

## 3. Katalog File: `app/Core/` (PRIVAT — inti kerangka)

| File | Fungsi | Kenapa ada (tidak digabung) | Dipanggil oleh | Pemula edit? | Verifikasi |
|---|---|---|---|---|---|
| `bootstrap.php` | Autoloader, konstanta, muat config, error handler aman | Titik tunggal inisialisasi | index.php, installer, tools | Tidak | Semua URL hidup |
| `App.php` | Siklus request: sesi → redirect → route → controller | Alur tetap terdokumentasi | index.php | Tidak | Redirect 301 bekerja |
| `Router.php` | Pencocokan URL → handler; `{path}` multi-segmen untuk aset | Terpisah agar route bisa diuji | App.php | Tidak | Semua route 200/404 benar |
| `Database.php` | PDO singleton (MySQL/SQLite), helper query aman | Satu titik kontrol koneksi | Semua Model | Tidak | Halaman berbasis DB tampil |
| `Session.php` | Sesi aman (HttpOnly/SameSite/Secure), flash, regenerasi | Cookie sesi aman = wajib | App, Auth, Csrf | Tidak | Login → cookie `ptper_session` |
| `Auth.php` | Login/logout, rate limit file-based, matrix peran | Keamanan login tidak boleh tersebar | Controller admin | Tidak | 5× login salah → diblok 15 menit |
| `Csrf.php` | Token CSRF per sesi + guard POST | Semua form mutasi data wajib token | Semua controller POST | Tidak | Form tanpa token → 419 |
| `View.php` | Renderer tema (template+layout+komponen), error page bertema | Pemisahan core vs tema | Controller publik | Tidak | Tema berubah tanpa sentuh core |
| `Theme.php` | siteData, CSS variables dari customizer, buildSeo | Opsi tema dari DB → tampilan | View, admin ThemeController | Tidak | Ubah warna di /admin/tema → situs berubah |
| `Cache.php` | File cache + tag + flush | Shared hosting tanpa Redis | Sitemap, Setting, dsb. | Tidak | Publish → cache bersih otomatis |
| `Validator.php` | Validasi server-side (required/email/slug/…) | Client-side bisa dilewati | Controller POST | Tidak | Email salah → pesan error |

## 4. Katalog File: `app/Models/` (PRIVAT — lapisan data)

| File | Tabel | Fungsi utama |
|---|---|---|
| `BaseModel.php` | — | CRUD generik prepared-statement (find/insert/update/delete/count) |
| `User.php` | users | Akun admin; password_hash; peran owner/admin/editor/reviewer |
| `Setting.php` | settings | Key-value per grup (site/theme/analytics); upsert MySQL & SQLite |
| `Page.php` | pages | Halaman builder; blocks JSON; saveWithRevision; sitemap |
| `Category.php` | categories | Kategori layanan (hub) |
| `Service.php` | services | Layanan + facts JSON (biaya resmi/jasa/waktu/syarat) |
| `Article.php` | articles | Artikel edukasi; penulis/reviewer |
| `Faq.php` | faqs | Bank FAQ (global + per layanan) |
| `Menu.php` | menus | Menu header/footer dari DB (fallback default) |
| `Media.php` | media | Metadata upload (alt, kredit, dimensi) |
| `Redirect.php` | redirects | 301/302/410 + hit counter + deteksi loop sederhana |
| `Revision.php` | revisions | Snapshot sebelum tiap simpan; restore; prune 20 terakhir |
| `ContactMessage.php` | contact_messages | Pesan formulir kontak (IP di-hash) |

## 5. Katalog File: `app/Services/` (PRIVAT — logika domain)

| File | Fungsi | Kenapa penting |
|---|---|---|
| `BlockSchema.php` | Whitelist tipe blok + sanitasi tiap field (text/html terbatas/url/image/list) + `blocksToPlainText` | KUNCI KEAMANAN EDITOR: tidak ada eksekusi kode mentah; field di luar schema dibuang |
| `SeoService.php` | Pembangun JSON-LD (Organization, WebSite, Service, FAQPage, Article, Breadcrumb) dari data yang benar-benar tampil | Structured data valid sesuai Search Central; dilarang mengarang rating/harga |
| `SitemapService.php` | Sitemap index + tersegmentasi (pages/services/articles) + robots.txt dinamis | Fondasi SEO ribuan URL; hanya URL kanonis published |
| `QualityGate.php` | Gerbang kualitas sebelum publish: title/description, ≥2 blok, teks ≥300 karakter, sumber resmi untuk topik regulasi | Anti thin-content; selaras spam policies |
| `ImportService.php` | Impor CSV/JSON layanan massal; validasi per baris; hasil = DRAFT | Produksi halaman skala besar dengan kontrol kualitas |

## 6. Katalog File: Controller & View Admin

| File | Route yang dilayani | Peran minimum |
|---|---|---|
| `Controllers/HomeController.php` | `/` | publik |
| `Controllers/PageController.php` | `/p/{slug}` | publik |
| `Controllers/ServiceController.php` | `/layanan`, `/layanan/kategori/{slug}`, `/layanan/{slug}` | publik |
| `Controllers/ArticleController.php` | `/artikel`, `/artikel/{slug}` | publik |
| `Controllers/FaqController.php` | `/faq` | publik |
| `Controllers/ContactController.php` | `/kontak` GET+POST | publik |
| `Controllers/SearchController.php` | `/cari` (noindex + X-Robots-Tag) | publik |
| `Controllers/SitemapController.php` | `/sitemap*.xml`, `/robots.txt` | publik |
| `Controllers/AssetController.php` | `/theme-assets/{path}` (proteksi traversal) | publik |
| `Controllers/Admin/AuthController.php` | `/admin/login|logout` | publik (form login) |
| `Controllers/Admin/DashboardController.php` | `/admin` | login |
| `Controllers/Admin/PagesController.php` | CRUD halaman + editor + pratinjau + revisi + autosave | editor |
| `Controllers/Admin/ServicesController.php` | CRUD layanan + fakta + editor | editor |
| `Controllers/Admin/ArticlesController.php` | CRUD artikel | editor |
| `Controllers/Admin/CategoriesController.php` | CRUD kategori | editor |
| `Controllers/Admin/FaqController.php` | CRUD FAQ | editor |
| `Controllers/Admin/MediaController.php` | upload/list/edit/hapus media (validasi MIME nyata) | editor |
| `Controllers/Admin/MenusController.php` | menu header/footer | editor |
| `Controllers/Admin/ThemeController.php` | customizer (13 kontrol tervalidasi) | editor |
| `Controllers/Admin/SeoController.php` | redirect manager + flush sitemap | editor |
| `Controllers/Admin/ImportController.php` | impor massal | editor |
| `Controllers/Admin/UsersController.php` | manajemen pengguna | admin/owner |
| `Controllers/Admin/SettingsController.php` | identitas, kontak, GSC, GA | editor (GA: admin) |
| `Controllers/Admin/MessagesController.php` | kotak masuk pesan | editor |

`app/Views/admin/*.php` (20 view) = tampilan dashboard; layout di `Views/admin/layout.php`.
Semua output lewat `Str::e()` (escape) — anti-XSS.

## 7. Katalog File: Tema `themes/pt-perorangan/`

| File | Fungsi |
|---|---|
| `theme.json` | Manifest kemampuan tema (dibaca aplikasi) |
| `layouts/default.php` | Kerangka semua halaman publik (head SEO + header + main + footer) |
| `components/head.php` | Meta SEO/OG/JSON-LD/CSS-tokens/GSC/GA — terpusat |
| `components/header.php` | Navigasi sticky glass + menu CMS + CTA WA + toggle mobile ARIA |
| `components/footer.php` | Footer modular + disclaimer non-afiliasi pemerintah |
| `components/breadcrumb.php` | Breadcrumb aksesibel |
| `templates/page.php` | Halaman builder generik |
| `templates/service.php` | Detail layanan (kartu fakta + blok + FAQ + terkait) |
| `templates/service_index.php`, `service_category.php` | Hub layanan & kategori |
| `templates/article.php`, `article_index.php` | Artikel & daftar |
| `templates/faq.php`, `contact.php`, `search.php` | FAQ / kontak / pencarian |
| `templates/404.php`, `410.php` | Error page (status asli dikirim controller) |
| `templates/blocks/*.php` (14 file) | Render 14 jenis blok page builder |
| `assets/css/main.css` | Design system futuristik (±500 baris; animasi transform/opacity; reduced-motion) |
| `assets/js/main.js` | Reveal-on-scroll (IntersectionObserver), header state, counter, parallax, accordion, menu mobile — semua defensif |

## 8. Katalog File: Konfigurasi, Database, Content, Tools

| File | Fungsi | Publik? |
|---|---|---|
| `config/config.example.php` | Template konfigurasi berkomentar lengkap | PRIVAT |
| `config/config.php` | Konfigurasi asli (dibuat installer) | PRIVAT — jangan dibagikan |
| `config/routes.php` | PETA SEMUA URL aplikasi | PRIVAT |
| `config/blocks.php` | Schema 14 blok (label Indonesia + tipe field) | PRIVAT |
| `config/.installed` | Penanda installer terkunci | PRIVAT |
| `database/schema.mysql.sql` | 12 tabel MySQL utf8mb4 berkomentar | PRIVAT |
| `database/schema.sqlite.php` | Skema SQLite uji lokal | PRIVAT |
| `content/*.json` | Seed: settings, categories, services (4 layanan riil), pages (5 halaman), faq (10 tanya), menus | PRIVAT |
| `tools/setup-local.php` | Setup uji lokal (SQLite + seed + admin demo) | Jangan diunggah |
| `tools/router-dev.php` | Router untuk `php -S` | Jangan diunggah |
| `tools/smoke-test.php` | 27 tes integrasi end-to-end | Jangan diunggah |
| `.htaccess` (root) | Proteksi folder internal + forward ke public/ saat full-upload | WAJIB bila full-upload |

## 9. Prinsip Penamaan & Konvensi

- Semua file PHP memakai header komentar `FILE / FUNGSI / UNTUK / KENAPA / TERKAIT / AMAN? / PEMULA / JANGAN`.
- Semua URL admin berbahasa Indonesia (`/admin/halaman`, `/admin/layanan`).
- Semua input → `Str::clean()` / `Validator` / `BlockSchema::sanitizeBlocks()`; semua output HTML → `Str::e()`.
- Tabel DB `snake_case`; kelas PHP `PascalCase` PSR-4 mini (tanpa Composer).
