# STATUS ROADMAP 99 FITUR (nomor asli dipertahankan)

> Legenda: ✅ SUDAH ADA · 🟡 ADA SEBAGIAN · ⬜ BELUM ADA · ⛔ TERHALANG · ➖ TIDAK RELEVAN
> Status diukur terhadap implementasi PHP 8.5 yang diserahkan HARI INI (bukan janji).
> Bukti = path file / fitur yang dapat diuji. Nomor tetap sesuai Bagian II Master Prompt.

## Fase 1 — Fondasi (1–11)
1. Backup sumber & titik pemulihan — ⬜ BELUM ADA (prosedur backup ada di docs; eksekusi di tangan pemilik) · `docs/README_DEPLOY_CPANEL.md` L8
2. Inventaris halaman & fitur — ⛔ TERHALANG (repo 404); inventaris aplikasi baru ✅ (`docs/PETA_FILE_DAN_ARSITEKTUR.md`)
3. Peta URL lama-baru — 🟡 redirect manager ✅ (`app/Models/Redirect.php`); peta URL repo ⛔ TERHALANG
4. Baseline SEO & performa — ⬜ BELUM ADA (butuh domain produksi + Search Console)
5. Pemeriksaan wajib PHP 8.5 — ✅ installer mengecek + memblokir versi < 8.5 (`public/install.php`)
6. Matriks ekstensi & dependensi — ✅ (`install.php` cek ekstensi; `docs/PETA_FILE` §8)
7. Pemisahan core/tema/konten — ✅ (`app/`, `themes/pt-perorangan/`, database+content/)
8. Router & registri halaman — ✅ (`app/Core/Router.php`, `config/routes.php`)
9. Skema database & migrasi versi — 🟡 skema ✅ (12 tabel); sistem migrasi versi ⬜
10. Konfigurasi & secret privat — ✅ (`config/config.php` di luar public; .htaccess blokir)
11. Rilis, rollback, catatan perubahan — 🟡 rollback konten ✅ (revisions); versi aplikasi ⬜

## Fase 2 — Tema & UX (12–22)
12. Design tokens — ✅ (`Theme::cssVariables()` + customizer 13 kontrol)
13. Layout responsif + motion-ready — ✅ (`main.css` grid clamp, breakpoint)
14. Library komponen UI futuristik — ✅ (card/badge/btn/table/modal-lite/accordion/alert/form; modal penuh ⬜)
15. Header & navigasi dari CMS — ✅ (`Menu::items()` + `/admin/menu`)
16. Menu mobile aksesibel — ✅ (ARIA, Escape, fokus; uji `main.js` §3)
17. Footer modular — ✅ (`components/footer.php` + style grid/simple)
18. Breadcrumb konsisten — ✅ (`components/breadcrumb.php` + JSON-LD BreadcrumbList)
19. CTA & formulir reusable — ✅ (blok cta/contact + CTA WA otomatis)
20. Status validasi jelas — ✅ (field-error, flash success/error, toast)
21. Motion system + interaksi defensif — ✅ (17 animasi terdokumentasi & diuji; `ANIMATION_INVENTORY.md`)
22. Aksesibilitas UI dasar — ✅ (skip-link, focus-visible, kontras gelap, label form, reduced-motion)

## Fase 3 — Arsitektur layanan & SEO intent (23–33)
23. Riset keyword kebutuhan pengguna — ⬜ BELUM ADA (proses, bukan kode)
24. Pengelompokan intent — 🟡 struktur konten mendukung; matriks awal ✅ `MATRIKS_SEO_INTENT.md`
25. Taksonomi kategori/layanan — ✅ (categories + service.category_id)
26. Aturan slug/URL — ✅ (slugify + anti-duplikat + stabil saat edit)
27. Matriks intent→halaman — ✅ awal (`MATRIKS_SEO_INTENT.md`, akan berkembang dari data)
28. Halaman hub kategori — ✅ (`/layanan`, `/layanan/kategori/{slug}`)
29. Landing layanan utama — ✅ (4 layanan seed dengan hero/fakta/FAQ/sumber)
30. Halaman syarat & kelayakan — ✅ (blok checklist + facts.requirements per layanan)
31. Halaman langkah/prosedur — ✅ (blok steps)
32. Halaman biaya & tarif — ✅ (blok pricing; pemisahan tarif resmi vs jasa)
33. Halaman wilayah autentik — 🟡 field `region` per layanan ✅; halaman wilayah ⬜ (anti doorway by design)

## Fase 4 — Jenis halaman bernilai & gerbang kualitas (34–44)
34. Glosarium — ⬜ BELUM ADA (bisa dibuat dari blok richtext/halaman)
35. FAQ berbasis pertanyaan nyata — ✅ (bank FAQ + per layanan; pengumpulan otomatis ⬜)
36. Perbandingan pilihan — 🟡 (blok features/pricing mendukung; halaman perbandingan khusus ⬜)
37. Panduan pemecahan masalah — ✅ via artikel (blok rich)
38. Halaman per jenis kebutuhan — ✅ via page builder
39. Pemeriksa kelayakan/kalkulator — ⬜ BELUM ADA (roadmap P2; butuh rules jelas)
40. Checklist dokumen — ✅ (blok checklist)
41. Template dokumen unduhan — ⬜ BELUM ADA (media PDF mendukung, konten ⬜)
42. Sumber resmi per halaman — ✅ (blok sources + kolom seo.sources + tanggal review)
43. Blok nilai unik per halaman — ✅ (facts + 14 jenis blok)
44. Quality gate sebelum indeksasi — ✅ server-side (`QualityGate.php`; teruji menahan publish)

## Fase 5 — CMS & produksi skala besar (45–55)
45. Visual page builder front-end — ✅ (editor blok + pratinjau live 3 viewport + autosave; klik-section-di-preview ⬜)
46. Impor massal CSV/JSON — ✅ (`ImportService` + laporan per baris + slug auto-unique)
47. Editor massal metadata SEO — ⬜ BELUM ADA (per-halaman ✅; bulk ⬜)
48. Draft/preview/autosave/undo-restore — ✅ (status workflow + pratinjau + revisions + restore)
49. Penjadwalan publikasi — 🟡 status "Terjadwal" ada; eksekusi otomatis butuh Cron ⛔ batas provider
50. Reusable blocks & theme customizer — ✅ customizer penuh; reusable-library antar halaman ⬜
51. Media library — ✅ (upload aman, alt, kredit, pencarian; crop ⬜)
52. Workflow editorial — ✅ (draft→review→published→needs_update + peran reviewer)
53. Saran internal linking — ⬜ BELUM ADA
54. Komponen terkait & FAQ relevan — ✅ (blok related + FAQ per layanan; saran otomatis ⬜)
55. Redirect manager — ✅ (301/302/410 + hit + anti-loop)

## Fase 6 — Technical SEO skala (56–66)
56. SEO metadata per halaman — ✅ (title/description/robots/canonical/OG per entitas)
57. Structured data tervalidasi — ✅ (JSON-LD Organization/WebSite/Service/FAQPage/Article/Breadcrumb — tanpa data palsu)
58. Sitemap index tersegmentasi — ✅ (pages/services/articles; hanya kanonis published)
59. robots.txt aman — ✅ (dinamis; tidak memblokir aset)
60. Hreflang — ➖ TIDAK RELEVAN (situs satu bahasa; struktur siap bila pasar nyata muncul)
61. Kontrol pagination/filter — 🟡 (pencarian noindex ✅; paginasi daftar ⬜ butuh volume)
62. Status 404/410 benar — ✅ (teruji; 410 via redirect manager)
63. Pencarian internal tidak banjir indeks — ✅ (noindex + X-Robots-Tag)
64. Optimasi gambar — ✅ (alt wajib, dimensi, lazy-load; konversi webp otomatis ⬜)
65. Pengukuran CWV — ⬜ BELUM DIUJI (butuh produksi; GA slot tersedia)
66. Pemeriksaan teknis otomatis — ⬜ BELUM ADA (roadmap P2)

## Fase 7 — Kepercayaan & kualitas editorial (67–77)
67. Profil penulis/reviewer — 🟡 (author_id/reviewed_by ✅; halaman profil ⬜)
68. Sumber resmi & tanggal review — ✅ (blok sources + reviewed_at)
69. Halaman tentang — ✅ (seed "Tentang Kami" dengan batas tanggung jawab)
70. Kontak & jangkauan — ✅ (halaman kontak + facts.region)
71. Kebijakan privasi — ✅ (seed lengkap; IP di-hash sesuai isinya)
72. Syarat layanan & refund — ✅ (seed "Syarat Layanan")
73. Disclaimer afiliasi — ✅ (footer + halaman tentang: BUKAN pemerintah)
74. Transparansi harga & ruang lingkup — ✅ (facts memisahkan resmi vs jasa)
75. Testimoni asli berizin — ✅ mekanisme (blok testimonials; seed ditandai "ganti dengan testimoni asli")
76. Studi kasus nyata — ⬜ BELUM ADA (butuh izin klien)
77. Kebijakan editorial/koreksi — 🟡 (tanggal review per blok; halaman kebijakan editorial ⬜)

## Fase 8 — Keamanan, performa, ketahanan (78–88)
78. RBAC/roles — ✅ (owner/admin/editor/reviewer + matrix server-side)
79. Pengujian proteksi input/output — ✅ (CSRF/XSS/slug/traversal teruji; IDOR/SQL-injection suite penuh ⬜)
80. Proteksi login & reset — 🟡 (rate limit ✅, regenerasi sesi ✅; reset password email ⬜ butuh mail)
81. Keamanan upload — ✅ (MIME nyata fileinfo, whitelist, nama acak, no-exec htaccess, SVG disanitasi)
82. HTTPS & security headers — ✅ (htaccess headers + HTTPS toggle; aktifasi tergantung SSL host)
83. Backup & uji restore — 🟡 (prosedur ✅; otomatisasi ⬜; uji restore di tangan pemilik)
84. Pembaruan dependensi — ✅ (nol dependensi runtime — tidak ada yang perlu di-patch)
85. Cache & invalidasi konsisten — ✅ (flush otomatis saat publish/setting/redirect)
86. Optimasi aset & browser cache — ✅ (deflate+expires htaccess; minifikasi ⬜)
87. Optimasi SQL & daftar — ✅ (index pada slug/status/entity; LIMIT di semua daftar)
88. Audit aksesibilitas & mobile — ✅ dasar (keyboard, kontras, label, reduced-motion; audit pihak-3 ⬜)

## Fase 9 — Analitik & pertumbuhan (89–99)
89. GSC & analitik — ✅ slot (meta verifikasi + gtag opsional di /admin/pengaturan)
90. Laporan indeksasi & query — ⬜ (butuh GSC produksi)
91. Funnel konversi — 🟡 (penanda klik WA `data-wa` ✅; laporan funnel ⬜)
92. Analitik pencarian internal — ⬜ BELUM ADA
93. Eksperimen CTA terukur — ⬜ BELUM ADA (etika eksperimen sudah ditegakkan by design)
94. Peringatan gangguan — ⬜ (butuh layanan eksternal/Cron; opsional)
95. Laporan rutin & dashboard — 🟡 (dashboard statistik ✅; laporan bulanan otomatis ⬜)
96. Pembaruan konten menua — ✅ status `needs_update` + tanggal review
97. Ekspansi dari bukti permintaan — 🟡 (impor massal ✅; keputusan berbasis data = proses)
98. Kesiapan multi-bahasa — ➖ TIDAK RELEVAN saat ini (satu bahasa; arsitektur URL stabil siap)
99. Portabilitas & evaluasi roadmap — ✅ (ekspor SQL+file terdokumentasi; dokumen ini memungkinkan evaluasi)

## Rekap
| Status | Jumlah |
|---|---|
| ✅ SUDAH ADA | 44 |
| 🟡 ADA SEBAGIAN | 12 |
| ⬜ BELUM ADA | 20 |
| ⛔ TERHALANG | 2 |
| ➖ TIDAK RELEVAN | 2 |

*(rekap dihitung dari penandaan di atas — nomor tetap, status jujur, bukti tersedia)*

## Batch Implementasi Berikutnya (rekomendasi, nilai tinggi + risiko rendah)
1. **Batch A (fondasi produksi):** deploy cPanel → SSL → GSC → ukur CWV baseline → isi gap #4/#65.
2. **Batch B (konten intent):** 10–20 halaman layanan dari `MATRIKS_SEO_INTENT.md` via editor/impor → quality gate menjamin mutu.
3. **Batch C (CMS+):** editor massal SEO (#47), reusable blocks (#50), saran internal linking (#53).
4. **Batch D (audit repo):** saat ZIP diberikan → audit gap + peta animasi B2 + peta URL → redirect 301 otomatis.
