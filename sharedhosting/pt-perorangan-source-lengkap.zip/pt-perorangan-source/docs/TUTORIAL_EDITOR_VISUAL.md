# TUTORIAL EDITOR VISUAL — Mengubah Website Tanpa Menyentuh Kode

> Alur lengkap: login → buka halaman → pilih edit visual → ubah section →
> pratinjau mobile/desktop → simpan draft → review → publish → verifikasi URL →
> rollback bila perlu. Setiap langkah menyebut **hasil yang diharapkan** dan
> **perbaikan dasar bila gagal**.

---

## 1. Peta Dashboard (mengenali dulu tempatnya)

```
/admin            Dasbor ringkasan
/admin/halaman    Page builder (beranda, tentang, halaman intent)
/admin/layanan    Layanan + fakta terstruktur (inti bisnis)
/admin/kategori   Kategori layanan (struktur hub)
/admin/artikel    Artikel edukasi
/admin/faq        Bank pertanyaan-jawaban
/admin/media      Upload & kelola gambar/file
/admin/menu       Navigasi header/footer
/admin/tema       Customizer warna/font/gaya
/admin/seo        Redirect 301/302/410 + sitemap
/admin/impor      Impor massal CSV/JSON
/admin/pesan      Pesan dari form kontak
/admin/pengaturan Identitas situs & kontak
/admin/pengguna   Kelola tim (owner/admin saja)
```

---

## 2. Alur Utama: Mengedit Halaman dengan Editor Visual

### Langkah 1 — Login
Buka `domain.com/admin/login` → email + kata sandi → **Masuk**.
**Hasil diharapkan:** dasbor dengan statistik konten.
**Bila gagal:** "terlalu banyak percobaan" = tunggu 15 menit (proteksi otomatis).

### Langkah 2 — Buka halaman yang mau diedit
Menu **Halaman** → klik **Edit** pada judul target (atau `+ Halaman Baru`).
**Hasil:** layar editor dua kolom — kiri: metadata + daftar section; kanan: **Pratinjau Langsung** dalam iframe.

### Langkah 3 — Pahami daftar Section (Blok)
Setiap section punya tombol alat:
| Tombol | Fungsi |
|---|---|
| ↑ / ↓ | Geser urutan section |
| ⧉ | Duplikat (buat variasi) |
| 👁 / 🚫 | Tampilkan / sembunyikan (tanpa menghapus) |
| ✕ | Hapus (minta konfirmasi) |

Klik kepala section untuk **membuka form field-nya**. Field mengikuti schema aman —
Anda tidak pernah bisa memasukkan kode berbahaya (server menyaring ulang).

### Langkah 4 — Ubah section
Contoh mengganti judul hero: buka section **Hero** → ubah "Judul utama" →
lihat perubahan konsep di struktur. Klik area kosong untuk menutup form.
**Hasil:** teks di form berubah; pratinjau iframe belum otomatis memuat draft (lihat langkah 5).

### Langkah 5 — Pratinjau Desktop / Tablet / Mobile
- Tombol 🖥 / 📱 / 📲 di atas pratinjau → lebar bingkai berubah (klik dua ukuran).
- Untuk melihat draft TERKINI dalam pratinjau: **Simpan dulu** (draft), lalu muat ulang iframe (⟳) atau klik **Pratinjau Tab Baru**.
- **Autosave:** setiap 60 detik setelah Anda mengubah blok, salinan revisi otomatis dibuat — statusnya muncul di bawah pratinjau. Data Anda tetap aman di form meski autosave tertunda.

### Langkah 6 — Simpan Draft
Pilih status **Draft** → **Simpan Perubahan**.
**Hasil:** flash hijau "Perubahan tersimpan". Situs publik BELUM berubah.

### Langkah 7 — Review
Peran **reviewer/admin** membuka halaman, memeriksa panel **Kualitas** (skor + daftar isu).
Ubah status ke **Perlu review** bila menunggu persetujuan orang lain.

### Langkah 8 — Publish
Isi **meta description** (120–156 karakter) — WAJIB.
Pilih status **Published** → **Simpan**.
**Gerbang kualitas akan menolak** dan mengembalikan status ke "perlu review" bila:
- meta description kosong;
- kurang dari 2 section berisi;
- total teks < 300 karakter;
- menyebut regulasi/biaya resmi tanpa kolom "Sumber resmi".
**Hasil bila lolos:** halaman langsung tayang; cache sitemap dibersihkan otomatis.

### Langkah 9 — Verifikasi URL publik
Buka URL halaman (ditampilkan di editor: `/p/slug` atau `/layanan/slug`).
- Cek judul browser tab = meta title Anda.
- Klik kanan → "Lihat sumber halaman" → cari `rel="canonical"` dan `application/ld+json`.
**Hasil:** halaman tampil dengan struktur SEO lengkap.

### Langkah 10 — Rollback bila perlu
Editor → tombol **Revisi** → pilih catatan waktu → **Pulihkan** → konfirmasi.
Sistem otomatis menyimpan kondisi SAAT INI lebih dulu, jadi rollback pun bisa di-undo.
**Hasil:** konten kembali persis seperti pada waktu revisi itu.

---

## 3. Theme Customizer (Mengubah Tampilan Global)

**Tema** → 13 kontrol: 6 warna, 2 font, radius, lebar konten, gaya header, gaya footer, kecepatan animasi.
- Setiap kontrol punya penjelasan singkat di bawahnya.
- Klik **Simpan Tampilan** → cache dibersihkan → buka situs → semua halaman memakai nilai baru.
- **Bila gagal/aneh:** kembalikan nilai default (tercantum di form) → Simpan. Nilai tersanitasi server — CSS berbahaya tidak mungkin masuk.

## 4. Menu Navigasi

**Menu** → dua kolom (Header/Footer) → baris `Label | URL` → `+ Baris` untuk menambah → ✕ menghapus → **Simpan Semua Menu**.
URL boleh internal (`/layanan`) atau absolut (`https://...`). URL tidak valid dilewati server diam-diam.
**Hasil:** navigasi berubah di seluruh situs, termasuk mobile (toggle ☰).

## 5. Media Library

**Media** → pilih file (jpg/png/webp/gif/svg/pdf, ≤ 8 MB) → isi **alt text** (wajib untuk aksesibilitas & SEO) → Unggah.
- Server memeriksa MIME NYATA file (bukan sekadar nama) dan mengganti nama acak — upload berbahaya ditolak.
- Edit alt/kredit kapan pun di kartu media.
- Gunakan path `/media/nama-file.ext` pada field gambar di blok/kontak/customizer logo.
**Bila gagal:** ukuran melebihi batas atau tipe tidak cocok — kompres dulu, atau konversi format.

## 6. Impor Massal (Banyak Layanan Sekaligus)

**Impor Massal** → unggah CSV/JSON atau tempel → **Proses Impor**.
Header CSV wajib: `title,slug,excerpt,body,official_fee,service_fee,est_time`
- `body` minimal 200 karakter; semua hasil = **DRAFT** (tidak langsung tayang).
- Laporan per baris menunjukkan yang gagal + alasannya.
**Hasil:** draft dalam jumlah besar siap direview satu per satu → publish lewat gerbang kualitas.

## 7. Redirect & Sitemap

**SEO** → **Tambah Redirect**: URL lama → tipe → tujuan.
- 301 = pindah permanen (paling sering dipakai); 302 = sementara; 410 = dihapus permanen (kolom tujuan dikosongkan).
- Sistem menolak loop (URL = tujuan).
- Kolom **Hit** menunjukkan berapa kali redirect dipakai — berguna untuk menutup URL lama yang masih dikunjungi.
**Sitemap:** `domain.com/sitemap.xml` (indeks) → sub-sitemap pages/services/articles. Tombol **Bersihkan Cache Sitemap** untuk memaksa regenerasi.

## 8. Ringkasan Status Publikasi

| Status | Arti | Terlihat publik? | Di sitemap? |
|---|---|---|---|
| Draft | Sedang dikerjakan | ✕ | ✕ |
| Perlu review | Menunggu tinjauan | ✕ | ✕ |
| Terjadwal | Menunggu waktu tayang (kelola manual di shared hosting) | ✕ | ✕ |
| Published | Tayang (lolos gerbang kualitas) | ✓ | ✓ |
| Perlu pembaruan | Sudah tayang tetapi konten menua | ✓ | ✓ (segera perbarui) |
