# MATRIKS SEO INTENT → HALAMAN (awal, berbasis kebutuhan nyata)

> Prinsip (sesuai Bab 6 prompt): satu intent penting = satu halaman kuat;
> variasi ejaan digabung; TIDAK ada halaman kota kembar; quality gate menahan
> halaman tipis sebelum indeks. Matriks ini adalah STARTING POINT — akan
> berkembang dari data Search Console (bukan mengejar jumlah URL).

| # | Kelompok intent (gabungan variasi) | Jenis halaman | URL target | CTA | Sumber fakta | Status |
|---|---|---|---|---|---|---|
| 1 | cara mendirikan pt perorangan; proses pendirian pt perorangan; syarat mendirikan pt perorangan | Layanan utama + prosedur | `/layanan/pendirian-pt-perorangan` | Konsultasi WA | Permenkum 49/2025, PP 8/2021, layanan.ahu.go.id | ✅ PUBLISHED |
| 2 | biaya pendirian pt perorangan; pnbp pt perorangan; modal minimal pt perorangan | Bagian biaya dalam layanan utama (digabung — intent sama-sama "berapa biaya") | `/layanan/pendirian-pt-perorangan#biaya` | Konsultasi | PNBP Rp50.000; PP 8/2021 (25% disetor) | ✅ dalam halaman #1 (gabung, jangan URL terpisah) |
| 3 | syarat pt perorangan; dokumen yang dibutuhkan pt perorangan | Checklist dalam layanan utama | `/layanan/pendirian-pt-perorangan#syarat` | Konsultasi | KTP/KK/NPWP sinkron; kriteria UMK PP 7/2021 | ✅ dalam halaman #1 |
| 4 | nib; nomor induk berusaha; izin usaha oss | Layanan | `/layanan/nib-oss-rba` | Konsultasi izin | oss.go.id; PP 28/2025 | ✅ PUBLISHED |
| 5 | kbli usaha; cara memilih kbli; kbli untuk pt perorangan | Layanan konsultasi | `/layanan/konsultasi-kbli` | Jadwalkan konsultasi | KBLI 2025 (transisi OSS) | ✅ PUBLISHED |
| 6 | ubah nama pt perorangan; ubah alamat pt perorangan; perubahan data perseroan | Layanan | `/layanan/perubahan-data-pt-perorangan` | Konsultasi perubahan | layanan.ahu.go.id | ✅ PUBLISHED |
| 7 | perbedaan pt perorangan dan pt biasa; kapan pakai pt perorangan | Artikel perbandingan (edukasi → link layanan #1) | `/artikel/perbedaan-pt-perorangan-dan-pt-biasa` | Baca → layanan | UU Cipta Kerja; PP 7/2021; PP 8/2021 | ⬜ DRAFT (buat saat konten ditulis penuh) |
| 8 | pt perorangan wajib lapor lkpm; kewajiban setelah pt berdiri | Artikel (edukasi → layanan kepatuhan) | `/artikel/kewajiban-pt-perorangan-setelah-berdiri` | Baca → kontak | LKPM oss.go.id | ⬜ DRAFT |
| 9 | pt perorangan vs cv vs usaha perorangan | Artikel perbandingan objektif | `/artikel/pt-perorangan-vs-cv-vs-usaha-perorangan` | Konsultasi | UU 40/2007 jo. UU Cipta Kerja | ⬜ DRAFT |
| 10 | apakah pt perorangan harus notaris; berapa lama proses pt perorangan | FAQ (halaman FAQ + JSON-LD) | `/faq` | Konsultasi | Permenkum 49/2025 | ✅ PUBLISHED (10 Q&A) |
| 11 | [kota] + jasa pendirian pt perorangan (mis. "jasa pendirian pt perorangan jakarta") | **TIDAK dibuat otomatis** | — | — | — | ➖ ANTILUKA: hanya buat halaman wilayah bila ada layanan & info lokal NYATA yang bisa dibuktikan (mis. alamat kantor, kunjungan). Tanpa itu: tetap satu halaman nasional (proses 100% online). |
| 12 | hasil pencarian internal | Halaman pencarian | `/cari?q=` | — | — | ✅ noindex + X-Robots-Tag (sengaja tak diindeks) |

## Aturan mutu untuk halaman baru (quality gate menegakkan di server)
1. Meta description 120–156 karakter — wajib.
2. ≥ 2 section berisi; total teks ≥ 300 karakter.
3. Menyebut regulasi/biaya resmi → wajib blok **Sumber Resmi** + tanggal review.
4. Variasi kata yang bermaksud sama → GABUNG ke halaman induk (lihat #2, #3).
5. Halaman wilayah hanya bila ada diferensiasi lokal nyata (#11).
6. Konversi di akhir: setiap halaman punya next step yang sesuai (CTA/blok terkait).

## Kebutuhan data sebelum ekspansi besar (ratusan URL)
- Search Console aktif → query yang benar-benar diklik pengguna (#90/#97 roadmap).
- Bank FAQ dari pertanyaan pelanggan asli (form/kontak) — bukan inventaris karangan.
- Bukti layanan wilayah (kantor mitra, kunjungan) sebelum halaman kota mana pun.
