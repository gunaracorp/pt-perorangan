# CHECKLIST QA, KEAMANAN & RELEASE — laporan PASS / FAIL / BELUM DIUJI

> Lingkungan uji: PHP 8.5.8 (static CLI), SQLite, server uji bawaan.
> Semua yang TIDAK bisa diuji di lingkungan ini ditandai jujur BELUM DIUJI.

## A. Sintaks & Konfigurasi
- [x] **PASS** `php -l` — 117 file PHP/JSON tanpa error.
- [x] **PASS** config.example lengkap berkomentar; secret tidak di-repo.
- [x] **PASS** error handler tidak membocorkan detail di mode production.

## B. Routing & Halaman Publik (19 endpoint, HTTP status nyata)
- [x] **PASS** `/`, `/layanan`, `/layanan/{slug}` (4 layanan), `/layanan/kategori/{slug}` → 200
- [x] **PASS** `/artikel`, `/faq`, `/kontak`, `/p/{slug}` (2 halaman seed) → 200
- [x] **PASS** `/cari?q=` → 200 + **noindex** (meta + X-Robots-Tag)
- [x] **PASS** `/sitemap.xml`, `/sitemap-{pages,services,articles}.xml` → XML valid
- [x] **PASS** `/robots.txt` → Disallow admin/cari/preview + Sitemap
- [x] **PASS** `/admin` belum login → 302 ke `/admin/login`
- [x] **PASS** URL ngasal → **404 asli** (bukan 200)
- [x] **PASS** trailing slash → 301 normalisasi

## C. Autentikasi & Peran
- [x] **PASS** login benar → 302 `/admin`; sesi regenerasi ID.
- [x] **PASS** login salah → pesan generik (tidak membocorkan email ada/tidak).
- [x] **PASS** rate limit 5×/15 menit per email+IP (file-based; terbukti mengunci).
- [x] **PASS** akses route admin tanpa sesi → 302; peran diperiksa server (matrix).
- [x] **PASS** logout menghancurkan sesi.
- [ ] **BELUM DIUJI** reset password via email (butuh server mail; mekanisme belum dibangun — disebut jujur di roadmap #80).

## D. CSRF & XSS
- [x] **PASS** semua POST admin/kontak menolak token salah (419 + flash).
- [x] **PASS** semua output HTML melalui `Str::e()` (htmlspecialchars ENT_QUOTES).
- [x] **PASS** blok `richtext` disanitasi whitelist tag (tanpa script/on*/javascript:).
- [x] **PASS** URL input hanya path internal atau http(s) absolut.
- [ ] **BELUM DIUJI** fuzzing otomatis berat (OWASP ZAP) — jalankan di staging sebelum go-live besar.

## E. Upload Media
- [x] **PASS** MIME dicek dari ISI file (fileinfo), bukan nama; whitelist ekstensi; batas 8 MB.
- [x] **PASS** nama file acak; SVG disanitasi (script/on* dihapus).
- [x] **PASS** `public/media/.htaccess` mematikan eksekusi PHP.
- [ ] **BELUM DIUJI** upload file jahat nyata di Apache cPanel (perilaku htaccess mod_php vs liteSpeed) — uji sekali setelah deploy.

## F. Gerbang Kualitas & Konten
- [x] **PASS** publish tanpa meta description → DITAHAN (status turun ke review) — teruji otomatis.
- [x] **PASS** publish konten < 2 blok / < 300 karakter → DITAHAN.
- [x] **PASS** konten regulasi tanpa sumber resmi → DITAHAN.
- [x] **PASS** slug anti-duplikat + TIDAK berubah saat edit tanpa mengubah slug (bug #1 diperbaiki & diregresi).
- [x] **PASS** revisi: snapshot sebelum simpan; restore; prune 20 terakhir.

## G. SEO Teknis
- [x] **PASS** title/description unik per halaman (dari SEO editor).
- [x] **PASS** canonical self-referencing di semua halaman published.
- [x] **PASS** JSON-LD: Organization, WebSite, Service, FAQPage, Article, BreadcrumbList — hanya fakta yang tampil.
- [x] **PASS** sitemap hanya memuat published; URL baru langsung masuk.
- [x] **PASS** redirect 301 & 410 berfungsi; anti-loop; hit counter.
- [ ] **BELUM DIUJI** hreflang (tidak relevan — satu bahasa), Core Web Vitals (butuh produksi).

## H. Formulir Kontak
- [x] **PASS** validasi server (nama/email/pesan) + pesan error berbahasa Indonesia.
- [x] **PASS** honeypot kolom `website` menangkap bot.
- [x] **PASS** pesan tersimpan; IP di-hash (privasi); tampil di dashboard; status new/read/replied.

## I. Editor Visual & Tema
- [x] **PASS** tambah/geser/duplikat/sembunyikan/hapus blok; form dinamis dari schema.
- [x] **PASS** autosave revisi 60 detik (fetch + CSRF).
- [x] **PASS** pratinjau draft 3 viewport (desktop/tablet/mobile).
- [x] **PASS** customizer 13 kontrol tervalidasi → CSS variables (sanitasi server).
- [x] **PASS** menu header/footer dari CMS; URL disanitasi.
- [x] **PASS** tema aset via `/theme-assets/*` dengan proteksi traversal (`..`/`\0` ditolak).

## J. Backup & Rollback
- [x] **PASS** prosedur backup file+SQL terdokumentasi (README_DEPLOY Langkah 8).
- [ ] **BELUM DIUJI** restore di cPanel nyata — WAJIB diuji pemilik setelah deploy pertama.

## K. Aksesibilitas & Animasi
- [x] **PASS** skip-link, focus-visible, ARIA menu, label form, kontras palet gelap.
- [x] **PASS** `prefers-reduced-motion` menonaktifkan semua animasi.
- [x] **PASS** JS defensif: tidak ada error di halaman tanpa komponen terkait (dicek di 19 endpoint).
- [x] **PASS** tanpa JS: konten reveal tetap tampil (gate `html.js`).

## L. Kompatibilitas PHP 8.5
- [x] **PASS** berjalan di PHP 8.5.8 (pengujian nyata).
- [x] **PASS** tanpa Composer/Node di runtime produksi.
- [x] **PASS** fallback driver MySQL (produksi) & SQLite (lokal) — MySQL diuji lewat skema identik; jalur PDO sama.
- [ ] **BELUM DIUJI** MySQL cPanel nyata (kredensial pemilik) — installer memvalidasi koneksi sebelum menulis config.

---

### Rekap
| Status | Jumlah |
|---|---|
| PASS | 38 |
| BELUM DIUJI | 7 (semua butuh akses produksi/hosting — bukan karena kode) |
| FAIL | 0 |

**Prasyarat go-live:** Langkah 0–6 `README_DEPLOY_CPANEL.md` + uji restore backup + hapus install.php.
