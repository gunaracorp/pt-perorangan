# LAPORAN AUDIT, MATRIKS MIGRASI & BLOCKER

> Tanggal audit: 2026-10-26 · Auditor: AI (peran software architect senior)
> Metode: verifikasi bukti, bukan asumsi — sesuai Bagian III Master Prompt.

---

## 1. Ringkasan Kondisi

| Aspek | Status | Bukti |
|---|---|---|
| Akses repository sumber `pusatperizinan/pt-perorangan` | **TERHALANG — 404/PRIVAT** | `git clone` menuntut kredensial; GitHub API `api.github.com/repos/...` = HTTP 404 (dicek 2026-10-26 00:07 UTC+8) |
| Ketersediaan PHP 8.5 (target produksi) | **TERVERIFIKASI GA** | php.net/releases: PHP 8.5.10 terbaru (27 Agustus 2026); pengujian lokal memakai PHP 8.5.8 |
| Lingkungan pengujian | **TERBANGUN** | PHP 8.5.8 static CLI + SQLite; 12 tabel; server uji; 27 tes integrasi |
| Aplikasi PHP 8.5 hasil build | **TERBANGUN & LULUS UJI** | 117 file PHP/JSON valid; 27/27 tes lulus; 3 bug nyata ditemukan & diperbaiki |

## 2. BLOCKER Utama dan Dampaknya (jujur, tanpa mengarang)

**BLOCKER-1: Repository tidak dapat diakses.**
- Dampak: inventaris halaman/komponen/animasi repo ASLI **tidak dapat dibuat**;
  matriks migrasi Next.js→PHP tidak dapat memetakan fitur nyata repo;
  animasi sumber berstatus TERHALANG (lihat ANIMATION_INVENTORY.md tabel B2).
- Langkah pemulihan: (a) buka repo jadi publik sementara, ATAU (b) kirim ZIP ke saya.
- Yang TETAP dikerjakan (tidak terblokir): seluruh fondasi aplikasi PHP 8.5, tema,
  CMS editor visual, SEO infrastruktur, dokumentasi — sesuai spesifikasi Bab I–II prompt.
- Konsekuensi jujur: saat repo diberikan, tahap AUDIT GAP (Bagian III prompt) dijalankan
  terhadap repo asli; konten seed saat ini adalah konten RIIL domain bisnis (regulasi
  terverifikasi) — bukan konten repo — dan akan disesuaikan hasil audit.

## 3. Matriks Migrasi Next.js → PHP 8.5 (kerangka siap isi + keputusan tetap)

| Aspek | Kondisi di Next.js (umum) | Padanan PHP 8.5 implementasi ini | Keterbatasan runtime | Keputusan |
|---|---|---|---|---|
| Routing (app router / pages) | file-based | `config/routes.php` + Router (front controller) | — | Explicit registry (lebih aman & terdokumentasi) |
| Server components / SSR | Node runtime | Render PHP native per request | Tidak ada proses persisten | PHP murni + file cache |
| Framer Motion / GSAP | library JS | CSS + vanilla JS (IntersectionObserver) | Hindari library berat | Paritas visual, tanpa dependensi build |
| API routes | /api/* | Controller POST + CSRF | — | Form actions + endpoint autosave |
| Database | Prisma ORM | PDO prepared statements (MySQL/SQLite) | — | Tanpa Composer di produksi |
| Env variables | .env | `config/config.php` (di luar public) | — | Privasi konsisten shared hosting |
| Asset build | npm build | Aset statis siap pakai | Tidak ada build di server | Sudah final saat upload |
| Auth middleware | middleware.ts | `Auth::requireLogin()` per controller + matrix peran | — | Pemeriksaan server-side |

**Kolom "status dalam PHP / status editor visual / cara menguji" per halaman repo:**
menunggu akses repo (terblokir). Template tersedia di LAPORAN ini §2 dan PETA_FILE §B2.

## 4. Hasil Pengujian yang Benar-Benar Dijalankan (bukan klaim)

| Pengujian | Metode | Hasil |
|---|---|---|
| Sintaks seluruh file | `php -l` PHP 8.5.8 terhadap 117 file | **PASS** (setelah 3 perbaikan) |
| Smoke test HTTP 19 endpoint | curl status code | **PASS** (200/302/404/410 sesuai rancangan) |
| Integrasi end-to-end 27 kasus | `tools/smoke-test.php` (login CSRF, gate, publish, sitemap, redirect 301/410, honeypot, noindex, JSON-LD, 404) | **27/27 PASS** |
| Rate limit login | 5 percobaan gagal → blokir | **PASS** (terbukti memblokir pengujian berikutnya) |
| Proteksi config | akses langsung config.php | **PASS** (tidak terlayani) |
| Anti path traversal aset | `AssetController` realpath guard | **PASS** (desain + uji `..` ditolak) |
| Lighthouse/Core Web Vitals | — | **BELUM DIUJI** (butuh domain produksi + SSL) |
| Uji di Apache cPanel nyata | — | **BELUM DIUJI** (butuh akses hosting; .htaccess disiapkan) |

## 5. Bug Nyata yang Ditemukan & Diperbaiki Selama Pengujian

1. **Slug berubah sendiri saat mengedit** (`-2` ditambahkan) — `collectPageData` mengabaikan ID entitas; memengaruhi Pages/Services/Articles. DIPERBAIKI + regresi lulus.
2. **QualityGate 500** saat publish (implode pada array blok). DIPERBAIKI via `BlockSchema::blocksToPlainText`.
3. **head.php undefined key** pada halaman error (og_type/canonical). DIPERBAIKI (null coalescing).
4. Router `{path}` tak menerima multi-segmen → aset tema 404. DIPERBAIKI (regex khusus `path`).

## 6. Batasan yang Diakui Terbuka

- Penjadwalan publikasi otomatis butuh cPanel Cron (pembatasan provider) — status "Terjadwal" disediakan namun eksekusinya manual/Cron opsional.
- Pengiriman email transaksional tidak dijamin di shared hosting — pesan kontak disimpan ke database (by design).
- Lighthouse/CWV belum diukur — klaim performa tidak dibuat sebelum pengukuran.
