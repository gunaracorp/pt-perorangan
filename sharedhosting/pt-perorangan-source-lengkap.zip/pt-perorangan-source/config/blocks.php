<?php
/**
 * FILE   : config/blocks.php
 * FUNGSI : Pustaka blok page builder — daftar TIPE BLOK yang diizinkan + field masing-masing.
 * UNTUK  : (1) Form editor visual admin (form dibuat dinamis dari sini),
 *          (2) Validasi server-side BlockSchema::sanitizeBlocks(),
 *          (3) Template tema di themes/pt-perorangan/templates/blocks/{type}.php.
 * KENAPA : Keamanan editor visual: hanya tipe & field terdaftar yang diterima server.
 *          Tidak ada PHP/JS mentah yang bisa disuntik lewat editor.
 * TERKAIT: app/Services/BlockSchema.php, semua admin editor, tema blocks.
 * AMAN?  : PRIVAT.
 * PEMULA : Tipe field: text (satu baris), multiline (beberapa baris), html (rich text
 *          dengan sanitasi), url, image (dari media library), select (pilihan), list (daftar).
 * JANGAN : Menambah tipe field selain yang didukung BlockSchema::sanitizeValue().
 */

return [

    'hero' => [
        'label' => 'Hero (Judul Utama)',
        'desc'  => 'Section pembuka besar: judul kuat, subjudul, dan tombol ajakan (CTA).',
        'fields' => [
            'badge'    => ['label' => 'Label kecil di atas judul', 'type' => 'text'],
            'title'    => ['label' => 'Judul utama', 'type' => 'text', 'max' => 90],
            'subtitle' => ['label' => 'Subjudul / penjelasan singkat', 'type' => 'multiline'],
            'cta_label' => ['label' => 'Teks tombol utama', 'type' => 'text'],
            'cta_url'   => ['label' => 'Tautan tombol utama', 'type' => 'url'],
            'cta2_label' => ['label' => 'Teks tombol kedua', 'type' => 'text'],
            'cta2_url'   => ['label' => 'Tautan tombol kedua', 'type' => 'url'],
            'align'    => ['label' => 'Perataan', 'type' => 'select', 'options' => ['left' => 'Kiri', 'center' => 'Tengah']],
        ],
    ],

    'features' => [
        'label' => 'Keunggulan / Fitur',
        'desc'  => 'Grid kartu keunggulan (ikon + judul + penjelasan).',
        'fields' => [
            'title'   => ['label' => 'Judul section', 'type' => 'text'],
            'subtitle'=> ['label' => 'Penjelasan singkat', 'type' => 'multiline'],
            'items'   => ['label' => 'Daftar keunggulan (satu per baris, format: Judul | Penjelasan)', 'type' => 'list'],
            'style'   => ['label' => 'Gaya kartu', 'type' => 'select', 'options' => ['glass' => 'Kaca', 'outline' => 'Garis', 'solid' => 'Padat']],
        ],
    ],

    'steps' => [
        'label' => 'Langkah Proses',
        'desc'  => 'Tahapan bernomor (prosedur pendirian, alur kerja layanan).',
        'fields' => [
            'title' => ['label' => 'Judul section', 'type' => 'text'],
            'items' => ['label' => 'Daftar langkah (satu per baris, format: Judul | Penjelasan)', 'type' => 'list'],
        ],
    ],

    'checklist' => [
        'label' => 'Syarat / Checklist Dokumen',
        'desc'  => 'Daftar persyaratan dengan tanda centang.',
        'fields' => [
            'title' => ['label' => 'Judul section', 'type' => 'text'],
            'note'  => ['label' => 'Catatan tambahan', 'type' => 'multiline'],
            'items' => ['label' => 'Daftar syarat (satu per baris)', 'type' => 'list'],
        ],
    ],

    'pricing' => [
        'label' => 'Biaya & Tarif',
        'desc'  => 'Kartu biaya: pisahkan tarif resmi pemerintah dan biaya jasa.',
        'fields' => [
            'title' => ['label' => 'Judul section', 'type' => 'text'],
            'items' => ['label' => 'Daftar komponen biaya (format: Nama | Nilai | Keterangan)', 'type' => 'list'],
            'disclaimer' => ['label' => 'Disclaimer', 'type' => 'multiline'],
        ],
    ],

    'faq' => [
        'label' => 'FAQ (Pertanyaan Umum)',
        'desc'  => 'Accordion pertanyaan-jawaban (mendukung JSON-LD FAQPage).',
        'fields' => [
            'title' => ['label' => 'Judul section', 'type' => 'text'],
            'items' => ['label' => 'Daftar FAQ (format: Pertanyaan | Jawaban)', 'type' => 'list'],
        ],
    ],

    'testimonials' => [
        'label' => 'Testimoni',
        'desc'  => 'Kutipan pelanggan ASLI dengan izin (dilarang membuat testimoni palsu).',
        'fields' => [
            'title' => ['label' => 'Judul section', 'type' => 'text'],
            'items' => ['label' => 'Daftar testimoni (format: Nama | Kutipan | Jabatan/Usaha)', 'type' => 'list'],
        ],
    ],

    'stats' => [
        'label' => 'Statistik Angka',
        'desc'  => 'Angka penting dengan animasi counter (contoh: 500+ PT didirikan).',
        'fields' => [
            'title' => ['label' => 'Judul section', 'type' => 'text'],
            'items' => ['label' => 'Daftar statistik (format: Angka | Label)', 'type' => 'list'],
        ],
    ],

    'cta' => [
        'label' => 'CTA (Ajakan Bertindak)',
        'desc'  => 'Section ajakan konsultasi (WhatsApp / formulir).',
        'fields' => [
            'title' => ['label' => 'Judul', 'type' => 'text'],
            'subtitle' => ['label' => 'Penjelasan', 'type' => 'multiline'],
            'cta_label' => ['label' => 'Teks tombol', 'type' => 'text'],
            'cta_url'   => ['label' => 'Tautan tombol', 'type' => 'url'],
        ],
    ],

    'richtext' => [
        'label' => 'Teks Bebas (Rich Text)',
        'desc'  => 'Paragraf, daftar, heading, tabel sederhana — HTML terbatas yang disanitasi.',
        'fields' => [
            'html' => ['label' => 'Konten teks', 'type' => 'html'],
        ],
    ],

    'gallery' => [
        'label' => 'Galeri Gambar',
        'desc'  => 'Grid gambar dari media library (dengan alt text).',
        'fields' => [
            'title' => ['label' => 'Judul section', 'type' => 'text'],
            'items' => ['label' => 'Daftar path gambar /media/... (satu per baris)', 'type' => 'list'],
        ],
    ],

    'sources' => [
        'label' => 'Sumber Resmi',
        'desc'  => 'Tautan referensi primer (regulasi/portal resmi) — wajib untuk konten legal.',
        'fields' => [
            'title' => ['label' => 'Judul', 'type' => 'text'],
            'items' => ['label' => 'Daftar sumber (format: Nama | URL)', 'type' => 'list'],
            'reviewed_at' => ['label' => 'Tanggal review terakhir (YYYY-MM-DD)', 'type' => 'text'],
        ],
    ],

    'contact' => [
        'label' => 'Formulir Kontak',
        'desc'  => 'Formulir pesan (nama, email, pesan) tersimpan ke dashboard admin.',
        'fields' => [
            'title'    => ['label' => 'Judul', 'type' => 'text'],
            'subtitle' => ['label' => 'Penjelasan', 'type' => 'multiline'],
        ],
    ],

    'related' => [
        'label' => 'Layanan / Artikel Terkait',
        'desc'  => 'Kartu tautan internal berdasarkan relasi konten (bukan tumpukan keyword).',
        'fields' => [
            'title' => ['label' => 'Judul', 'type' => 'text'],
            'items' => ['label' => 'Daftar tautan (format: Label | URL)', 'type' => 'list'],
        ],
    ],
];
