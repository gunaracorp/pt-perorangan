<?php
return array (
  'environment' => 'development',
  'base_url' => 'http://127.0.0.1:8099',
  'database' => 
  array (
    'driver' => 'sqlite',
    'host' => '',
    'port' => 0,
    'database' => '',
    'username' => '',
    'password' => '',
    'charset' => 'utf8mb4',
    'sqlite_path' => '/home/z/my-project/build/pt-perorangan/storage/database.sqlite',
  ),
  'security' => 
  array (
    'app_key' => '7caa69a88168097f0a200f315a02e3cc05ab2d2db50020a1b486c899ad57ccae',
    'login_max_attempts' => 5,
    'login_decay_minutes' => 15,
    'session_lifetime_minutes' => 120,
  ),
  'uploads' => 
  array (
    'max_size_mb' => 8,
    'allowed' => 
    array (
      0 => 'jpg',
      1 => 'jpeg',
      2 => 'png',
      3 => 'webp',
      4 => 'gif',
      5 => 'svg',
      6 => 'pdf',
    ),
  ),
  'features' => 
  array (
    'contact_store' => true,
    'cache_enabled' => true,
    'debug' => true,
  ),
  'theme' => 'pt-perorangan',
);
