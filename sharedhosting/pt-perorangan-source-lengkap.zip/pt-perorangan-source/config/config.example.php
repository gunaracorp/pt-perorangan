<?php
/**
 * FILE   : config/config.example.php
 * FUNGSI : Contoh konfigurasi aplikasi. Salin menjadi config.php lalu isi nilai asli.
 * UNTUK  : Menghubungkan aplikasi ke database, mengatur base URL, dan kunci keamanan.
 * KENAPA : Kredensial asli TIDAK boleh masuk repositori publik atau dibagikan.
 * TERKAIT: app/Core/bootstrap.php, app/Core/Database.php, docs/README_DEPLOY_CPANEL.md
 * AMAN?  : PRIVAT. config.php asli wajib berada di luar folder publik (lihat docs).
 * PEMULA : Anda hanya perlu mengedit file ini SATU KALI saat instalasi (atau biarkan
 *          installer web public/install.php membuatnya otomatis).
 * JANGAN : Membagikan isi file ini, meng-commit ke GitHub, atau menaruhnya di public/.
 */

return [
    // Lingkungan: 'production' di hosting cPanel, 'development' saat mencoba di komputer lokal.
    'environment' => 'production',

    // URL situs tanpa garis miring di akhir. Contoh: https://ptperorangan.com
    'base_url' => 'https://contoh-domain-anda.com',

    // --- Database (MySQL cPanel) ---
    'database' => [
        'driver'   => 'mysql',      // 'mysql' untuk cPanel; 'sqlite' untuk uji lokal
        'host'     => 'localhost',  // di cPanel biasanya 'localhost'
        'port'     => 3306,
        'database' => 'cpaneluser_ptperorangan',
        'username' => 'cpaneluser_admin',
        'password' => 'ISI_PASSWORD_DB_ANDA',
        'charset'  => 'utf8mb4',
        // Lokasi file SQLite (hanya dipakai bila driver = sqlite).
        'sqlite_path' => __DIR__ . '/../storage/database.sqlite',
    ],

    // --- Keamanan ---
    'security' => [
        // APP_KEY: string acak panjang. Contoh pembuatan (di komputer lokal):
        //   php -r "echo bin2hex(random_bytes(32));"
        'app_key' => 'GANTI_DENGAN_STRING_ACAK_64_KARAKTER',
        // Maksimal percobaan login: 5 kali dalam 15 menit per email/IP.
        'login_max_attempts'   => 5,
        'login_decay_minutes'  => 15,
        // Sesi admin kedaluwarsa setelah 120 menit tidak aktif.
        'session_lifetime_minutes' => 120,
    ],

    // --- Upload media ---
    'uploads' => [
        'max_size_mb' => 8,
        // Ekstensi yang diizinkan. Tambahkan hanya yang benar-benar dibutuhkan.
        'allowed' => ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'pdf'],
    ],

    // --- Fitur opsional ---
    'features' => [
        'contact_store' => true,   // simpan pesan kontak ke database (tanpa server email)
        'cache_enabled' => true,   // cache halaman publik (file cache di storage/cache)
        'debug'         => false,  // JANGAN true di produksi (bocorkan detail error)
    ],

    // --- Tema aktif ---
    'theme' => 'pt-perorangan',
];
