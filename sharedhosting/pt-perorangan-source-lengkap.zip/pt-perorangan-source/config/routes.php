<?php
/**
 * FILE   : config/routes.php
 * FUNGSI : PETA SEMUA URL aplikasi (route registry) — publik, teknis, dan admin.
 * UNTUK  : Dipanggil App::run(). Satu tempat untuk melihat seluruh URL.
 * KENAPA : URL dikelola eksplisit & konsisten (fondasi SEO + keamanan).
 * TERKAIT: app/Core/App.php, app/Core/Router.php
 * AMAN?  : PRIVAT.
 * PEMULA : Route admin SELALU lewat Auth::requireLogin() di controllernya —
 *          bukan keamanan di sini.
 * JANGAN : Menambah route tanpa controller yang memeriksa izin.
 */

use App\Core\Router;
use App\Controllers\HomeController;
use App\Controllers\PageController;
use App\Controllers\ServiceController;
use App\Controllers\ArticleController;
use App\Controllers\FaqController;
use App\Controllers\ContactController;
use App\Controllers\SearchController;
use App\Controllers\SitemapController;
use App\Controllers\AssetController;
use App\Controllers\Admin\AuthController;
use App\Controllers\Admin\DashboardController;
use App\Controllers\Admin\PagesController;
use App\Controllers\Admin\ServicesController;
use App\Controllers\Admin\ArticlesController;
use App\Controllers\Admin\FaqController as AdminFaqController;
use App\Controllers\Admin\CategoriesController;
use App\Controllers\Admin\MediaController;
use App\Controllers\Admin\MenusController;
use App\Controllers\Admin\ThemeController;
use App\Controllers\Admin\SeoController;
use App\Controllers\Admin\ImportController;
use App\Controllers\Admin\UsersController;
use App\Controllers\Admin\SettingsController;
use App\Controllers\Admin\MessagesController;

return static function (Router $r): void {

    // ---------- ASET TEMA (dilayani PHP dengan proteksi path traversal) ----------
    $r->get('/theme-assets/{path}', [AssetController::class, 'serve']);

    // ---------- HALAMAN PUBLIK ----------
    $r->get('/', [HomeController::class, 'index']);
    $r->get('/layanan', [ServiceController::class, 'index']);
    $r->get('/layanan/kategori/{slug}', [ServiceController::class, 'category']);
    $r->get('/layanan/{slug}', [ServiceController::class, 'show']);
    $r->get('/artikel', [ArticleController::class, 'index']);
    $r->get('/artikel/{slug}', [ArticleController::class, 'show']);
    $r->get('/faq', [FaqController::class, 'index']);
    $r->get('/kontak', [ContactController::class, 'index']);
    $r->post('/kontak', [ContactController::class, 'submit']);
    $r->get('/cari', [SearchController::class, 'index']);
    $r->get('/p/{slug}', [PageController::class, 'show']);

    // ---------- TEKNIS SEO ----------
    $r->get('/sitemap.xml', [SitemapController::class, 'index']);
    $r->get('/sitemap-pages.xml', [SitemapController::class, 'pages']);
    $r->get('/sitemap-services.xml', [SitemapController::class, 'services']);
    $r->get('/sitemap-articles.xml', [SitemapController::class, 'articles']);
    $r->get('/robots.txt', [SitemapController::class, 'robots']);

    // ---------- ADMIN: AUTH ----------
    $r->get('/admin/login', [AuthController::class, 'showLogin']);
    $r->post('/admin/login', [AuthController::class, 'login']);
    $r->get('/admin/logout', [AuthController::class, 'logout']);

    // ---------- ADMIN: DASBOR ----------
    $r->get('/admin', [DashboardController::class, 'index']);

    // ---------- ADMIN: HALAMAN (page builder) ----------
    $r->get('/admin/halaman', [PagesController::class, 'index']);
    $r->get('/admin/halaman/baru', [PagesController::class, 'create']);
    $r->post('/admin/halaman/baru', [PagesController::class, 'store']);
    $r->get('/admin/halaman/{id}/edit', [PagesController::class, 'edit']);
    $r->post('/admin/halaman/{id}/simpan', [PagesController::class, 'update']);
    $r->post('/admin/halaman/{id}/hapus', [PagesController::class, 'destroy']);
    $r->get('/admin/halaman/{id}/pratinjau', [PagesController::class, 'preview']);
    $r->post('/admin/halaman/{id}/revisi/{rid}/pulihkan', [PagesController::class, 'restoreRevision']);
    $r->get('/admin/halaman/{id}/revisi', [PagesController::class, 'revisions']);
    // Endpoint autosave (fetch dari editor visual)
    $r->post('/admin/halaman/{id}/autosave', [PagesController::class, 'autosave']);

    // ---------- ADMIN: LAYANAN ----------
    $r->get('/admin/layanan', [ServicesController::class, 'index']);
    $r->get('/admin/layanan/baru', [ServicesController::class, 'create']);
    $r->post('/admin/layanan/baru', [ServicesController::class, 'store']);
    $r->get('/admin/layanan/{id}/edit', [ServicesController::class, 'edit']);
    $r->post('/admin/layanan/{id}/simpan', [ServicesController::class, 'update']);
    $r->post('/admin/layanan/{id}/hapus', [ServicesController::class, 'destroy']);
    $r->get('/admin/layanan/{id}/pratinjau', [ServicesController::class, 'preview']);

    // ---------- ADMIN: KATEGORI ----------
    $r->get('/admin/kategori', [CategoriesController::class, 'index']);
    $r->post('/admin/kategori', [CategoriesController::class, 'store']);
    $r->post('/admin/kategori/{id}/hapus', [CategoriesController::class, 'destroy']);

    // ---------- ADMIN: ARTIKEL ----------
    $r->get('/admin/artikel', [ArticlesController::class, 'index']);
    $r->get('/admin/artikel/baru', [ArticlesController::class, 'create']);
    $r->post('/admin/artikel/baru', [ArticlesController::class, 'store']);
    $r->get('/admin/artikel/{id}/edit', [ArticlesController::class, 'edit']);
    $r->post('/admin/artikel/{id}/simpan', [ArticlesController::class, 'update']);
    $r->post('/admin/artikel/{id}/hapus', [ArticlesController::class, 'destroy']);
    $r->get('/admin/artikel/{id}/pratinjau', [ArticlesController::class, 'preview']);

    // ---------- ADMIN: FAQ ----------
    $r->get('/admin/faq', [AdminFaqController::class, 'index']);
    $r->post('/admin/faq', [AdminFaqController::class, 'store']);
    $r->post('/admin/faq/{id}/hapus', [AdminFaqController::class, 'destroy']);

    // ---------- ADMIN: MEDIA ----------
    $r->get('/admin/media', [MediaController::class, 'index']);
    $r->post('/admin/media', [MediaController::class, 'upload']);
    $r->post('/admin/media/{id}/simpan', [MediaController::class, 'update']);
    $r->post('/admin/media/{id}/hapus', [MediaController::class, 'destroy']);

    // ---------- ADMIN: MENU ----------
    $r->get('/admin/menu', [MenusController::class, 'index']);
    $r->post('/admin/menu', [MenusController::class, 'save']);

    // ---------- ADMIN: TEMA (customizer) ----------
    $r->get('/admin/tema', [ThemeController::class, 'index']);
    $r->post('/admin/tema', [ThemeController::class, 'save']);

    // ---------- ADMIN: SEO (redirect + sitemap) ----------
    $r->get('/admin/seo', [SeoController::class, 'index']);
    $r->post('/admin/seo/redirect', [SeoController::class, 'addRedirect']);
    $r->post('/admin/seo/redirect/{id}/hapus', [SeoController::class, 'deleteRedirect']);
    $r->post('/admin/seo/sitemap-bersihkan-cache', [SeoController::class, 'flushSitemap']);

    // ---------- ADMIN: IMPOR MASSAL ----------
    $r->get('/admin/impor', [ImportController::class, 'index']);
    $r->post('/admin/impor', [ImportController::class, 'run']);

    // ---------- ADMIN: PENGGUNA ----------
    $r->get('/admin/pengguna', [UsersController::class, 'index']);
    $r->post('/admin/pengguna', [UsersController::class, 'store']);
    $r->post('/admin/pengguna/{id}/hapus', [UsersController::class, 'destroy']);

    // ---------- ADMIN: PENGATURAN ----------
    $r->get('/admin/pengaturan', [SettingsController::class, 'index']);
    $r->post('/admin/pengaturan', [SettingsController::class, 'save']);

    // ---------- ADMIN: PESAN KONTAK ----------
    $r->get('/admin/pesan', [MessagesController::class, 'index']);
    $r->post('/admin/pesan/{id}/status', [MessagesController::class, 'setStatus']);
    $r->post('/admin/pesan/{id}/hapus', [MessagesController::class, 'destroy']);
};
