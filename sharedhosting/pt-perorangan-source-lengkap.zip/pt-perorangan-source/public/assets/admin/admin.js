/**
 * FILE   : public/assets/admin/admin.js
 * FUNGSI : Logika dashboard admin + EDITOR VISUAL (page builder).
 * UNTUK  : - Membangun UI blok dinamis dari schema (config/blocks.php via JSON).
 *          - Tambah/geser/duplikat/sembunyikan/hapus blok, edit field per blok.
 *          - Autosave revisi (fetch POST) + status, viewport pratinjau,
 *            konfirmasi hapus, editor menu dinamis.
 * KENAPA : Semua perubahan dikirim sebagai JSON di <input name="blocks"> —
 *          server TETAP menyaring ulang via BlockSchema (UI bukan keamanan).
 * AMAN?  : PUBLIK (file statis). Tidak ada data sensitif; CSRF dikirim server-side.
 * PEMULA : File ini "otak" editor visual. Tidak perlu diedit untuk pemakaian normal.
 */
(function () {
  'use strict';

  /* ================= UTIL ================= */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* Konfirmasi hapus semua form ber-atribut data-confirm */
  function initConfirms() {
    $$('form[data-confirm]').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        if (!window.confirm(form.getAttribute('data-confirm'))) e.preventDefault();
      });
    });
  }

  /* Flash auto-hide */
  function initFlashes() {
    $$('.admin-flash').forEach(function (el) {
      setTimeout(function () {
        el.style.transition = 'opacity .5s';
        el.style.opacity = '0';
        setTimeout(function () { el.remove(); }, 500);
      }, 6000);
    });
  }

  /* ================= EDITOR VISUAL (page builder) ================= */
  var editor = {
    blocks: [],       // [{type, hidden, data:{...}}]
    defs: {},         // schema dari server
    form: null,
    listEl: null,
    input: null,
    pageId: 0,
    dirty: false,
    autosaveTimer: null
  };

  function initEditor() {
    editor.listEl = $('#blockList');
    editor.input = $('#blocksInput');
    editor.form = $('#editorForm') || (editor.input && editor.input.closest('form'));
    if (!editor.listEl || !editor.input || !editor.form) return; // halaman tanpa editor → keluar defensif

    var defsEl = $('#blockDefsJson');
    var initEl = $('#initialBlocks');
    try { editor.defs = JSON.parse(defsEl ? defsEl.textContent : '{}') || {}; } catch (e) { editor.defs = {}; }
    try { editor.blocks = JSON.parse(initEl ? initEl.textContent : '[]') || []; } catch (e) { editor.blocks = []; }

    editor.pageId = parseInt(editor.form.getAttribute('action') || '', 10) || 0;
    var m = (editor.form.getAttribute('action') || '').match(/\/(halaman|layanan|artikel)\/(\d+)\//);
    if (m) editor.pageId = parseInt(m[2], 10);

    renderAll();

    // Tambah blok baru
    var addBtn = $('#addBlockBtn');
    var addSel = $('#addBlockType');
    if (addBtn && addSel) {
      addBtn.addEventListener('click', function () {
        var type = addSel.value;
        if (!type || !editor.defs[type]) { alert('Pilih jenis section terlebih dahulu.'); return; }
        editor.blocks.push({ type: type, hidden: false, data: defaultsFor(type) });
        renderAll();
        markDirty();
        // buka blok terakhir
        var items = $$('.block-item', editor.listEl);
        if (items.length) {
          var last = items[items.length - 1];
          last.classList.add('open');
          var head = $('.block-item-head', last);
          if (head) head.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        addSel.value = '';
      });
    }

    // Submit: kirim JSON blok
    editor.form.addEventListener('submit', function () {
      editor.input.value = JSON.stringify(editor.blocks);
      stopAutosave();
    });

    initAutosave();
  }

  function defaultsFor(type) {
    var def = editor.defs[type];
    var data = {};
    if (!def) return data;
    Object.keys(def.fields || {}).forEach(function (f) {
      data[f] = def.fields[f].type === 'list' ? [] : (def.fields[f].type === 'boolean' ? false : '');
    });
    return data;
  }

  function renderAll() {
    editor.listEl.innerHTML = '';
    editor.blocks.forEach(function (block, idx) {
      editor.listEl.appendChild(renderBlockItem(block, idx));
    });
    editor.input.value = JSON.stringify(editor.blocks);
  }

  function renderBlockItem(block, idx) {
    var def = editor.defs[block.type] || { label: block.type, fields: {}, desc: '' };
    var wrap = document.createElement('div');
    wrap.className = 'block-item' + (block.hidden ? ' is-hidden' : '');
    wrap.innerHTML =
      '<div class="block-item-head" role="button" tabindex="0" aria-expanded="false">' +
        '<span>' + esc(def.label) + ' <span class="block-type">' + esc(block.type) + '</span></span>' +
        '<span class="block-item-tools">' +
          '<button type="button" class="tool-btn" data-act="up" title="Geser ke atas">↑</button>' +
          '<button type="button" class="tool-btn" data-act="down" title="Geser ke bawah">↓</button>' +
          '<button type="button" class="tool-btn" data-act="dup" title="Duplikat">⧉</button>' +
          '<button type="button" class="tool-btn' + (block.hidden ? ' eye-off' : '') + '" data-act="hide" title="Sembunyikan/Tampilkan">' + (block.hidden ? '🚫' : '👁') + '</button>' +
          '<button type="button" class="tool-btn" data-act="del" title="Hapus">✕</button>' +
        '</span>' +
      '</div>' +
      '<div class="block-item-body"><p class="hint">' + esc(def.desc || '') + '</p></div>';

    var body = $('.block-item-body', wrap);

    // Buka/tutup
    var head = $('.block-item-head', wrap);
    function toggle() {
      var open = wrap.classList.toggle('open');
      head.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    head.addEventListener('click', function (e) {
      if (e.target.closest('.tool-btn')) return;
      toggle();
    });
    head.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });

    // Tool buttons
    $$('.tool-btn', wrap).forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var act = btn.getAttribute('data-act');
        if (act === 'up' && idx > 0) {
          editor.blocks.splice(idx - 1, 0, editor.blocks.splice(idx, 1)[0]);
        } else if (act === 'down' && idx < editor.blocks.length - 1) {
          editor.blocks.splice(idx + 1, 0, editor.blocks.splice(idx, 1)[0]);
        } else if (act === 'dup') {
          editor.blocks.splice(idx + 1, 0, JSON.parse(JSON.stringify(block)));
        } else if (act === 'hide') {
          block.hidden = !block.hidden;
        } else if (act === 'del') {
          if (window.confirm('Hapus section ini dari halaman?')) {
            editor.blocks.splice(idx, 1);
          } else { return; }
        }
        renderAll();
        markDirty();
      });
    });

    // Field forms sesuai schema
    Object.keys(def.fields || {}).forEach(function (fieldName) {
      var meta = def.fields[fieldName];
      var value = block.data[fieldName] !== undefined ? block.data[fieldName] : '';
      var id = 'f-' + idx + '-' + fieldName;
      var row = document.createElement('div');
      row.className = 'form-row';

      if (meta.type === 'html') {
        row.innerHTML = '<label for="' + id + '">' + esc(meta.label) + ' <span class="hint">(HTML terbatas: p, h2-h4, ul/ol/li, b, i, a — disanitasi server)</span></label>' +
          '<textarea id="' + id + '" rows="6" data-field="' + esc(fieldName) + '">' + esc(value) + '</textarea>';
      } else if (meta.type === 'multiline') {
        row.innerHTML = '<label for="' + id + '">' + esc(meta.label) + '</label>' +
          '<textarea id="' + id + '" rows="3" data-field="' + esc(fieldName) + '">' + esc(value) + '</textarea>';
      } else if (meta.type === 'select') {
        var opts = Object.keys(meta.options || {}).map(function (v) {
          return '<option value="' + esc(v) + '"' + (value === v ? ' selected' : '') + '>' + esc(meta.options[v]) + '</option>';
        }).join('');
        row.innerHTML = '<label for="' + id + '">' + esc(meta.label) + '</label>' +
          '<select id="' + id + '" data-field="' + esc(fieldName) + '">' + opts + '</select>';
      } else if (meta.type === 'list') {
        var items = Array.isArray(value) ? value : [];
        var listRows = items.map(function (it) {
          return '<div class="menu-row"><input type="text" value="' + esc(it) + '" data-list-field="' + esc(fieldName) + '"><button type="button" class="tool-btn list-remove">✕</button></div>';
        }).join('');
        row.innerHTML = '<label>' + esc(meta.label) + '</label>' +
          '<div class="menu-rows list-rows" data-list="' + esc(fieldName) + '">' + listRows + '</div>' +
          '<button type="button" class="btn btn-ghost btn-sm list-add" data-list="' + esc(fieldName) + '">+ Baris</button>';
      } else {
        row.innerHTML = '<label for="' + id + '">' + esc(meta.label) + '</label>' +
          '<input id="' + id + '" type="text" value="' + esc(value) + '" data-field="' + esc(fieldName) + '" maxlength="' + (meta.max ? parseInt(meta.max, 10) : 300) + '">';
      }
      body.appendChild(row);
    });

    // Bind perubahan field sederhana
    $$('[data-field]', body).forEach(function (input) {
      input.addEventListener('input', function () {
        block.data[input.getAttribute('data-field')] = input.value;
        markDirty();
      });
    });

    // Bind list add/remove/input
    $$('.list-add', body).forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-list');
        block.data[key] = block.data[key] || [];
        block.data[key].push('');
        renderAll();
        markDirty();
      });
    });
    $$('.list-remove', body).forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.closest('.list-rows').getAttribute('data-list');
        var input = $('input', btn.closest('.menu-row'));
        var items = block.data[key] || [];
        var i = $$('.menu-row', btn.closest('.list-rows')).indexOf(btn.closest('.menu-row'));
        if (i > -1) items.splice(i, 1);
        block.data[key] = items;
        renderAll();
        markDirty();
      });
    });
    $$('[data-list-field]', body).forEach(function (input) {
      input.addEventListener('input', function () {
        var key = input.getAttribute('data-list-field');
        var rows = $$('.menu-row input', input.closest('.list-rows'));
        var i = rows.indexOf(input);
        block.data[key] = block.data[key] || [];
        block.data[key][i] = input.value;
        markDirty();
      });
    });

    return wrap;
  }

  /* ================= AUTOSAVE (revisi) ================= */
  function initAutosave() {
    var statusEl = $('#autosaveStatus');
    if (!editor.pageId || !statusEl) return;

    editor.autosaveTimer = window.setInterval(function () {
      if (!editor.dirty) return;
      var csrf = editor.form.querySelector('input[name="_csrf"]');
      if (!csrf) return;

      var body = new URLSearchParams();
      body.set('_csrf', csrf.value);
      body.set('blocks', JSON.stringify(editor.blocks));

      fetch('/admin/halaman/' + editor.pageId + '/autosave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
        credentials: 'same-origin'
      }).then(function (res) { return res.json(); }).then(function (json) {
        editor.dirty = false;
        if (json && json.ok) {
          statusEl.textContent = '✓ Salinan sementara tersimpan otomatis pukul ' + json.saved_at;
        } else {
          statusEl.textContent = '⚠️ Autosave gagal — perubahan Anda tetap aman di formulir ini.';
        }
      }).catch(function () {
        statusEl.textContent = '⚠️ Autosave tertunda (jaringan). Perubahan tetap aman di formulir.';
      });
    }, 60000);
  }
  function markDirty() { editor.dirty = true; }
  function stopAutosave() { if (editor.autosaveTimer) window.clearInterval(editor.autosaveTimer); }

  /* ================= PRATINJAU VIEWPORT ================= */
  function initViewports() {
    var wrap = $('#previewWrap');
    if (!wrap) return;
    $$('.viewport-switch button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $$('.viewport-switch button').forEach(function (b) {
          b.classList.remove('active');
          b.setAttribute('aria-pressed', 'false');
        });
        btn.classList.add('active');
        btn.setAttribute('aria-pressed', 'true');
        var vp = btn.getAttribute('data-vp');
        wrap.classList.remove('vp-tablet', 'vp-mobile');
        if (vp === 'tablet') wrap.classList.add('vp-tablet');
        if (vp === 'mobile') wrap.classList.add('vp-mobile');
      });
    });
  }

  /* ================= MENU EDITOR ================= */
  function initMenuEditor() {
    $$('.add-menu-row').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var target = btn.getAttribute('data-target');
        var card = btn.closest('.admin-card');
        var rows = $('.menu-rows', card);
        var row = document.createElement('div');
        row.className = 'menu-row';
        row.innerHTML =
          '<input type="text" name="' + esc(target) + '_label[]" placeholder="Label" maxlength="60" aria-label="Label tautan">' +
          '<input type="text" name="' + esc(target) + '_url[]" placeholder="/layanan atau https://..." maxlength="300" aria-label="URL tautan">' +
          '<button type="button" class="tool-btn remove-row" aria-label="Hapus baris">✕</button>';
        rows.appendChild(row);
        bindRemove(row);
      });
    });
    function bindRemove(scope) {
      $$('.remove-row', scope || document).forEach(function (btn) {
        if (btn.getAttribute('data-bound')) return;
        btn.setAttribute('data-bound', '1');
        btn.addEventListener('click', function () {
          btn.closest('.menu-row').remove();
        });
      });
    }
    bindRemove();
  }

  /* ================= BOOT ================= */
  function boot() {
    [initConfirms, initFlashes, initEditor, initViewports, initMenuEditor].forEach(function (fn) {
      try { fn(); } catch (err) {
        if (window.console && console.warn) console.warn('admin init gagal:', fn.name, err);
      }
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
