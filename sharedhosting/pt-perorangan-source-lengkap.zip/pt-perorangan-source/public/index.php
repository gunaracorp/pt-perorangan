<?php
/**
 * FILE   : public/index.php
 * FUNGSI : SATU-SATUNYA titik masuk aplikasi di document root (front controller).
 * UNTUK  : Semua URL publik & admin dialihkan ke sini oleh .htaccess.
 * KENAPA : Pola front controller = keamanan (folder app/config tidak pernah bisa
 *          diakses browser langsung) + routing konsisten.
 * TERKAIT: app/Core/bootstrap.php → app/Core/App.php → config/routes.php
 * AMAN?  : PUBLIK (memang untuk browser).
 * PEMULA : Di cPanel, folder "public/" inilah yang dijadikan document root
 *          (atau seluruh proyek di subfolder + .htaccess root — lihat tutorial).
 */

declare(strict_types=1);

// Lindungi dari header aneh saat di-hosting di belakang proxy cPanel.
if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__DIR__));
}

require APP_ROOT . '/app/Core/bootstrap.php';

// Jika aplikasi belum terpasang → arahkan ke installer.
if (!is_file(CONFIG_DIR . '/config.php')) {
    if (basename($_SERVER['SCRIPT_NAME'] ?? '') !== 'install.php') {
        $wantsJson = str_contains($_SERVER['REQUEST_URI'] ?? '', '.xml') || str_contains($_SERVER['REQUEST_URI'] ?? '', '.txt');
        if ($wantsJson) {
            http_response_code(503);
            exit('Aplikasi belum terpasang.');
        }
        header('Location: /install.php');
        exit;
    }
}

App\Core\App::run();
