<?php
/**
 * FILE   : tools/router-dev.php
 * FUNGSI : Router khusus PHP built-in server (PENGUJIAN LOKAL SAJA, bukan produksi).
 * UNTUK  : `php -S 127.0.0.1:8099 router-dev.php` dari folder public/.
 * KENAPA : Built-in server tidak membaca .htaccess; file ini menggantikan perannya
 *          dengan perilaku yang sama (file asli dilayani, sisanya ke index.php).
 * AMAN?  : PRIVAT — tidak perlu diunggah ke hosting cPanel.
 */

declare(strict_types=1);

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$file = __DIR__ . '/' . $path;

if ($path !== '/' && is_file($file)) {
    // Sajikan file statis dengan MIME benar.
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $mime = match ($ext) {
        'css' => 'text/css; charset=UTF-8',
        'js' => 'application/javascript; charset=UTF-8',
        'svg' => 'image/svg+xml',
        'png' => 'image/png',
        'jpg', 'jpeg' => 'image/jpeg',
        'webp' => 'image/webp',
        'gif' => 'image/gif',
        'ico' => 'image/x-icon',
        default => 'application/octet-stream',
    };
    header('Content-Type: ' . $mime);
    readfile($file);
    return true;
}

// Semua request lain → front controller (hanya GET/POST seperti hosting umum).
$_SERVER['SCRIPT_NAME'] = '/index.php';
require __DIR__ . '/index.php';
return true;
