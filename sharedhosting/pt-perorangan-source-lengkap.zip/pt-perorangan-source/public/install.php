<?php
/**
 * FILE   : public/install.php
 * FUNGSI : Installer web 4 langkah untuk PEMULA TANPA TERMINAL:
 *          (1) cek server, (2) isi database, (3) buat akun admin,
 *          (4) buat tabel + seed konten awal + tulis config.php.
 * UNTUK  : Dibuka sekali di browser saat pertama deploy; otomatis MENYENDIRI DIRI
 *          (mengganti dirinya dengan halaman "sudah terpasang") setelah sukses.
 * KENAPA : Memenuhi aturan: pemula tidak boleh diminta menjalankan perintah terminal.
 * AMAN?  : WAJIB DIHAPUS/DILOCK setelah instalasi (file akan self-lock sendiri).
 * PEMULA : Jika halaman ini terbuka padahal situs sudah jalan, berarti instalasi
 *          selesai tapi installer belum terkunci — klik tombol "Kunci Installer".
 */

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');

define('APP_ROOT', dirname(__DIR__));
require APP_ROOT . '/app/Core/bootstrap.php';

use App\Core\Database;
use App\Models\User;
use App\Models\Page;
use App\Models\Service;
use App\Models\Category;
use App\Models\Faq;
use App\Models\Menu;
use App\Models\Setting;
use App\Core\Str;

session_name('ptper_install');
session_start();

$lockFile = APP_ROOT . '/config/.installed';
$alreadyInstalled = is_file(CONFIG_DIR . '/config.php') || is_file($lockFile);

/* ---------- Cek lingkungan ---------- */
$phpOk = version_compare(PHP_VERSION, '8.5.0', '>=');
$neededExtensions = ['pdo', 'mbstring', 'json', 'fileinfo', 'openssl', 'gd'];
$missingExt = array_values(array_filter($neededExtensions, static fn($e) => !extension_loaded($e)));
$storageWritable = is_writable(STORAGE_DIR) || @mkdir(STORAGE_DIR, 0755, true);
$configWritable = is_writable(CONFIG_DIR) || is_writable(APP_ROOT . '/public');
$mediaWritable = is_writable(PUBLIC_DIR . '/media') || @mkdir(PUBLIC_DIR . '/media', 0755, true);

$errors = [];
if (!$phpOk) {
    $errors[] = 'PHP ' . PHP_VERSION . ' terdeteksi. Proyek ini WAJIB PHP 8.5.x — minta penyedia hosting mengaktifkan PHP 8.5 (cPanel → Select PHP Version). JANGAN lanjut dengan versi lebih rendah.';
}
if ($missingExt !== []) {
    $errors[] = 'Ekstensi PHP belum aktif: ' . implode(', ', $missingExt) . '. Aktifkan via cPanel → Select PHP Version → Extensions.';
}
if (!$storageWritable) {
    $errors[] = 'Folder storage/ tidak dapat ditulis. Set permission 755 (atau 775) via cPanel File Manager.';
}

/* ---------- Proses form instalasi ---------- */
$step = 'server';
$done = false;

if (!$alreadyInstalled && $errors === [] && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $dbDriver = ($_POST['db_driver'] ?? 'mysql') === 'sqlite' ? 'sqlite' : 'mysql';
    $baseUrl = rtrim(trim((string) ($_POST['base_url'] ?? '')), '/');
    if ($baseUrl !== '' && !preg_match('~^https?://~', $baseUrl)) {
        $baseUrl = 'https://' . $baseUrl;
    }
    $adminName = Str::clean((string) ($_POST['admin_name'] ?? ''));
    $adminEmail = mb_strtolower(Str::clean((string) ($_POST['admin_email'] ?? '')));
    $adminPass = (string) ($_POST['admin_password'] ?? '');
    $adminPass2 = (string) ($_POST['admin_password2'] ?? '');

    if ($baseUrl === '') {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $baseUrl = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }

    if ($adminName === '' || !filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Nama dan email admin wajib diisi dengan benar.';
    }
    if (mb_strlen($adminPass) < 12) {
        $errors[] = 'Kata sandi admin minimal 12 karakter (disarankan frasa panjang yang mudah diingat).';
    }
    if ($adminPass !== $adminPass2) {
        $errors[] = 'Konfirmasi kata sandi tidak sama.';
    }

    if ($errors === []) {
        try {
            // 1. Tulis config.php
            $appKey = bin2hex(random_bytes(32));
            $config = [
                'environment' => 'production',
                'base_url' => $baseUrl,
                'database' => [
                    'driver'      => $dbDriver,
                    'host'        => Str::clean((string) ($_POST['db_host'] ?? 'localhost')),
                    'port'        => (int) ($_POST['db_port'] ?? 3306),
                    'database'    => Str::clean((string) ($_POST['db_name'] ?? '')),
                    'username'    => Str::clean((string) ($_POST['db_user'] ?? '')),
                    'password'    => (string) ($_POST['db_pass'] ?? ''),
                    'charset'     => 'utf8mb4',
                    'sqlite_path' => STORAGE_DIR . '/database.sqlite',
                ],
                'security' => [
                    'app_key'                  => $appKey,
                    'login_max_attempts'       => 5,
                    'login_decay_minutes'      => 15,
                    'session_lifetime_minutes' => 120,
                ],
                'uploads' => [
                    'max_size_mb' => 8,
                    'allowed'     => ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'pdf'],
                ],
                'features' => [
                    'contact_store' => true,
                    'cache_enabled' => true,
                    'debug'         => false,
                ],
                'theme' => 'pt-perorangan',
            ];

            // Uji koneksi dulu sebelum menulis config (mysql saja).
            $GLOBALS['__APP_CONFIG'] = $config;
            Database::pdo(); // melempar bila gagal

            $configPhp = "<?php\n// DIBUAT OLEH INSTALLER " . date('c') . "\n// PRIVAT: jangan dibagikan / di-commit.\nreturn " . var_export($config, true) . ";\n";
            if (@file_put_contents(CONFIG_DIR . '/config.php', $configPhp, LOCK_EX) === false) {
                throw new RuntimeException('Gagal menulis config/config.php. Periksa permission folder config/ (755).');
            }

            // 2. Buat tabel
            if ($dbDriver === 'sqlite') {
                $schema = require APP_ROOT . '/database/schema.sqlite.php';
                foreach ($schema as $ddl) {
                    Database::run($ddl);
                }
            } else {
                $sql = (string) file_get_contents(APP_ROOT . '/database/schema.mysql.sql');
                foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
                    if ($stmt !== '' && !str_starts_with($stmt, '--') && str_starts_with($stmt, 'CREATE')) {
                        Database::run($stmt);
                    }
                }
            }

            // 3. Akun admin (owner)
            $adminId = User::create($adminName, $adminEmail, $adminPass, 'owner');

            // 4. Seed konten awal dari content/*.json
            seedContent($adminId);

            // 5. Lock installer
            @file_put_contents($lockFile, date('c'));
            @file_put_contents(__FILE__, "<?php\n// Installer telah dipakai dan terkunci pada " . date('c') . "\nhttp_response_code(410);\nexit('Installer sudah digunakan. Untuk keamanan, hapus file install.php ini via cPanel File Manager.');\n");
            $done = true;
        } catch (Throwable $e) {
            $errors[] = 'Instalasi gagal: ' . $e->getMessage();
            // Hapus config parsial agar bisa dicoba lagi
            if (is_file(CONFIG_DIR . '/config.php')) {
                @unlink(CONFIG_DIR . '/config.php');
            }
        }
    }
}

/** Seed konten awal dari folder content/. */
function seedContent(int $adminId): void
{
    $now = date('Y-m-d H:i:s');
    $read = static function (string $name): array {
        $f = CONTENT_DIR . '/' . $name;
        return is_file($f) ? (json_decode((string) file_get_contents($f), true) ?: []) : [];
    };

    // Kategori
    $catIds = [];
    foreach ($read('categories.json') as $c) {
        $id = Category::insert([
            'name' => (string) $c['name'], 'slug' => (string) $c['slug'],
            'description' => (string) ($c['description'] ?? ''),
            'seo' => json_encode(['title' => $c['name'], 'description' => $c['description'] ?? ''], JSON_UNESCAPED_UNICODE),
            'status' => 'published', 'sort_order' => (int) ($c['sort_order'] ?? 10),
            'created_at' => $now, 'updated_at' => $now,
        ]);
        $catIds[$c['slug']] = $id;
    }

    // Layanan
    foreach ($read('services.json') as $s) {
        Service::insert([
            'title' => (string) $s['title'], 'slug' => (string) $s['slug'],
            'excerpt' => (string) ($s['excerpt'] ?? ''),
            'blocks' => json_encode($s['blocks'] ?? [], JSON_UNESCAPED_UNICODE),
            'seo' => json_encode($s['seo'] ?? [], JSON_UNESCAPED_UNICODE),
            'facts' => json_encode($s['facts'] ?? [], JSON_UNESCAPED_UNICODE),
            'category_id' => $catIds[(string) ($s['category'] ?? '')] ?? null,
            'featured' => (int) ($s['featured'] ?? 0),
            'status' => 'published', 'published_at' => $now,
            'sort_order' => (int) ($s['sort_order'] ?? 100),
            'updated_by' => $adminId, 'created_at' => $now, 'updated_at' => $now,
        ]);
    }

    // Halaman
    foreach ($read('pages.json') as $p) {
        Page::insert([
            'title' => (string) $p['title'], 'slug' => (string) $p['slug'],
            'excerpt' => (string) ($p['excerpt'] ?? ''),
            'blocks' => json_encode($p['blocks'] ?? [], JSON_UNESCAPED_UNICODE),
            'seo' => json_encode($p['seo'] ?? [], JSON_UNESCAPED_UNICODE),
            'status' => 'published', 'published_at' => $now,
            'updated_by' => $adminId, 'created_at' => $now, 'updated_at' => $now,
        ]);
    }

    // FAQ
    foreach ($read('faq.json') as $f) {
        Faq::insert([
            'question' => (string) $f['question'], 'answer' => (string) $f['answer'],
            'service_id' => null, 'status' => 'published',
            'sort_order' => (int) ($f['sort_order'] ?? 10), 'created_at' => $now,
        ]);
    }

    // Menu
    $menus = $read('menus.json');
    if (isset($menus['header'])) {
        Menu::saveItems('header', $menus['header']);
    }
    if (isset($menus['footer'])) {
        Menu::saveItems('footer', $menus['footer']);
    }

    // Pengaturan dasar
    foreach ($read('settings.json') as $group => $pairs) {
        Setting::putMany((string) $group, (array) $pairs);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Installer — PT Perorangan</title>
<style>
  :root { --bg:#0b0f1e; --surface:#121831; --border:#232c52; --text:#e8ecff; --muted:#9aa3c7; --primary:#5b3df5; --accent:#22d3ee; --danger:#f87171; }
  * { box-sizing: border-box; }
  body { margin:0; font-family: system-ui, sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; padding: 40px 16px; }
  .wrap { max-width: 760px; margin: 0 auto; }
  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; padding: 28px; margin-bottom: 20px; }
  h1 { margin: 0 0 6px; font-size: 1.6rem; } h2 { font-size: 1.1rem; }
  .step-badge { display:inline-block; background: var(--primary); color:#fff; border-radius: 999px; padding: 3px 14px; font-size:.8rem; font-weight:700; margin-bottom: 12px; }
  label { display:block; font-weight:600; font-size:.9rem; margin: 14px 0 6px; }
  input, select { width:100%; padding: 12px 14px; border-radius: 10px; border:1px solid var(--border); background: rgba(11,15,30,.7); color: var(--text); font-size: .95rem; }
  .btn { display:inline-block; background: linear-gradient(135deg, var(--primary), #7c5cff); color:#fff; border:0; padding: 13px 30px; border-radius: 12px; font-weight:700; cursor:pointer; margin-top: 18px; font-size: 1rem; }
  .ok { color: #6ee7b7; } .bad { color: var(--danger); }
  ul.checks { list-style:none; padding:0; } ul.checks li { padding: 6px 0; border-bottom: 1px solid rgba(35,44,82,.5); }
  .error-box { background: rgba(248,113,113,.12); border: 1px solid var(--danger); border-radius: 12px; padding: 14px 18px; margin-bottom: 18px; }
  .hint { color: var(--muted); font-size: .84rem; }
  .grid2 { display:grid; grid-template-columns: 1fr 1fr; gap: 0 18px; }
  @media (max-width: 640px) { .grid2 { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<div class="wrap">
  <h1>◆ Installer Website PT Perorangan</h1>
  <p class="hint">Wizard ini mengatur semuanya tanpa perintah terminal. Butuh ±3 menit.</p>

  <?php if ($done): ?>
    <div class="card">
      <span class="step-badge">SELESAI ✓</span>
      <h2>Situs Anda sudah terpasang!</h2>
      <p class="ok">✓ Tabel database dibuat ✓ Konten awal dimuat ✓ Akun admin dibuat ✓ Installer terkunci.</p>
      <p><strong>Langkah berikutnya:</strong></p>
      <ol>
        <li>Buka <a href="/admin/login">/admin/login</a> dan masuk dengan akun yang tadi dibuat.</li>
        <li>Periksa <a href="/" target="_blank">beranda</a> dan <a href="/sitemap.xml" target="_blank">sitemap</a>.</li>
        <li><strong>Keamanan:</strong> pastikan file <code>public/install.php</code> sudah dihapus dari hosting (via cPanel File Manager) — isi file ini sudah otomatis dikosongkan, tetapi menghapusnya lebih rapi.</li>
      </ol>
      <a class="btn" href="/admin/login">Buka Dashboard →</a>
    </div>
  <?php elseif ($alreadyInstalled): ?>
    <div class="card">
      <span class="step-badge">SUDAH TERPASANG</span>
      <h2>Aplikasi ini sudah terinstal.</h2>
      <p>Untuk keamanan, installer tidak dapat dijalankan lagi. Bila ingin menginstal ulang dari nol, hapus <code>config/config.php</code>, <code>config/.installed</code>, dan <code>public/install.php</code> lewat cPanel File Manager, lalu buka halaman ini kembali.</p>
      <a class="btn" href="/admin/login">Masuk ke Dashboard</a>
    </div>
  <?php else: ?>

    <?php foreach ($errors as $err): ?>
    <div class="error-box"><strong>⚠️</strong> <?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endforeach; ?>

    <?php if ($errors === []): ?>
    <div class="card">
      <span class="step-badge">LANGKAH 1/3 — Cek Lingkungan</span>
      <ul class="checks">
        <li><?= $phpOk ? '<span class="ok">✓</span>' : '<span class="bad">✕</span>' ?> PHP <?= htmlspecialchars(PHP_VERSION) ?> (butuh 8.5+)</li>
        <li><?= $missingExt === [] ? '<span class="ok">✓ Semua ekstensi aktif</span>' : '<span class="bad">✕ Kurang: ' . htmlspecialchars(implode(', ', $missingExt)) . '</span>' ?></li>
        <li><?= $storageWritable ? '<span class="ok">✓</span>' : '<span class="bad">✕</span>' ?> Folder storage/ dapat ditulis</li>
        <li><?= $mediaWritable ? '<span class="ok">✓</span>' : '<span class="bad">✕</span>' ?> Folder public/media/ dapat ditulis</li>
      </ul>
    </div>

    <form method="post" action="/install.php">
      <div class="card">
        <span class="step-badge">LANGKAH 2/3 — Database</span>
        <p class="hint">Di cPanel: buat database + user di menu "MySQL Databases", lalu salin datanya ke sini.</p>
        <div class="grid2">
          <div><label>Driver</label>
            <select name="db_driver" id="dbDriver">
              <option value="mysql">MySQL (cPanel — disarankan)</option>
              <option value="sqlite">SQLite (uji cepat lokal)</option>
            </select></div>
          <div><label>Host (cPanel: localhost)</label><input name="db_host" value="localhost"></div>
          <div><label>Port</label><input name="db_port" value="3306" type="number"></div>
          <div><label>Nama database</label><input name="db_name" placeholder="cpaneluser_ptperorangan"></div>
          <div><label>User database</label><input name="db_user" placeholder="cpaneluser_admin"></div>
          <div><label>Password database</label><input name="db_pass" type="password"></div>
        </div>
        <label>URL situs (deteksi otomatis bila kosong)</label>
        <input name="base_url" placeholder="https://domain-anda.com">
      </div>

      <div class="card">
        <span class="step-badge">LANGKAH 3/3 — Akun Admin</span>
        <div class="grid2">
          <div><label>Nama lengkap</label><input name="admin_name" required></div>
          <div><label>Email (untuk login)</label><input name="admin_email" type="email" required></div>
          <div><label>Kata sandi (min 12 karakter)</label><input name="admin_password" type="password" minlength="12" required></div>
          <div><label>Ulangi kata sandi</label><input name="admin_password2" type="password" minlength="12" required></div>
        </div>
        <p class="hint">Kata sandi disimpan sebagai hash aman (tidak pernah teks asli). Simpan di tempat aman.</p>
        <button class="btn" type="submit">🚀 Jalankan Instalasi</button>
      </div>
    </form>
    <?php endif; ?>
  <?php endif; ?>
</div>
<script>
// Sembunyikan field MySQL bila memilih SQLite
document.getElementById('dbDriver').addEventListener('change', function () {
  var sqlite = this.value === 'sqlite';
  document.querySelectorAll('[name="db_host"],[name="db_port"],[name="db_name"],[name="db_user"],[name="db_pass"]')
    .forEach(function (el) { el.closest('div').style.display = sqlite ? 'none' : 'block'; });
});
</script>
</body>
</html>
