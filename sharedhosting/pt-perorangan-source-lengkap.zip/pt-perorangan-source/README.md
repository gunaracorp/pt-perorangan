# PT Perorangan — Website PHP 8.5 · Tema Futuristik · CMS + Editor Visual · SEO Skala Besar

Aplikasi web lengkap untuk layanan pendirian **PT Perorangan**: PHP 8.5 murni,
siap shared hosting cPanel (tanpa Node/Composer di produksi), tema futuristik
yang benar-benar dipakai, dashboard admin dengan **editor visual front-end**,
dan fondasi SEO untuk ratusan halaman dengan gerbang kualitas.

---

## Mulai Cepat

**Di hosting cPanel (produksi):**
Baca `docs/README_DEPLOY_CPANEL.md` — langkah demi langkah tanpa terminal:
cek PHP 8.5 → database → unggah ZIP → arahkan document root ke `public/` →
buka `install.php` → selesai (installer mengunci dirinya sendiri).

**Di komputer lokal (uji cepat):**
```
cd pt-perorangan
/path/ke/php tools/setup-local.php --force     # SQLite + seed + admin demo
cd public
/path/ke/php -S 127.0.0.1:8099 router-dev.php  # buka http://127.0.0.1:8099
```
Login admin lokal: `admin@demo.local` / `SandiDemoPanjang123!`

## Fitur Utama (semuanya berfungsi, teruji 27/27)

| Area | Kemampuan |
|---|---|
| **Publik** | Beranda builder, hub layanan + kategori, detail layanan dengan kartu fakta (tarif resmi vs jasa, waktu, syarat), artikel, FAQ accordion, kontak (anti-spam honeypot), pencarian (noindex), 404/410 bertema |
| **Tema** | `pt-perorangan`: dark futuristik, glassmorphism, gradient/glow, 17 animasi (reveal, counter, parallax, progress…) — semua hormati `prefers-reduced-motion`, defensif tanpa JS |
| **Customizer** | 13 kontrol tervalidasi: 6 warna, 2 font, radius, lebar, gaya header/footer, kecepatan animasi → CSS variables |
| **Editor visual** | Page builder 14 blok: tambah/geser/duplikat/sembunyikan/hapus, form dinamis dari schema, pratinjau live 3 viewport, autosave revisi |
| **Konten** | Layanan (dengan fakta terstruktur), halaman, artikel, FAQ (global+per layanan), kategori, menu, media library (upload aman MIME nyata), pesan kontak |
| **Keamanan** | PDO prepared statements, CSRF semua POST, password_hash, rate limit login, peran owner/admin/editor/reviewer (server-side), proteksi upload, security headers, folder privat terisolasi |
| **SEO skala** | Meta lengkap + canonical + OG, JSON-LD (Organization/Service/FAQPage/Article/Breadcrumb), sitemap index tersegmentasi, robots dinamis, redirect 301/302/410 + hit, quality gate anti thin-content, impor massal CSV/JSON (hasil draft) |
| **Revisi** | Snapshot otomatis sebelum tiap simpan, restore, prune 20 terakhir |

## Struktur
```
public/    → document root (satu-satunya folder web)
app/       → core + controllers + models + services + view admin
themes/pt-perorangan/ → tampilan (layout, 11 template, 14 blok, CSS, JS)
config/    → routes, schema blok, config (dibuat installer)
content/   → seed konten riil (regulasi terverifikasi 2026)
database/  → schema MySQL (+SQLite lokal)
docs/      → 8 dokumen wajib (lihat daftar di bawah)
storage/   → PRIVAT: cache, log, rate-limit
tools/     → alat dev (jangan diunggah)
```

## Dokumentasi Wajib (folder `docs/`)
1. `PETA_FILE_DAN_ARSITEKTUR.md` — katalog semua file + alasan keberadaan
2. `TUTORIAL_PEMULA.md` — glosarium + alur kerja dasar tanpa jargon
3. `TUTORIAL_EDITOR_VISUAL.md` — alur lengkap edit→preview→publish→rollback
4. `ANIMATION_INVENTORY.md` — 17 animasi terdokumentasi + template audit repo
5. `README_DEPLOY_CPANEL.md` — deploy tanpa terminal + troubleshooting
6. `LAPORAN_AUDIT_DAN_MATRIKS_MIGRASI.md` — audit jujur + blocker repo
7. `ROADMAP_99_STATUS.md` — status 99 fitur dengan bukti (44 ✅, 12 🟡, 20 ⬜, 2 ⛔, 2 ➖)
8. `MATRIKS_SEO_INTENT.md` — intent → halaman (anti doorway/kanibalisme)
9. `CHECKLIST_QA_KEAMANAN.md` — 38 PASS / 7 BELUM DIUJI / 0 FAIL

## Catatan Penting (jujur)
- Repository sumber `pusatperizinan/pt-perorangan` **404/privat** → audit kode asli
  TERHALANG sampai ZIP diberikan; tidak ada fitur repo yang dikarang.
- Konten seed memakai fakta regulasi terverifikasi (Permenkum 49/2025, PP 8/2021,
  portal resmi AHU/OSS) dengan tanggal review — perbarui berkala dari dashboard.
- Klaim performa (Lighthouse/CWV) menunggu pengukuran di domain produksi.

## Stack
PHP 8.5.x · MySQL/MariaDB (PDO) · SQLite (opsional lokal) · HTML/CSS/JS vanilla
· Tanpa framework berat · Tanpa build step di server.
