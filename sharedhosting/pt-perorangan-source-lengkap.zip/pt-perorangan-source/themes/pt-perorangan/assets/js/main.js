/**
 * FILE   : themes/pt-perorangan/assets/js/main.js
 * FUNGSI : Sistem animasi & interaksi tema pt-perorangan (vanilla JS, tanpa library).
 * UNTUK  : Reveal-on-scroll, header scroll state, progress bar, menu mobile aksesibel,
 *          counter statistik, parallax ringan orb hero, link WhatsApp, toast.
 * KENAPA : - DEFENSIF: setiap fitur cek keberadaan elemen dulu → tidak error di
 *            halaman tanpa komponen terkait (wajib menurut spesifikasi proyek).
 *          - Animasi memakai transform/opacity (GPU-friendly) + IntersectionObserver.
 *          - Menghormati prefers-reduced-motion (fallback: konten langsung tampil).
 * TERKAIT: assets/css/main.css (kelas .reveal, .is-visible, .is-scrolled)
 * UNTUK PEMULA: "IntersectionObserver" = cara browser memberi tahu "elemen ini
 *          masuk layar" tanpa memantau scroll terus-menerus (hemat CPU).
 */
(function () {
  'use strict';

  // Tandai JS aktif → CSS boleh menyembunyikan .reveal sebelum terlihat.
  document.documentElement.classList.add('js');

  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- 1. Reveal-on-scroll ---------- */
  function initReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!els.length) return;

    if (reducedMotion || !('IntersectionObserver' in window)) {
      // Fallback: langsung tampilkan semua (tanpa animasi).
      els.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }

    // Teruskan atribut data-delay ke CSS var --d (delay berjenjang).
    els.forEach(function (el) {
      var d = parseInt(el.getAttribute('data-delay') || '0', 10);
      if (d > 0) el.style.setProperty('--d', String(d));
    });

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target); // animasi sekali saja (hemat performa)
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    els.forEach(function (el) { io.observe(el); });
  }

  /* ---------- 2. Header scrolled + progress bar ---------- */
  function initHeader() {
    var header = document.getElementById('siteHeader');
    var progress = document.getElementById('scrollProgress');
    if (!header && !progress) return;

    var ticking = false;
    function onScroll() {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        var y = window.scrollY || 0;
        if (header) header.classList.toggle('is-scrolled', y > 12);
        if (progress) {
          var max = document.documentElement.scrollHeight - window.innerHeight;
          progress.style.width = max > 0 ? ((y / max) * 100).toFixed(2) + '%' : '0%';
        }
        ticking = false;
      });
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- 3. Menu mobile aksesibel ---------- */
  function initNavToggle() {
    var toggle = document.getElementById('navToggle');
    var nav = document.getElementById('mainNav');
    if (!toggle || !nav) return;

    function setOpen(open) {
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      nav.classList.toggle('is-open', open);
      toggle.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
    }
    toggle.addEventListener('click', function () {
      setOpen(toggle.getAttribute('aria-expanded') !== 'true');
    });
    // Tutup dengan Escape (aksesibilitas keyboard).
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        setOpen(false);
        toggle.focus();
      }
    });
    // Tutup setelah memilih tautan (navigasi satu halaman).
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a')) setOpen(false);
    });
    // Tutup bila layar diperbesar kembali ke desktop.
    window.matchMedia('(min-width: 721px)').addEventListener('change', function (e) {
      if (e.matches) setOpen(false);
    });
  }

  /* ---------- 4. Counter statistik ---------- */
  function initCounters() {
    var counters = document.querySelectorAll('[data-counter]');
    if (!counters.length) return;

    function animate(el) {
      if (reducedMotion) { render(el); return; } // tanpa animasi → langsung nilai akhir
      var target = parseFloat(el.getAttribute('data-counter')) || 0;
      var suffix = el.getAttribute('data-suffix') || '';
      var duration = 1400;
      var start = null;
      function step(ts) {
        if (start === null) start = ts;
        var p = Math.min((ts - start) / duration, 1);
        var eased = 1 - Math.pow(1 - p, 3); // easeOutCubic
        var val = Math.round(target * eased);
        el.textContent = val.toLocaleString('id-ID') + suffix;
        if (p < 1) window.requestAnimationFrame(step);
      }
      window.requestAnimationFrame(step);
    }
    function render(el) {
      var target = parseFloat(el.getAttribute('data-counter')) || 0;
      el.textContent = target.toLocaleString('id-ID') + (el.getAttribute('data-suffix') || '');
    }

    if (!('IntersectionObserver' in window)) {
      counters.forEach(render);
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animate(entry.target);
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    counters.forEach(function (el) { io.observe(el); });
  }

  /* ---------- 5. Parallax ringan orb hero (desktop, tanpa reduced-motion) ---------- */
  function initParallax() {
    if (reducedMotion) return;
    var orbs = document.querySelectorAll('.orb');
    if (!orbs.length) return;
    var fine = window.matchMedia('(pointer: fine)').matches;
    if (!fine) return; // hanya pointer presisi (mouse) — hemat baterai ponsel

    var ticking = false;
    window.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        var y = window.scrollY || 0;
        orbs.forEach(function (orb, i) {
          var speed = i === 0 ? 0.08 : -0.06;
          orb.style.transform = 'translate3d(0,' + (y * speed).toFixed(1) + 'px,0)';
        });
        ticking = false;
      });
    }, { passive: true });
  }

  /* ---------- 6. Tautan WhatsApp: konfirmasi keluar situs (opsional UX) ---------- */
  function initWaLinks() {
    var links = document.querySelectorAll('a[data-wa]');
    links.forEach(function (link) {
      link.addEventListener('click', function () {
        // Titik ukur funnel sederhana (tanpa data pribadi) — siap dihubungkan analitik.
        document.documentElement.setAttribute('data-wa-clicked', '1');
      });
    });
  }

  /* ---------- 7. FAQ: tutup item lain dalam satu grup (accordion) ---------- */
  function initFaqAccordion() {
    var groups = document.querySelectorAll('.faq-list');
    groups.forEach(function (group) {
      var items = group.querySelectorAll('details.faq-item');
      if (items.length < 2) return;
      items.forEach(function (item) {
        item.addEventListener('toggle', function () {
          if (item.open) {
            items.forEach(function (other) {
              if (other !== item) other.open = false;
            });
          }
        });
      });
    });
  }

  /* ---------- 8. Active nav highlight (fallback tanpa PHP) ---------- */
  function initActiveNav() {
    var links = document.querySelectorAll('.main-nav a[href]');
    if (!links.length) return;
    var path = window.location.pathname;
    links.forEach(function (link) {
      var href = link.getAttribute('href');
      if (href && href !== '/' && path.indexOf(href) === 0) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
      }
    });
  }

  /* ---------- Boot (defensif: setiap init aman di halaman apa pun) ---------- */
  function boot() {
    [initReveal, initHeader, initNavToggle, initCounters, initParallax,
     initWaLinks, initFaqAccordion, initActiveNav].forEach(function (fn) {
      try { fn(); } catch (err) {
        // Jangan biarkan satu fitur error mematikan fitur lain.
        if (window.console && console.warn) console.warn('init gagal:', fn.name, err);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
