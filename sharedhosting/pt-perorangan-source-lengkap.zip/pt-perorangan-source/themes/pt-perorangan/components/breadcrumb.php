<?php
/**
 * KOMPONEN : breadcrumb.php
 * FUNGSI    : Jejak navigasi konsisten (rumah → induk → halaman) + mendukung JSON-LD.
 * UNTUK     : Template service/page/article dengan variabel $trail = [label => url].
 * AMAN?     : PRIVAT.
 */

use App\Core\Str;
?>
<?php if (!empty($trail) && count($trail) > 1): ?>
<nav class="breadcrumb" aria-label="Breadcrumb">
  <ol>
    <?php $last = array_key_last($trail); foreach ($trail as $label => $url): ?>
    <li>
      <?php if ($url === $last || $url === ''): ?>
        <span aria-current="page"><?= Str::e($label) ?></span>
      <?php else: ?>
        <a href="<?= Str::e($url) ?>"><?= Str::e($label) ?></a>
      <?php endif; ?>
    </li>
    <?php endforeach; ?>
  </ol>
</nav>
<?php endif; ?>
