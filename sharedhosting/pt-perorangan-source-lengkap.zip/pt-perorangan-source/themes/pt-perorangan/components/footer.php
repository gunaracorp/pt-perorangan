<?php
/**
 * KOMPONEN : footer.php
 * FUNGSI    : Footer modular: ringkasan, menu, kontak, disclaimer afiliasi (BUKAN situs pemerintah).
 * AMAN?     : PRIVAT.
 * PEMULA    : Disclaimer afiliasi penting: layanan legalitas sering dikira instansi resmi —
 *             harus jelas bahwa ini penyedia jasa independen.
 */

use App\Core\Str;
?>
<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-col">
      <a class="brand" href="/">
        <span class="brand-mark" aria-hidden="true">◆</span>
        <span class="brand-name"><?= Str::e($site['name']) ?></span>
      </a>
      <p class="footer-tagline"><?= Str::e($site['tagline']) ?></p>
      <p class="footer-note"><?= Str::e($site['footer_note']) ?></p>
    </div>
    <nav class="footer-col" aria-label="Tautan situs">
      <h3>Penjelajahan</h3>
      <ul>
        <?php foreach (($menu ?? []) as $item): ?>
        <li><a href="<?= Str::e($item['url']) ?>"><?= Str::e($item['label']) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </nav>
    <div class="footer-col">
      <h3>Kontak</h3>
      <ul class="contact-list">
        <?php if (!empty($site['whatsapp'])): ?>
        <li><a data-wa href="https://wa.me/<?= Str::e(preg_replace('~\D~', '', $site['whatsapp'])) ?>" rel="noopener" target="_blank">WhatsApp: <?= Str::e($site['whatsapp']) ?></a></li>
        <?php endif; ?>
        <?php if (!empty($site['phone'])): ?><li>Telepon: <?= Str::e($site['phone']) ?></li><?php endif; ?>
        <?php if (!empty($site['email'])): ?><li><a href="mailto:<?= Str::e($site['email']) ?>"><?= Str::e($site['email']) ?></a></li><?php endif; ?>
        <?php if (!empty($site['address'])): ?><li><?= Str::e($site['address']) ?></li><?php endif; ?>
      </ul>
      <ul class="social-list">
        <?php foreach ($site['social'] as $key => $url): if ($url === '') continue; ?>
        <li><a href="<?= Str::e($url) ?>" rel="noopener nofollow" target="_blank"><?= Str::e(ucfirst($key)) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container">
      <p>© <?= date('Y') ?> <?= Str::e($site['name']) ?>. Seluruh hak cipta dilindungi.</p>
    </div>
  </div>
</footer>
