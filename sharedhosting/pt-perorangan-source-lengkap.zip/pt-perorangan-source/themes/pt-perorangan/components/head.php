<?php
/**
 * KOMPONEN : head.php
 * FUNGSI    : Semua tag <head>: meta SEO, Open Graph, JSON-LD, CSS, design tokens.
 * UNTUK     : Dipanggil layout default.
 * KENAPA    : SEO teknis per halaman (title, description, canonical, robots, OG)
 *             terpusat di sini — tidak terpecah antar template.
 * AMAN?     : PRIVAT.
 * PEMULA    : canonical = URL resmi halaman; og:image = gambar saat dibagikan ke WA/sosmed.
 */

use App\Core\Str;
use App\Services\SeoService;
?>
<title><?= Str::e($seo['title'] ?? 'PT Perorangan') ?></title>
<meta name="description" content="<?= Str::e($seo['description'] ?? '') ?>">
<meta name="robots" content="<?= Str::e($seo['robots'] ?? 'index, follow') ?>">
<?php if (!empty($seo['canonical'])): ?>
<link rel="canonical" href="<?= Str::e($seo['canonical']) ?>">
<?php endif; ?>

<!-- Open Graph -->
<meta property="og:title" content="<?= Str::e($seo['title'] ?? 'PT Perorangan') ?>">
<meta property="og:description" content="<?= Str::e($seo['description'] ?? '') ?>">
<meta property="og:type" content="<?= Str::e($seo['og_type'] ?? 'website') ?>">
<?php if (!empty($seo['canonical'])): ?>
<meta property="og:url" content="<?= Str::e($seo['canonical']) ?>">
<?php endif; ?>
<meta property="og:locale" content="id_ID">
<?php if (!empty($seo['og_image'])): ?>
<meta property="og:image" content="<?= Str::e($seo['og_image']) ?>">
<?php endif; ?>
<meta name="twitter:card" content="summary_large_image">

<?php if (!empty($site['logo'])): ?>
<link rel="icon" href="<?= Str::e($site['logo']) ?>" type="image/x-icon">
<?php endif; ?>

<!-- Google Search Console verifikasi (dari admin/pengaturan) -->
<?php $gsc = \App\Models\Setting::allGrouped('analytics')['gsc_verification'] ?? ''; if ($gsc !== ''): ?>
<meta name="google-site-verification" content="<?= Str::e($gsc) ?>">
<?php endif; ?>

<!-- Design tokens dari customizer (nilai tervalidasi Theme::cssVariables) -->
<style>:root { <?= $cssVars ?? '' ?> }</style>
<link rel="stylesheet" href="/theme-assets/css/main.css">

<!-- JSON-LD: hanya data yang benar-benar tampil di halaman -->
<?php foreach (($seo['jsonld'] ?? []) as $i => $ld): if (!is_array($ld) || $ld === []) continue; ?>
<script type="application/ld+json"><?= json_encode($ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
<?php endforeach; ?>

<!-- Google Analytics / GTAG opsional (diatur admin, tanpa klaim privasi berlebih) -->
<?php $gtag = \App\Models\Setting::allGrouped('analytics')['gtag_id'] ?? ''; if ($gtag !== ''): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= Str::e($gtag) ?>"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','<?= Str::e($gtag) ?>');</script>
<?php endif; ?>
