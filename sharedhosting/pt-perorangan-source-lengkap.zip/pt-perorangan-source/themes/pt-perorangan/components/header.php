<?php
/**
 * KOMPONEN : header.php
 * FUNGSI    : Navigasi utama sticky dengan efek glass, logo, menu dari CMS, CTA WhatsApp,
 *             menu mobile aksesibel (ARIA), dan indikator scroll.
 * AMAN?     : PRIVAT.
 * PEMULA    : ARIA-expanded membantu pembaca layar mengetahui kondisi menu.
 */

use App\Core\Str;
?>
<header class="site-header" id="siteHeader">
  <div class="container header-inner">
    <a class="brand" href="/" aria-label="Beranda <?= Str::e($site['name']) ?>">
      <?php if (!empty($site['logo'])): ?>
        <img src="<?= Str::e($site['logo']) ?>" alt="Logo <?= Str::e($site['name']) ?>" width="36" height="36">
      <?php else: ?>
        <span class="brand-mark" aria-hidden="true">◆</span>
      <?php endif; ?>
      <span class="brand-name"><?= Str::e($site['name']) ?></span>
    </a>

    <nav class="main-nav" id="mainNav" aria-label="Navigasi utama">
      <ul>
        <?php foreach (($menu ?? []) as $item): $url = (string) $item['url'];
            $active = $url !== '/' && str_starts_with($_SERVER['REQUEST_URI'] ?? '/', $url); ?>
        <li><a href="<?= Str::e($url) ?>"<?= $active ? ' class="active" aria-current="page"' : '' ?>><?= Str::e($item['label']) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </nav>

    <div class="header-cta">
      <?php if (!empty($site['whatsapp'])): ?>
      <a class="btn btn-primary btn-sm" data-wa href="https://wa.me/<?= Str::e(preg_replace('~\D~', '', $site['whatsapp'])) ?>?text=<?= rawurlencode($site['wa_message'] ?: 'Halo, saya ingin konsultasi.') ?>" rel="noopener" target="_blank">Konsultasi</a>
      <?php else: ?>
      <a class="btn btn-primary btn-sm" href="/kontak">Konsultasi</a>
      <?php endif; ?>
      <button class="nav-toggle" id="navToggle" aria-expanded="false" aria-controls="mainNav" aria-label="Buka menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
  <div class="scroll-progress" id="scrollProgress" aria-hidden="true"></div>
</header>
