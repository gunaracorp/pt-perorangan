<?php
/**
 * LAYOUT : themes/pt-perorangan/layouts/default.php
 * FUNGSI  : Kerangka seluruh halaman publik: <head> SEO, header, konten, footer.
 * UNTUK   : Dipanggil View::render() — variabel $content, $site, $seo, $cssVars tersedia.
 * KENAPA  : Struktur HTML + meta SEO dikontrol satu tempat agar konsisten di semua halaman.
 * AMAN?   : PRIVAT (bukan entry point).
 * PEMULA  : $content = hasil template halaman (mis. service.php) yang sudah dirender.
 */

use App\Core\Str;
use App\Core\View;
use App\Models\Menu;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0b0f1e">
<?php View::component('head', ['seo' => $seo, 'site' => $site, 'cssVars' => $cssVars]); ?>
</head>
<body data-reduced-motion="auto">
<a class="skip-link" href="#konten-utama">Langsung ke konten utama</a>

<?php View::component('header', ['site' => $site, 'menu' => Menu::items('header')]); ?>

<main id="konten-utama" class="site-main">
    <?= $content ?>
</main>

<?php View::component('footer', ['site' => $site, 'menu' => Menu::items('footer')]); ?>

<!-- Panel pratinjau (hanya muncul pada mode pratinjau admin) -->
<?php if (!empty($previewMode)): ?>
<div class="preview-bar" role="status">
    <span>MODE PRATINJAU — perubahan belum dipublikasikan</span>
    <a href="/admin<?= isset($page) ? '/halaman/' . (int) $page['id'] . '/edit' : '' ?>">Kembali ke editor</a>
</div>
<?php endif; ?>

<script src="/theme-assets/js/main.js" defer></script>
</body>
</html>
