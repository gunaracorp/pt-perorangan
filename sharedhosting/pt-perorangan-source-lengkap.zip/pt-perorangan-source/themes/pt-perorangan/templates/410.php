<?php
/**
 * TEMPLATE : 410.php — konten dihapus permanen (status 410 dikirim App::run()).
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
?>
<section class="page-hero error-hero reveal">
    <div class="container">
        <p class="error-code">410</p>
        <h1>Konten Telah Dihapus</h1>
        <p class="lead"><?= Str::e($message ?? 'Konten ini telah dihapus permanen dan tidak tersedia.') ?></p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="/">Kembali ke Beranda</a>
            <a class="btn btn-ghost" href="/layanan">Lihat Layanan</a>
        </div>
    </div>
</section>
