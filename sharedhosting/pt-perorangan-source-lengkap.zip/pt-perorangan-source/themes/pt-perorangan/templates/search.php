<?php
/**
 * TEMPLATE : search.php — hasil pencarian internal (noindex dari controller SEO).
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
?>
<section class="page-hero reveal">
    <div class="container">
        <p class="eyebrow">Pencarian</p>
        <h1>Hasil Pencarian</h1>
        <form class="search-form" method="get" action="/cari" role="search">
            <label class="sr-only" for="q">Kata kunci</label>
            <input type="search" id="q" name="q" value="<?= Str::e($q) ?>" placeholder="Cari layanan atau artikel…" maxlength="80">
            <button class="btn btn-primary" type="submit">Cari</button>
        </form>
    </div>
</section>

<section class="block container">
    <?php if ($q === ''): ?>
    <p>Ketik kata kunci untuk mencari layanan dan artikel.</p>
    <?php elseif (empty($results)): ?>
    <p>Tidak ada hasil untuk "<strong><?= Str::e($q) ?></strong>". Coba kata kunci lain, atau jelajahi <a href="/layanan">daftar layanan</a>.</p>
    <?php else: ?>
    <div class="search-results">
        <?php foreach ($results as $res): ?>
        <a class="search-result card" href="<?= $res['kind'] === 'service' ? '/layanan/' : ($res['kind'] === 'article' ? '/artikel/' : '/p/') ?><?= Str::e($res['slug']) ?>">
            <span class="badge badge-<?= Str::e($res['kind']) ?>"><?= Str::e($res['kind'] === 'service' ? 'Layanan' : ($res['kind'] === 'article' ? 'Artikel' : 'Halaman')) ?></span>
            <h3><?= Str::e($res['title']) ?></h3>
            <p><?= Str::e(Str::excerpt((string) ($res['excerpt'] ?? ''), 120)) ?></p>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>
