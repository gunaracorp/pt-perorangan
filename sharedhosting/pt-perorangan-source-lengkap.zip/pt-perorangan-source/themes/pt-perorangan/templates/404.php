<?php
/**
 * TEMPLATE : 404.php — halaman tidak ditemukan (status 404 asli dikirim controller).
 * AMAN?    : PRIVAT. Jangan pernah redirect 404 ke beranda (buruk untuk SEO & UX).
 */

use App\Core\Str;
?>
<section class="page-hero error-hero reveal">
    <div class="container">
        <p class="error-code">404</p>
        <h1>Halaman Tidak Ditemukan</h1>
        <p class="lead"><?= Str::e($message ?? 'Halaman yang Anda cari tidak ditemukan.') ?></p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="/">Kembali ke Beranda</a>
            <a class="btn btn-ghost" href="/layanan">Lihat Layanan</a>
        </div>
    </div>
</section>
