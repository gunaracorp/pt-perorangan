<?php
/**
 * TEMPLATE : article_index.php — daftar artikel/panduan.
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
?>
<section class="page-hero reveal">
    <div class="container">
        <p class="eyebrow">Wawasan</p>
        <h1>Artikel & Panduan</h1>
        <p class="lead">Panduan praktis seputar legalitas usaha, ditulis ulang dari sumber resmi dan ditinjau berkala.</p>
    </div>
</section>

<section class="block container reveal">
    <?php if (!empty($articles)): ?>
    <div class="cards-grid">
        <?php foreach ($articles as $a): ?>
        <a class="card article-card" href="/artikel/<?= Str::e($a['slug']) ?>">
            <h3><?= Str::e($a['title']) ?></h3>
            <p><?= Str::e(Str::excerpt((string) ($a['excerpt'] ?? ''), 120)) ?></p>
            <span class="card-meta"><?= Str::e(Str::tanggalIndo($a['published_at'] ?? $a['created_at'])) ?></span>
            <span class="card-link">Baca →</span>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p>Belum ada artikel.</p>
    <?php endif; ?>
</section>
