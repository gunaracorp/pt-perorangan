<?php
/**
 * TEMPLATE : service_index.php — hub /layanan (peta jalan pengguna menemukan layanan).
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
?>
<section class="page-hero reveal">
    <div class="container">
        <p class="eyebrow">Layanan</p>
        <h1>Layanan Legalitas & Pendirian Usaha</h1>
        <p class="lead">Pilih kebutuhan Anda — setiap halaman layanan memuat syarat, proses, estimasi biaya resmi vs biaya jasa, dan waktu pengerjaan.</p>
    </div>
</section>

<?php if (!empty($categories)): ?>
<section class="block container reveal">
    <h2>Kategori Layanan</h2>
    <div class="chips">
        <?php foreach ($categories as $cat): ?>
        <a class="chip" href="/layanan/kategori/<?= Str::e($cat['slug']) ?>"><?= Str::e($cat['name']) ?></a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<section class="block container reveal">
    <?php if (!empty($services)): ?>
    <div class="cards-grid">
        <?php foreach ($services as $s): ?>
        <a class="card service-card" href="/layanan/<?= Str::e($s['slug']) ?>">
            <?php if (!empty($s['featured'])): ?><span class="badge">Unggulan</span><?php endif; ?>
            <h3><?= Str::e($s['title']) ?></h3>
            <p><?= Str::e(Str::excerpt((string) ($s['excerpt'] ?? ''), 120)) ?></p>
            <span class="card-link">Lihat detail →</span>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p>Daftar layanan akan segera tersedia.</p>
    <?php endif; ?>
</section>
