<?php
/**
 * BLOK : sources.php — sumber resmi + tanggal review (kredibilitas konten legal).
 * FIELD: title, items (Nama | URL), reviewed_at.
 * AMAN? : PRIVAT. URL sudah disanitasi schema (hanya http(s)/path).
 */

use App\Core\Str;
?>
<div class="container">
    <div class="sources-panel card reveal">
        <?php if (!empty($title)): ?><h2><?= Str::e($title) ?></h2><?php endif; ?>
        <ul class="sources-list">
            <?php foreach ((array) ($items ?? []) as $item):
                [$name, $url] = array_pad(explode('|', (string) $item, 2), 2, '');
                if (trim($url) === '') continue; ?>
            <li><a href="<?= Str::e(trim($url)) ?>" rel="noopener nofollow" target="_blank"><?= Str::e(trim($name) ?: trim($url)) ?></a></li>
            <?php endforeach; ?>
        </ul>
        <?php if (!empty($reviewed_at)): ?>
        <p class="muted-note">Terakhir ditinjau: <?= Str::e(Str::tanggalIndo($reviewed_at)) ?></p>
        <?php endif; ?>
    </div>
</div>
