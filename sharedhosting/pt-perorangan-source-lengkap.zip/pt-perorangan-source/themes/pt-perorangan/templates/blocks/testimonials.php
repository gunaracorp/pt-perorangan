<?php
/**
 * BLOK : testimonials.php — kutipan pelanggan ASLI (wajib izin; dilarang data palsu).
 * FIELD: title, items (Nama | Kutipan | Jabatan/Usaha).
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
?>
<div class="container">
    <?php if (!empty($title)): ?><h2 class="section-title reveal"><?= Str::e($title) ?></h2><?php endif; ?>
    <div class="cards-grid testimonial-cards">
        <?php foreach ((array) ($items ?? []) as $i => $item):
            [$name, $quote, $role] = array_pad(explode('|', (string) $item, 3), 3, ''); ?>
        <figure class="card testimonial-card reveal" data-delay="<?= min($i, 5) ?>">
            <blockquote>“<?= Str::e(trim($quote)) ?>”</blockquote>
            <figcaption>
                <strong><?= Str::e(trim($name)) ?></strong>
                <?php if (trim($role) !== ''): ?><span><?= Str::e(trim($role)) ?></span><?php endif; ?>
            </figcaption>
        </figure>
        <?php endforeach; ?>
    </div>
</div>
