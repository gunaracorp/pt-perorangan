<?php
/**
 * BLOK : hero.php — section pembuka besar dengan gradient, glow, dan animasi masuk.
 * FIELD: badge, title, subtitle, cta_label, cta_url, cta2_label, cta2_url, align.
 * AMAN? : PRIVAT. Semua output lewat Str::e().
 */

use App\Core\Str;
?>
<div class="container hero-inner hero-<?= Str::e($align ?? 'center') ?>">
    <div class="hero-bg" aria-hidden="true"><span class="orb orb-a"></span><span class="orb orb-b"></span><span class="grid-lines"></span></div>
    <?php if (!empty($badge)): ?><p class="hero-badge reveal"><?= Str::e($badge) ?></p><?php endif; ?>
    <h1 class="hero-title reveal" data-delay="1"><?= Str::e($title ?? '') ?></h1>
    <?php if (!empty($subtitle)): ?><p class="hero-subtitle reveal" data-delay="2"><?= Str::e($subtitle) ?></p><?php endif; ?>
    <?php if (!empty($cta_label) || !empty($cta2_label)): ?>
    <div class="hero-actions reveal" data-delay="3">
        <?php if (!empty($cta_label)): ?><a class="btn btn-primary" href="<?= Str::e($cta_url ?? '/kontak') ?>"><?= Str::e($cta_label) ?></a><?php endif; ?>
        <?php if (!empty($cta2_label)): ?><a class="btn btn-ghost" href="<?= Str::e($cta2_url ?? '/layanan') ?>"><?= Str::e($cta2_label) ?></a><?php endif; ?>
    </div>
    <?php endif; ?>
</div>
