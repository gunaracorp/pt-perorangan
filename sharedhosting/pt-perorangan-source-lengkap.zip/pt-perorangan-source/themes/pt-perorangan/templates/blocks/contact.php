<?php
/**
 * BLOK : contact.php — formulir kontak sebagai blok builder.
 * FIELD: title, subtitle. (Form identik dengan halaman /kontak, aman CSRF + honeypot.)
 * AMAN? : PRIVAT.
 */

use App\Core\Csrf;
use App\Core\Str;
?>
<div class="container">
    <div class="contact-form card reveal">
        <?php if (!empty($title)): ?><h2 class="section-title"><?= Str::e($title) ?></h2><?php endif; ?>
        <?php if (!empty($subtitle)): ?><p class="section-lead"><?= Str::e($subtitle) ?></p><?php endif; ?>
        <form method="post" action="/kontak" novalidate>
            <?= Csrf::field() ?>
            <div class="hp-field" aria-hidden="true"><label>Jangan isi<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
            <div class="form-row">
                <label for="b-name-<?= uniqid() ?>">Nama lengkap <span aria-hidden="true">*</span></label>
                <input name="name" type="text" required maxlength="100">
            </div>
            <div class="form-row">
                <label>Email <span aria-hidden="true">*</span></label>
                <input name="email" type="email" required maxlength="150">
            </div>
            <div class="form-row">
                <label>Pesan <span aria-hidden="true">*</span></label>
                <textarea name="message" rows="5" required maxlength="3000"></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Kirim Pesan</button>
        </form>
    </div>
</div>
