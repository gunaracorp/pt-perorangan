<?php
/**
 * BLOK : features.php — grid kartu keunggulan.
 * FIELD: title, subtitle, items (Judul | Penjelasan per baris), style.
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
?>
<div class="container">
    <?php if (!empty($title)): ?><h2 class="section-title reveal"><?= Str::e($title) ?></h2><?php endif; ?>
    <?php if (!empty($subtitle)): ?><p class="section-lead reveal"><?= Str::e($subtitle) ?></p><?php endif; ?>
    <div class="cards-grid feature-cards style-<?= Str::e($style ?? 'glass') ?>">
        <?php foreach ((array) ($items ?? []) as $i => $item):
            [$head, $body] = array_pad(explode('|', (string) $item, 2), 2, ''); ?>
        <div class="card feature-card reveal" data-delay="<?= min($i, 5) ?>">
            <span class="feature-icon" aria-hidden="true"><?= ['⚡','🛡️','✨','🎯','📈','🤝'][$i % 6] ?></span>
            <h3><?= Str::e(trim($head)) ?></h3>
            <p><?= Str::e(trim($body)) ?></p>
        </div>
        <?php endforeach; ?>
    </div>
</div>
