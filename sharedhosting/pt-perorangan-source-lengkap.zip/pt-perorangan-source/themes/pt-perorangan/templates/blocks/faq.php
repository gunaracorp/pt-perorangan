<?php
/**
 * BLOK : faq.php — accordion pertanyaan-jawaban (elemen <details> aksesibel).
 * FIELD: title, items (Pertanyaan | Jawaban per baris).
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
?>
<div class="container">
    <div class="block-faq">
        <?php if (!empty($title)): ?><h2 class="section-title reveal"><?= Str::e($title) ?></h2><?php endif; ?>
        <div class="faq-list">
            <?php foreach ((array) ($items ?? []) as $i => $item):
                [$q, $a] = array_pad(explode('|', (string) $item, 2), 2, ''); ?>
            <details class="faq-item reveal" data-delay="<?= min($i, 5) ?>">
                <summary><?= Str::e(trim($q)) ?></summary>
                <div class="faq-answer"><?= nl2br(Str::e(trim($a))) ?></div>
            </details>
            <?php endforeach; ?>
        </div>
    </div>
</div>
