<?php
/**
 * BLOK : steps.php — tahapan proses bernomor dengan garis penghubung.
 * FIELD: title, items (Judul | Penjelasan per baris).
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
?>
<div class="container">
    <?php if (!empty($title)): ?><h2 class="section-title reveal"><?= Str::e($title) ?></h2><?php endif; ?>
    <ol class="steps-list">
        <?php foreach ((array) ($items ?? []) as $i => $item):
            [$head, $body] = array_pad(explode('|', (string) $item, 2), 2, ''); ?>
        <li class="step reveal" data-delay="<?= min($i, 5) ?>">
            <span class="step-num" aria-hidden="true"><?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
            <div>
                <h3><?= Str::e(trim($head)) ?></h3>
                <p><?= Str::e(trim($body)) ?></p>
            </div>
        </li>
        <?php endforeach; ?>
    </ol>
</div>
