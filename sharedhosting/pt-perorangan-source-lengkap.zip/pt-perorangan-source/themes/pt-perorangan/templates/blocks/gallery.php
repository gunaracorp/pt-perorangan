<?php
/**
 * BLOK : gallery.php — grid gambar dari media library (lazy loading + alt wajib).
 * FIELD: title, items (path /media/xxx per baris).
 * AMAN? : PRIVAT. Path dibatasi /media/ oleh schema image → list di sini disaring ulang.
 */

use App\Core\Str;
?>
<div class="container">
    <?php if (!empty($title)): ?><h2 class="section-title reveal"><?= Str::e($title) ?></h2><?php endif; ?>
    <div class="gallery-grid">
        <?php foreach ((array) ($items ?? []) as $item):
            $path = trim((string) $item);
            if (!preg_match('~^/media/[A-Za-z0-9._-]+$~', $path)) {
                continue; // tolak path di luar media library
            }
            $media = \App\Models\Media::findByFilename(basename($path));
            $alt = (string) ($media['alt'] ?? 'Gambar galeri'); ?>
        <figure class="gallery-item reveal">
            <img src="<?= Str::e($path) ?>" alt="<?= Str::e($alt) ?>" loading="lazy" width="640" height="480">
        </figure>
        <?php endforeach; ?>
    </div>
</div>
