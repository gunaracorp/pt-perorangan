<?php
/**
 * BLOK : cta.php — ajakan bertindak dengan efek glow.
 * FIELD: title, subtitle, cta_label, cta_url.
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
$site = \App\Core\Theme::siteData();
// Default: tombol WhatsApp bila URL kosong dan nomor tersedia.
$ctaUrl = trim((string) ($cta_url ?? ''));
if ($ctaUrl === '' && $site['whatsapp'] !== '') {
    $ctaUrl = 'https://wa.me/' . preg_replace('~\D~', '', $site['whatsapp']) . '?text=' . rawurlencode($site['wa_message']);
}
?>
<div class="container">
    <div class="cta-panel reveal">
        <div class="cta-glow" aria-hidden="true"></div>
        <h2><?= Str::e($title ?? '') ?></h2>
        <?php if (!empty($subtitle)): ?><p><?= Str::e($subtitle) ?></p><?php endif; ?>
        <?php if (!empty($cta_label) && $ctaUrl !== ''): ?>
        <a class="btn btn-primary btn-lg" href="<?= Str::e($ctaUrl) ?>"><?= Str::e($cta_label) ?></a>
        <?php endif; ?>
    </div>
</div>
