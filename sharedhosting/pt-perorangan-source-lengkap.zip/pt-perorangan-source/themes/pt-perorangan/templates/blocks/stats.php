<?php
/**
 * BLOK : stats.php — angka statistik dengan animasi counter (IntersectionObserver).
 * FIELD: title, items (Angka | Label per baris). Angka boleh berformat "500+" atau "97%".
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
?>
<div class="container">
    <?php if (!empty($title)): ?><h2 class="section-title reveal"><?= Str::e($title) ?></h2><?php endif; ?>
    <div class="stats-grid">
        <?php foreach ((array) ($items ?? []) as $i => $item):
            [$num, $label] = array_pad(explode('|', (string) $item, 2), 2, '');
            $num = trim($num);
            // Pisahkan bagian numerik dan sufiks (+, %, dll) untuk animasi counter.
            if (preg_match('~^([\d.,]+)(.*)$~u', $num, $m)) {
                $numeric = str_replace(['.', ','], '', $m[1]);
                $suffix = $m[2];
                $attrs = 'data-counter="' . Str::e($numeric) . '" data-suffix="' . Str::e($suffix) . '"';
            } else {
                $attrs = '';
            } ?>
        <div class="stat-card reveal" data-delay="<?= min($i, 5) ?>">
            <span class="stat-value" <?= $attrs ?>><?= Str::e($num) ?></span>
            <span class="stat-label"><?= Str::e(trim($label)) ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>
