<?php
/**
 * BLOK : related.php — tautan internal terkait (label | URL per baris).
 * FIELD: title, items.
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
?>
<div class="container">
    <div class="related-grid-wrap reveal">
        <?php if (!empty($title)): ?><h2 class="section-title"><?= Str::e($title) ?></h2><?php endif; ?>
        <div class="cards-grid">
            <?php foreach ((array) ($items ?? []) as $item):
                [$label, $url] = array_pad(explode('|', (string) $item, 2), 2, '');
                if (trim($url) === '') continue; ?>
            <a class="card" href="<?= Str::e(trim($url)) ?>">
                <h3><?= Str::e(trim($label) ?: trim($url)) ?></h3>
                <span class="card-link">Buka →</span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
