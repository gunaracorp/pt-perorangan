<?php
/**
 * BLOK : pricing.php — komponen biaya (memisahkan tarif resmi vs biaya jasa).
 * FIELD: title, items (Nama | Nilai | Keterangan), disclaimer.
 * AMAN? : PRIVAT. Disclaimer wajib: angka dapat berubah; bukan janji hasil.
 */

use App\Core\Str;
?>
<div class="container">
    <?php if (!empty($title)): ?><h2 class="section-title reveal"><?= Str::e($title) ?></h2><?php endif; ?>
    <div class="cards-grid pricing-grid">
        <?php foreach ((array) ($items ?? []) as $i => $item):
            [$name, $value, $note] = array_pad(explode('|', (string) $item, 3), 3, ''); ?>
        <div class="card price-card reveal" data-delay="<?= min($i, 5) ?>">
            <h3><?= Str::e(trim($name)) ?></h3>
            <p class="price-value"><?= Str::e(trim($value)) ?></p>
            <?php if (trim($note) !== ''): ?><p class="price-note"><?= Str::e(trim($note)) ?></p><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if (!empty($disclaimer)): ?><p class="muted-note reveal"><?= Str::e($disclaimer) ?></p><?php endif; ?>
</div>
