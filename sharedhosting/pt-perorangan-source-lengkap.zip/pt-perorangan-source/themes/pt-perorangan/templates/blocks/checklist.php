<?php
/**
 * BLOK : checklist.php — daftar syarat dengan tanda centang.
 * FIELD: title, note, items.
 * AMAN? : PRIVAT.
 */

use App\Core\Str;
?>
<div class="container">
    <div class="block-checklist card reveal">
        <?php if (!empty($title)): ?><h2 class="section-title"><?= Str::e($title) ?></h2><?php endif; ?>
        <ul class="check-list">
            <?php foreach ((array) ($items ?? []) as $item): ?>
            <li><?= Str::e((string) $item) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php if (!empty($note)): ?><p class="muted-note"><?= Str::e($note) ?></p><?php endif; ?>
    </div>
</div>
