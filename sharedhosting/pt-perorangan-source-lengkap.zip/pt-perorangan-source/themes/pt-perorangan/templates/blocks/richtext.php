<?php
/**
 * BLOK : richtext.php — konten teks bebas. Data SUDAH DISANITASI BlockSchema
 * (whitelist tag, tanpa script/on*) sebelum disimpan — aman dicetak mentah.
 * FIELD: html.
 * AMAN? : PRIVAT. Jangan mengubah BlockSchema tanpa memahami risiko XSS.
 */
?>
<div class="container">
    <div class="richtext reveal"><?= $html ?? '' ?></div>
</div>
