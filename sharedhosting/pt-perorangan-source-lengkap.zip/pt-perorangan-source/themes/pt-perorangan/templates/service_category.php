<?php
/**
 * TEMPLATE : service_category.php — halaman kategori layanan (hub kedua).
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
use App\Core\View;
?>
<?php View::component('breadcrumb', ['trail' => ['Beranda' => '/', 'Layanan' => '/layanan', $category['name'] => '']]); ?>

<section class="page-hero reveal">
    <div class="container">
        <p class="eyebrow">Kategori</p>
        <h1><?= Str::e($category['name']) ?></h1>
        <?php if (!empty($category['description'])): ?><p class="lead"><?= Str::e($category['description']) ?></p><?php endif; ?>
    </div>
</section>

<section class="block container reveal">
    <?php if (!empty($services)): ?>
    <div class="cards-grid">
        <?php foreach ($services as $s): ?>
        <a class="card service-card" href="/layanan/<?= Str::e($s['slug']) ?>">
            <h3><?= Str::e($s['title']) ?></h3>
            <p><?= Str::e(Str::excerpt((string) ($s['excerpt'] ?? ''), 120)) ?></p>
            <span class="card-link">Lihat detail →</span>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p>Belum ada layanan pada kategori ini.</p>
    <?php endif; ?>
</section>
