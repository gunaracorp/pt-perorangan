<?php
/**
 * TEMPLATE : service.php — halaman detail layanan (inti konversi & SEO intent).
 * UNTUK    : ServiceController::show(). Menampilkan hero layanan, fakta terstruktur
 *           (biaya resmi vs jasa, waktu, syarat), blok builder, FAQ, terkait, CTA.
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
use App\Core\View;

$trail = ['Beranda' => '/', 'Layanan' => '/layanan', $service['title'] => ''];
?>
<?php View::component('breadcrumb', ['trail' => $trail]); ?>

<article class="service-detail">
    <!-- Fakta cepat: biaya resmi ≠ biaya jasa (transparansi) -->
    <section class="service-facts container reveal">
        <div class="facts-grid">
            <?php if (($facts['official_fee'] ?? '') !== ''): ?>
            <div class="fact-card"><span class="fact-label">Tarif resmi pemerintah</span><strong><?= Str::e($facts['official_fee']) ?></strong></div>
            <?php endif; ?>
            <?php if (($facts['service_fee'] ?? '') !== ''): ?>
            <div class="fact-card"><span class="fact-label">Estimasi biaya jasa</span><strong><?= Str::e($facts['service_fee']) ?></strong></div>
            <?php endif; ?>
            <?php if (($facts['est_time'] ?? '') !== ''): ?>
            <div class="fact-card"><span class="fact-label">Estimasi waktu</span><strong><?= Str::e($facts['est_time']) ?></strong></div>
            <?php endif; ?>
            <div class="fact-card"><span class="fact-label">Cakupan wilayah</span><strong><?= Str::e($facts['region'] ?? 'Indonesia') ?></strong></div>
        </div>
    </section>

    <?php if (!empty($facts['requirements'])): ?>
    <section class="block container reveal">
        <div class="block-checklist">
            <h2>Dokumen & Syarat yang Perlu Disiapkan</h2>
            <ul class="check-list">
                <?php foreach ($facts['requirements'] as $req): ?>
                <li><?= Str::e($req) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </section>
    <?php endif; ?>

    <?php foreach (($blocks ?? []) as $block): ?>
    <?php if (!empty($block['hidden'])) continue; ?>
    <section class="block block-<?= Str::e($block['type']) ?>">
        <?php View::block($block); ?>
    </section>
    <?php endforeach; ?>

    <?php if (!empty($faqs)): ?>
    <section class="block container reveal">
        <div class="block-faq">
            <h2>Pertanyaan Umum</h2>
            <div class="faq-list">
                <?php foreach ($faqs as $f): ?>
                <details class="faq-item">
                    <summary><?= Str::e($f['question']) ?></summary>
                    <div class="faq-answer"><?= nl2br(Str::e($f['answer'])) ?></div>
                </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($related)): ?>
    <section class="block container reveal">
        <div class="related-grid-wrap">
            <h2>Layanan Terkait</h2>
            <div class="cards-grid">
                <?php foreach ($related as $rel): if ($rel['id'] === $service['id']) continue; ?>
                <a class="card service-card" href="/layanan/<?= Str::e($rel['slug']) ?>">
                    <h3><?= Str::e($rel['title']) ?></h3>
                    <p><?= Str::e(Str::excerpt((string) $rel['excerpt'], 110)) ?></p>
                    <span class="card-link">Lihat detail →</span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
</article>
