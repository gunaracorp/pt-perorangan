<?php
/**
 * TEMPLATE : contact.php — halaman kontak (form aman + honeypot + info kontak).
 * AMAN?    : PRIVAT. Form menyertakan token CSRF otomatis dari Csrf::field().
 */

use App\Core\Csrf;
use App\Core\Str;
?>
<section class="page-hero reveal">
    <div class="container">
        <p class="eyebrow">Kontak</p>
        <h1>Konsultasi dengan Tim Kami</h1>
        <p class="lead">Ceritakan kebutuhan usaha Anda — kami balas pada jam kerja (Senin–Jumat, 09.00–17.00 WIB).</p>
    </div>
</section>

<section class="block container reveal">
    <div class="contact-grid">
        <div class="contact-info">
            <?php if (!empty($site['whatsapp'])): ?>
            <div class="fact-card"><span class="fact-label">WhatsApp</span><a data-wa href="https://wa.me/<?= Str::e(preg_replace('~\D~', '', $site['whatsapp'])) ?>" rel="noopener" target="_blank"><?= Str::e($site['whatsapp']) ?></a></div>
            <?php endif; ?>
            <?php if (!empty($site['email'])): ?>
            <div class="fact-card"><span class="fact-label">Email</span><a href="mailto:<?= Str::e($site['email']) ?>"><?= Str::e($site['email']) ?></a></div>
            <?php endif; ?>
            <?php if (!empty($site['address'])): ?>
            <div class="fact-card"><span class="fact-label">Alamat</span><span><?= Str::e($site['address']) ?></span></div>
            <?php endif; ?>
            <?php if (!empty($site['maps_embed'])): ?>
            <div class="map-frame"><?= $site['maps_embed'] /* sengaja: hanya diisi admin dari embed iframe peta resmi */ ?></div>
            <?php endif; ?>
        </div>

        <form class="contact-form card" method="post" action="/kontak" novalidate>
            <?= Csrf::field() ?>
            <!-- Honeypot anti-spam: disembunyikan dari manusia -->
            <div class="hp-field" aria-hidden="true"><label>Jangan isi kolom ini<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>

            <div class="form-row">
                <label for="f-name">Nama lengkap <span aria-hidden="true">*</span></label>
                <input id="f-name" name="name" type="text" required maxlength="100" value="<?= Str::e($old['name'] ?? '') ?>">
                <?php if (!empty($errors['name'])): ?><p class="field-error"><?= Str::e($errors['name']) ?></p><?php endif; ?>
            </div>
            <div class="form-row">
                <label for="f-email">Email <span aria-hidden="true">*</span></label>
                <input id="f-email" name="email" type="email" required maxlength="150" value="<?= Str::e($old['email'] ?? '') ?>">
                <?php if (!empty($errors['email'])): ?><p class="field-error"><?= Str::e($errors['email']) ?></p><?php endif; ?>
            </div>
            <div class="form-row">
                <label for="f-phone">No. WhatsApp / telepon</label>
                <input id="f-phone" name="phone" type="tel" maxlength="30" value="<?= Str::e($old['phone'] ?? '') ?>">
            </div>
            <div class="form-row">
                <label for="f-subject">Subjek</label>
                <input id="f-subject" name="subject" type="text" maxlength="150" value="<?= Str::e($old['subject'] ?? '') ?>" placeholder="Contoh: Konsultasi pendirian PT Perorangan">
            </div>
            <div class="form-row">
                <label for="f-message">Pesan <span aria-hidden="true">*</span></label>
                <textarea id="f-message" name="message" rows="6" required maxlength="3000"><?= Str::e($old['message'] ?? '') ?></textarea>
                <?php if (!empty($errors['message'])): ?><p class="field-error"><?= Str::e($errors['message']) ?></p><?php endif; ?>
            </div>
            <button class="btn btn-primary" type="submit">Kirim Pesan</button>
            <p class="form-note">Data Anda hanya digunakan untuk membalas pesan ini (lihat <a href="/p/kebijakan-privasi">kebijakan privasi</a>).</p>
        </form>
    </div>
</section>

<?php if (!empty($success)): ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const bar = document.createElement('div');
  bar.className = 'toast toast-success';
  bar.setAttribute('role', 'status');
  bar.textContent = 'Terima kasih! Pesan Anda telah kami terima dan akan dibalas segera.';
  document.body.appendChild(bar);
  setTimeout(() => bar.remove(), 6000);
});
</script>
<?php endif; ?>
