<?php
/**
 * TEMPLATE : faq.php — halaman FAQ publik (accordion aksesibel + JSON-LD dari controller).
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
?>
<section class="page-hero reveal">
    <div class="container">
        <p class="eyebrow">Bantuan</p>
        <h1>Pertanyaan Umum</h1>
        <p class="lead">Jawaban ringkas atas pertanyaan yang paling sering diajukan pengguna.</p>
    </div>
</section>

<section class="block container reveal">
    <?php if (!empty($faqs)): ?>
    <div class="faq-list">
        <?php foreach ($faqs as $f): ?>
        <details class="faq-item">
            <summary><?= Str::e($f['question']) ?></summary>
            <div class="faq-answer"><?= nl2br(Str::e($f['answer'])) ?></div>
        </details>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p>Belum ada pertanyaan terpublikasi.</p>
    <?php endif; ?>
</section>
