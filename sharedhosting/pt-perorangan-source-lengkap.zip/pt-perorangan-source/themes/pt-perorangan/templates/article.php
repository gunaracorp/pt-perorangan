<?php
/**
 * TEMPLATE : article.php — halaman artikel (blok builder + penulis + terkait).
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
use App\Core\View;
?>
<?php View::component('breadcrumb', ['trail' => ['Beranda' => '/', 'Artikel' => '/artikel', $article['title'] => '']]); ?>

<article class="article-detail container">
    <header class="article-header reveal">
        <h1><?= Str::e($article['title']) ?></h1>
        <p class="article-meta">
            <time datetime="<?= Str::e(date('c', strtotime((string) ($article['published_at'] ?? $article['created_at'])))) ?>">
                <?= Str::e(Str::tanggalIndo($article['published_at'] ?? $article['created_at'])) ?>
            </time>
            <?php if (!empty($article['reviewed_by'])): ?>
            <span aria-hidden="true">•</span> Ditinjau oleh reviewer
            <?php endif; ?>
        </p>
    </header>

    <?php foreach (($blocks ?? []) as $block): ?>
    <?php if (!empty($block['hidden'])) continue; ?>
    <section class="block block-<?= Str::e($block['type']) ?>">
        <?php View::block($block); ?>
    </section>
    <?php endforeach; ?>

    <?php if (!empty($related)): ?>
    <section class="block reveal">
        <div class="related-grid-wrap">
            <h2>Artikel Terkait</h2>
            <div class="cards-grid">
                <?php foreach ($related as $rel): if ($rel['id'] === $article['id']) continue; ?>
                <a class="card article-card" href="/artikel/<?= Str::e($rel['slug']) ?>">
                    <h3><?= Str::e($rel['title']) ?></h3>
                    <p><?= Str::e(Str::excerpt((string) ($rel['excerpt'] ?? ''), 110)) ?></p>
                    <span class="card-link">Baca →</span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
</article>
