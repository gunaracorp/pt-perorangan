<?php
/**
 * TEMPLATE : page.php — halaman builder generik (beranda, tentang, halaman intent).
 * UNTUK    : Dipakai HomeController & PageController. $blocks dirender berurutan.
 * AMAN?    : PRIVAT.
 */

use App\Core\Str;
use App\Core\View;

$trail = ['Beranda' => '/'];
if (($page['slug'] ?? '') !== 'beranda') {
    $trail[$page['title']] = '';
}
?>
<?php View::component('breadcrumb', ['trail' => $trail]); ?>

<?php if (!empty($blocks)): ?>
<?php foreach ($blocks as $block): ?>
<?php if (!empty($block['hidden'])) continue; ?>
<section class="block block-<?= Str::e($block['type']) ?>">
    <?php View::block($block); ?>
</section>
<?php endforeach; ?>
<?php else: ?>
<section class="block container empty-state">
    <h1><?= Str::e($page['title'] ?? 'Halaman') ?></h1>
    <p>Halaman ini belum memiliki konten. Sunting dari dashboard admin untuk mengisinya.</p>
</section>
<?php endif; ?>
