<?php
/**
 * FILE   : app/Services/ImportService.php
 * FUNGSI : Impor massal layanan/halaman dari CSV/JSON dengan laporan error per baris.
 * UNTUK  : /admin/impor — produksi halaman skala besar dengan validasi schema.
 * KENAPA : Ratusan halaman tidak mungkin dibuat manual; tapi SEMUA baris tetap
 *          divalidasi (slug unik, title, konten min) dan masuk sebagai DRAFT.
 * TERKAIT: admin/ImportController, QualityGate (di review saat publish)
 * AMAN?  : PRIVAT.
 * PEMULA : Format CSV kolom: title,slug,excerpt,body_plain,category,official_fee,service_fee,est_time
 *          Baris gagal dilaporkan; baris sukses jadi draft untuk direview dulu.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\Str;
use App\Models\Service;

final class ImportService
{
    /** @return array{ok:int, fail:int, report: array<int, array{row:int, ok:bool, msg:string}>} */
    public static function importServices(string $rawContent, bool $isCsv): array
    {
        $rows = $isCsv ? self::parseCsv($rawContent) : self::parseJson($rawContent);
        $report = [];
        $ok = 0;
        $fail = 0;
        $now = date('Y-m-d H:i:s');

        foreach ($rows as $i => $row) {
            $line = $i + 1;
            $title = trim((string) ($row['title'] ?? ''));
            $body = trim((string) ($row['body'] ?? $row['body_plain'] ?? ''));
            $slug = trim((string) ($row['slug'] ?? '')) ?: Str::slug($title);

            $errors = [];
            if ($title === '') {
                $errors[] = 'kolom title kosong';
            }
            if (mb_strlen($body) < 200) {
                $errors[] = 'body terlalu pendek (<200 karakter) — anti thin content';
            }
            if (!preg_match('~^[a-z0-9]+(?:-[a-z0-9]+)*$~', $slug)) {
                $slug = Str::slug($slug);
            }
            if (Service::findBySlug($slug) !== null) {
                $slug .= '-' . Str::random(3);
                $report[] = ['row' => $line, 'ok' => true, 'msg' => 'slug duplikat → diubah menjadi "' . $slug . '"'];
            }

            if ($errors !== []) {
                $fail++;
                $report[] = ['row' => $line, 'ok' => false, 'msg' => implode('; ', $errors)];
                continue;
            }

            $blocks = [
                ['type' => 'hero', 'hidden' => false, 'data' => [
                    'title' => $title, 'subtitle' => trim((string) ($row['excerpt'] ?? '')), 'align' => 'left',
                ]],
                ['type' => 'richtext', 'hidden' => false, 'data' => [
                    'html' => '<p>' . nl2br(Str::e($body)) . '</p>',
                ]],
            ];
            Service::insert([
                'title'       => $title,
                'slug'        => $slug,
                'excerpt'     => Str::excerpt((string) ($row['excerpt'] ?? $body), 200),
                'blocks'      => json_encode($blocks, JSON_UNESCAPED_UNICODE),
                'seo'         => json_encode([
                    'title'       => $title,
                    'description' => Str::excerpt((string) ($row['excerpt'] ?? $body), 156),
                ], JSON_UNESCAPED_UNICODE),
                'facts'       => json_encode([
                    'official_fee' => trim((string) ($row['official_fee'] ?? '')),
                    'service_fee'  => trim((string) ($row['service_fee'] ?? '')),
                    'est_time'     => trim((string) ($row['est_time'] ?? '')),
                ], JSON_UNESCAPED_UNICODE),
                'status'      => 'draft',
                'sort_order'  => 100 + $line,
                'created_at'  => $now,
                'updated_at'  => $now,
            ]);
            $ok++;
            $report[] = ['row' => $line, 'ok' => true, 'msg' => 'draft dibuat: ' . $title];
        }
        return ['ok' => $ok, 'fail' => $fail, 'report' => $report];
    }

    /** @return array<int, array<string,string>> */
    private static function parseCsv(string $raw): array
    {
        $lines = preg_split('~\r?\n~', trim($raw)) ?: [];
        if ($lines === []) {
            return [];
        }
        $header = array_map(static fn($h) => strtolower(trim($h, " \t\"'")), str_getcsv(array_shift($lines)));
        $rows = [];
        foreach ($lines as $line) {
            if (trim($line) === '') {
                continue;
            }
            $cells = str_getcsv($line);
            $row = [];
            foreach ($header as $idx => $key) {
                $row[$key] = $cells[$idx] ?? '';
            }
            $rows[] = $row;
        }
        return $rows;
    }

    /** @return array<int, array<string,string>> */
    private static function parseJson(string $raw): array
    {
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return [];
        }
        // Bungkus bila berupa objek tunggal.
        if (isset($data['title'])) {
            $data = [$data];
        }
        $out = [];
        foreach ($data as $item) {
            if (is_array($item)) {
                $out[] = array_map('strval', $item);
            }
        }
        return $out;
    }
}
