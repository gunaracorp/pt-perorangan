<?php
/**
 * FILE   : app/Services/SitemapService.php
 * FUNGSI : Menghasilkan sitemap index + sitemap tersegmentasi (pages/services/articles).
 * UNTUK  : Route /sitemap.xml, /sitemap-pages.xml, /sitemap-services.xml, /sitemap-articles.xml.
 * KENAPA : Untuk ratusan/ribuan URL, sitemap index tersegmentasi lebih mudah dikelola
 *          dan hanya memuat URL kanonis layak indeks (published saja).
 * TERKAIT: app/Core/Cache.php, config base_url, admin/SeoController (regenerate)
 * AMAN?  : PRIVAT.
 * PEMULA : Sitemap XML = daftar URL yang memberi tahu Google apa yang boleh dirayapi.
 */

declare(strict_types=1);

namespace App\Services;

use App\Core\App;
use App\Core\Cache;
use App\Models\Article;
use App\Models\Category;
use App\Models\Page;
use App\Models\Service;

final class SitemapService
{
    public static function urlset(array $urls): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
            . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($urls as $u) {
            $loc = App::url((string) $u['loc']);
            $xml .= "  <url>\n    <loc>" . htmlspecialchars($loc, ENT_XML1, 'UTF-8') . "</loc>\n";
            if (!empty($u['lastmod'])) {
                $xml .= '    <lastmod>' . date('Y-m-d\TH:i:sP', strtotime((string) $u['lastmod'])) . "</lastmod>\n";
            }
            $xml .= "  </url>\n";
        }
        return $xml . "</urlset>\n";
    }

    public static function index(): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
            . '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach (['pages', 'services', 'articles'] as $segment) {
            $xml .= "  <sitemap>\n    <loc>" . htmlspecialchars(App::url('/sitemap-' . $segment . '.xml'), ENT_XML1, 'UTF-8') . "</loc>\n  </sitemap>\n";
        }
        return $xml . "</sitemapindex>\n";
    }

    /** Kumpulan URL halaman (termasuk /p/{slug}, hub, dan halaman khusus). */
    public static function pagesUrls(): array
    {
        $urls = [
            ['loc' => '/', 'lastmod' => date('Y-m-d H:i:s')],
            ['loc' => '/layanan', 'lastmod' => date('Y-m-d H:i:s')],
            ['loc' => '/artikel', 'lastmod' => date('Y-m-d H:i:s')],
            ['loc' => '/faq', 'lastmod' => date('Y-m-d H:i:s')],
            ['loc' => '/kontak', 'lastmod' => date('Y-m-d H:i:s')],
        ];
        foreach (Page::forSitemap() as $p) {
            if ($p['slug'] === 'beranda') {
                continue; // beranda sudah / di atas
            }
            $urls[] = ['loc' => '/p/' . $p['slug'], 'lastmod' => $p['updated_at']];
        }
        foreach (Category::published() as $c) {
            $urls[] = ['loc' => '/layanan/kategori/' . $c['slug'], 'lastmod' => $c['updated_at'] ?? date('Y-m-d H:i:s')];
        }
        return $urls;
    }

    public static function servicesUrls(): array
    {
        $urls = [];
        foreach (Service::forSitemap() as $s) {
            $urls[] = ['loc' => '/layanan/' . $s['slug'], 'lastmod' => $s['updated_at']];
        }
        return $urls;
    }

    public static function articlesUrls(): array
    {
        $urls = [];
        foreach (Article::forSitemap() as $a) {
            $urls[] = ['loc' => '/artikel/' . $a['slug'], 'lastmod' => $a['updated_at']];
        }
        return $urls;
    }

    /** Keluarkan XML sesuai nama sitemap; dipanggil controller. */
    public static function output(string $which): void
    {
        header('Content-Type: application/xml; charset=UTF-8');
        $key = 'sitemap_' . $which;
        $xml = Cache::remember($key, 600, static function () use ($which) {
            return match ($which) {
                'index'    => self::index(),
                'pages'    => self::urlset(self::pagesUrls()),
                'services' => self::urlset(self::servicesUrls()),
                'articles' => self::urlset(self::articlesUrls()),
                default    => self::index(),
            };
        });
        echo $xml;
    }
}
