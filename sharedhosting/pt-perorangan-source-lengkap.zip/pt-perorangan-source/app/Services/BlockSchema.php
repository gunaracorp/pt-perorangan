<?php
/**
 * FILE   : app/Services/BlockSchema.php
 * FUNGSI : Manajer schema blok (whitelist tipe blok + field + validasi) dari config/blocks.php.
 * UNTUK  : Editor visual (form dinamis) dan sanitasi server-side sebelum simpan JSON.
 * KENAPA : Kunci keamanan editor: TIDAK ADA eksekusi kode mentah. Hanya field
 *          terdaftar yang diterima; HTML hanya di field bertipe "html" yang disanitasi.
 * TERKAIT: config/blocks.php, admin Pages/Services/ArticlesController, tema templates/blocks/*
 * AMAN?  : PRIVAT.
 * PEMULA : "Schema" = daftar aturan bentuk data. Field di luar schema dibuang otomatis.
 */

declare(strict_types=1);

namespace App\Services;

final class BlockSchema
{
    /** @return array<string, array{label:string, desc:string, fields:array<string,array>}> */
    public static function all(): array
    {
        $schema = require CONFIG_DIR . '/blocks.php';
        return is_array($schema) ? $schema : [];
    }

    public static function types(): array
    {
        return array_keys(self::all());
    }

    public static function definition(string $type): ?array
    {
        return self::all()[$type] ?? null;
    }

    /**
     * Sanitasi daftar blok dari editor: buang tipe tak dikenal, buang field di luar
     * schema, sanitasi tiap field sesuai tipe data. Mengembalikan array bersih.
     * @param array<int, array> $blocks
     */
    public static function sanitizeBlocks(array $blocks): array
    {
        $clean = [];
        foreach ($blocks as $block) {
            if (!is_array($block)) {
                continue;
            }
            $type = (string) ($block['type'] ?? '');
            $def = self::definition($type);
            if ($def === null) {
                continue; // tipe tidak terdaftar → ditolak
            }
            $dataIn = is_array($block['data'] ?? null) ? $block['data'] : [];
            $dataOut = [];
            foreach ($def['fields'] as $field => $meta) {
                if (!array_key_exists($field, $dataIn)) {
                    continue;
                }
                $dataOut[$field] = self::sanitizeValue($meta['type'] ?? 'text', $dataIn[$field]);
            }
            $clean[] = [
                'type'   => $type,
                'hidden' => (bool) ($block['hidden'] ?? false),
                'data'   => $dataOut,
            ];
        }
        return $clean;
    }

    /** Sanitasi satu nilai sesuai tipe field schema. */
    private static function sanitizeValue(string $type, mixed $value): mixed
    {
        switch ($type) {
            case 'html':
                // HTML terbatas: hanya tag aman, tanpa script/style/on*.
                return self::sanitizeHtml((string) $value);
            case 'text':
                return \App\Core\Str::clean((string) $value);
            case 'multiline':
                return \App\Core\Str::clean((string) $value);
            case 'url':
                $v = trim((string) $value);
                // Izinkan path internal dan URL absolut http(s) saja.
                if ($v === '') {
                    return '';
                }
                if (str_starts_with($v, '/')) {
                    return str_replace(['"', "'", '<', '>'], '', $v);
                }
                return filter_var($v, FILTER_VALIDATE_URL) ? $v : '';
            case 'select':
                return \App\Core\Str::clean((string) $value);
            case 'list':
                $arr = is_array($value) ? $value : json_decode((string) $value, true);
                if (!is_array($arr)) {
                    return [];
                }
                return array_values(array_map(static fn($item) => \App\Core\Str::clean((string) $item), $arr));
            case 'image':
                // Hanya nama file media yang terdaftar (path relatif /media/...).
                $v = trim((string) $value);
                return preg_match('~^/media/[A-Za-z0-9._-]+$~', $v) ? $v : '';
            case 'boolean':
                return (bool) $value;
            default:
                return \App\Core\Str::clean((string) $value);
        }
    }

    /** Sanitasi HTML: izinkan whitelist tag, buang event handler & script. */
    public static function sanitizeHtml(string $html): string
    {
        $allowed = '<p><br><b><strong><i><em><u><ul><ol><li><h2><h3><h4><blockquote><a><table><thead><tbody><tr><td><th><figure><figcaption>';
        $html = strip_tags($html, $allowed);
        // Buang atribut berbahaya (on*, javascript:, style berisi expression).
        $html = preg_replace('~\son\w+="[^"]*"~i', '', $html) ?? $html;
        $html = preg_replace("~\son\w+='[^']*'~i", '', $html) ?? $html;
        $html = preg_replace('~javascript\s*:~i', '', $html) ?? $html;
        // Atribut <a> dibatasi href + rel + target.
        $html = preg_replace_callback('~<a\b[^>]*>~i', static function ($m) {
            $tag = $m[0];
            if (preg_match('~href\s*=\s*("([^"]*)"|\'([^\']*)\')~i', $tag, $mm)) {
                $href = $mm[2] ?? $mm[3] ?? '';
                $href = filter_var($href, FILTER_VALIDATE_URL) ?: (str_starts_with($href, '/') ? $href : '');
                if ($href !== '') {
                    return '<a href="' . \App\Core\Str::e($href) . '"' . (str_starts_with($href, 'http') ? ' rel="noopener nofollow"' : '') . '>';
                }
            }
            return '<a>';
        }, $html) ?? $html;
        return $html;
    }

    /** Ekstrak teks polos dari blok (untuk hitung panjang konten & preview). */
    public static function blocksToPlainText(array $blocks): string
    {
        $parts = [];
        foreach ($blocks as $b) {
            $d = is_array($b['data'] ?? null) ? $b['data'] : [];
            foreach ($d as $v) {
                if (is_scalar($v)) {
                    $parts[] = (string) $v;
                } elseif (is_array($v)) {
                    $parts = array_merge($parts, array_map('strval', array_filter($v, 'is_scalar')));
                }
            }
        }
        return trim(implode(' ', $parts));
    }
}
