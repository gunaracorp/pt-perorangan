<?php
/**
 * FILE   : app/Services/QualityGate.php
 * FUNGSI : Pemeriksa kualitas halaman sebelum boleh PUBLISH (gerbang kualitas anti thin content).
 * UNTUK  : Editor halaman/layanan/artikel — tombol "Terbitkan" dicek dulu di server.
 * KENAPA : Mencegah halaman tipis/duplikat masuk indeks (selaras spam policies Google):
 *          - title & meta description wajib dan panjang wajar
 *          - minimal satu H1 + konten bermakna (>= 300 karakter teks)
 *          - minimal 2 blok berisi
 *          - sumber resmi wajib untuk konten legal/regulasi (kata kunci tertentu)
 * TERKAIT: admin Pages/Services/ArticlesController (cek sebelum status published)
 * AMAN?  : PRIVAT.
 * PEMULA : "Thin content" = halaman tanpa nilai unik → berisiko tidak diindeks/murah.
 */

declare(strict_types=1);

namespace App\Services;

final class QualityGate
{
    /** @return array{pass: bool, issues: string[], warnings: string[], score: int} */
    public static function check(string $type, array $data): array
    {
        $issues = [];
        $warnings = [];
        $score = 100;

        $title = trim((string) ($data['title'] ?? ''));
        $seo = is_array($data['seo'] ?? null) ? $data['seo'] : (json_decode((string) ($data['seo'] ?? '{}'), true) ?: []);
        $blocks = is_array($data['blocks'] ?? null) ? $data['blocks'] : (json_decode((string) ($data['blocks'] ?? '[]'), true) ?: []);

        // 1. Title & description
        if ($title === '') {
            $issues[] = 'Judul wajib diisi.';
        } elseif (mb_strlen($title) < 15) {
            $warnings[] = 'Judul sangat pendek (<15 karakter) — pertimbangkan judul yang lebih deskriptif.';
            $score -= 5;
        }
        $desc = trim((string) ($seo['description'] ?? ''));
        if ($desc === '') {
            $issues[] = 'Meta description wajib diisi (dipakai di hasil pencarian).';
        } elseif (mb_strlen($desc) < 70) {
            $warnings[] = 'Meta description pendek (<70 karakter) — manfaatkan 120–156 karakter.';
            $score -= 10;
        }

        // 2. Konten blok
        $filled = 0;
        $textLen = 0;
        foreach ($blocks as $b) {
            $d = is_array($b['data'] ?? null) ? $b['data'] : [];
            $serialized = mb_strtolower(trim(strip_tags(implode(' ', array_map('strval', array_filter($d, 'is_scalar'))))));
            $visible = ($b['hidden'] ?? false) ? 0 : 1;
            if ($visible && $serialized !== '') {
                $filled++;
                $textLen += mb_strlen($serialized, 'UTF-8');
            }
        }
        if ($filled < 2) {
            $issues[] = 'Minimal 2 section/blok berisi agar halaman memiliki nilai mandiri.';
        }
        if ($textLen < 300) {
            $issues[] = 'Total teks halaman < 300 karakter — berisiko thin content. Tambahkan penjelasan, syarat, proses, atau FAQ.';
        }

        // 3. Kata kunci regulasi → wajib sumber resmi
        $blockText = BlockSchema::blocksToPlainText($blocks);
        $allText = mb_strtolower($title . ' ' . $desc . ' ' . $blockText);
        $regulatedTerms = ['permenkum', 'pp 8/2021', 'pp 7/2021', 'uu cipta kerja', 'nib', 'oss-rba', 'pnbp', 'kemenkumham', 'ahu'];
        foreach ($regulatedTerms as $term) {
            if (str_contains($allText, $term)) {
                if (trim((string) ($data['sources'] ?? '')) === '' && trim((string) ($seo['sources'] ?? '')) === '') {
                    $issues[] = 'Halaman menyebut regulasi/tarif resmi — wajib mencantumkan sumber resmi (kolom "Sumber resmi").';
                }
                break;
            }
        }

        // 4. Duplikat title (di sisi pemanggil)

        $score = max(0, min(100, $score - count($issues) * 15));
        return ['pass' => $issues === [], 'issues' => $issues, 'warnings' => $warnings, 'score' => $score];
    }
}
