<?php
/**
 * FILE   : app/Services/SeoService.php
 * FUNGSI : Membangun JSON-LD (schema.org) yang valid dari fakta yang BENAR-BENAR tampil.
 * UNTUK  : Head tema; tipe: Organization, WebSite, Service, FAQPage, Article, BreadcrumbList.
 * KENAPA : Structured data hanya boleh menandai data yang terlihat di halaman
 *          (aturan Google Search Central) — jangan mengarang rating/harga/review.
 * TERKAIT: app/Core/Theme.php, tema components/head.php
 * AMAN?  : PRIVAT.
 * PEMULA : JSON-LD = data terstruktur yang membantu mesin pencari memahami halaman.
 */

declare(strict_types=1);

namespace App\Services;

final class SeoService
{
    public static function organization(array $site): array
    {
        $out = [
            '@context' => 'https://schema.org',
            '@type'    => 'ProfessionalService',
            'name'     => $site['name'],
            'url'      => \App\Core\App::url('/'),
        ];
        if ($site['phone'] !== '') {
            $out['telephone'] = $site['phone'];
        }
        if ($site['email'] !== '') {
            $out['email'] = $site['email'];
        }
        if ($site['address'] !== '') {
            $out['address'] = ['@type' => 'PostalAddress', 'streetAddress' => $site['address'], 'addressCountry' => 'ID'];
        }
        if ($site['logo'] !== '') {
            $out['logo'] = \App\Core\App::url($site['logo']);
        }
        $social = array_values(array_filter(array_values($site['social'])));
        if ($social !== []) {
            $out['sameAs'] = $social;
        }
        return $out;
    }

    public static function website(array $site): array
    {
        return [
            '@context'   => 'https://schema.org',
            '@type'      => 'WebSite',
            'name'       => $site['name'],
            'url'        => \App\Core\App::url('/'),
            'inLanguage' => 'id-ID',
        ];
    }

    /** JSON-LD Service dari data layanan (harga hanya bila ditampilkan di halaman). */
    public static function service(array $service, array $facts): array
    {
        $out = [
            '@context'  => 'https://schema.org',
            '@type'     => 'Service',
            'name'      => (string) $service['title'],
            'url'       => \App\Core\App::url('/layanan/' . $service['slug']),
            'provider'  => ['@type' => 'Organization', 'name' => \App\Core\Theme::siteData()['name']],
            'areaServed' => ['@type' => 'Country', 'name' => (string) ($facts['region'] ?? 'Indonesia')],
        ];
        if (!empty($service['excerpt'])) {
            $out['description'] = \App\Core\Str::excerpt((string) $service['excerpt'], 300);
        }
        $fee = trim((string) ($facts['service_fee'] ?? ''));
        if ($fee !== '' && preg_match('~^(?:Rp\s?)?[\d.,]+~i', $fee)) {
            // Hanya bila ada harga jasa tampil; bukan tarif resmi pemerintah.
            $out['offers'] = ['@type' => 'Offer', 'priceCurrency' => 'IDR', 'description' => 'Estimasi biaya jasa'];
        }
        return $out;
    }

    /** FAQPage hanya untuk pasangan Q&A yang tampil di halaman. */
    public static function faqPage(array $faqs): array
    {
        $entities = [];
        foreach ($faqs as $f) {
            $q = trim((string) ($f['question'] ?? ''));
            $a = trim((string) ($f['answer'] ?? ''));
            if ($q === '' || $a === '') {
                continue;
            }
            $entities[] = [
                '@type'    => 'Question',
                'name'     => $q,
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a],
            ];
        }
        if ($entities === []) {
            return [];
        }
        return ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $entities];
    }

    public static function article(array $article, string $authorName = ''): array
    {
        $out = [
            '@context'   => 'https://schema.org',
            '@type'      => 'Article',
            'headline'   => \App\Core\Str::excerpt((string) $article['title'], 110),
            'datePublished' => (string) ($article['published_at'] ?? $article['created_at']),
            'dateModified'  => (string) ($article['updated_at'] ?? $article['created_at']),
            'url'        => \App\Core\App::url('/artikel/' . $article['slug']),
            'inLanguage' => 'id-ID',
        ];
        if ($authorName !== '') {
            $out['author'] = ['@type' => 'Person', 'name' => $authorName];
        }
        return $out;
    }

    public static function breadcrumb(array $trail): array
    {
        $items = [];
        $pos = 1;
        foreach ($trail as $label => $url) {
            $items[] = [
                '@type'    => 'ListItem',
                'position' => $pos++,
                'name'     => (string) $label,
                'item'     => \App\Core\App::url((string) $url),
            ];
        }
        return ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items];
    }
}
