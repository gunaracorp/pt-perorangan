<?php
/**
 * FILE   : app/Controllers/FaqController.php
 * FUNGSI : Halaman FAQ publik /faq dengan JSON-LD FAQPage.
 * TERKAIT: app/Models/Faq.php, admin/FaqController
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;
use App\Models\Faq;
use App\Services\SeoService;

final class FaqController
{
    public function index(): void
    {
        $faqs = Faq::published();
        View::render('faq', [
            'faqs' => $faqs,
            'seo' => [
                'title' => 'Pertanyaan Umum (FAQ)',
                'description' => 'Jawaban atas pertanyaan paling sering diajukan tentang pendirian PT Perorangan, biaya, syarat, dan proses.',
                'jsonld' => [SeoService::faqPage($faqs)],
            ],
        ]);
    }
}
