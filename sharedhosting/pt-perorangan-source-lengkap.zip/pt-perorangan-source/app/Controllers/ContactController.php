<?php
/**
 * FILE   : app/Controllers/ContactController.php
 * FUNGSI : Formulir kontak (/kontak): tampil + terima POST dengan CSRF, validasi,
 *          penyimpanan ke database, dan honeypot anti-spam sederhana.
 * TERKAIT: app/Models/ContactMessage.php, admin/MessagesController
 * AMAN?  : PRIVAT.
 * PEMULA : Honeypot = kolom tersembunyi; manusia tidak mengisinya, bot isinya → dibuang.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Csrf;
use App\Core\Session;
use App\Core\Validator;
use App\Core\View;
use App\Models\ContactMessage;

final class ContactController
{
    public function index(): void
    {
        View::render('contact', [
            'old' => ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''],
            'errors' => [],
            'success' => Session::get('_contact_success') ?? false,
            'seo' => [
                'title' => 'Kontak & Konsultasi',
                'description' => 'Hubungi tim kami untuk konsultasi pendirian PT Perorangan, NIB, dan legalitas usaha.',
            ],
        ]);
        Session::forget('_contact_success');
    }

    public function submit(): void
    {
        Csrf::guard();

        // Honeypot: kolom 'website' disembunyikan; bot biasanya mengisinya.
        if (trim((string) ($_POST['website'] ?? '')) !== '') {
            Session::flash('success', 'Terima kasih! Pesan Anda telah kami terima.');
            header('Location: /kontak');
            exit;
        }

        $data = [
            'name'    => \App\Core\Str::clean((string) ($_POST['name'] ?? '')),
            'email'   => \App\Core\Str::clean((string) ($_POST['email'] ?? '')),
            'phone'   => \App\Core\Str::clean((string) ($_POST['phone'] ?? '')),
            'subject' => \App\Core\Str::clean((string) ($_POST['subject'] ?? '')),
            'message' => \App\Core\Str::clean((string) ($_POST['message'] ?? '')),
        ];

        $v = Validator::make($data, [
            'name'    => 'required|min:2|max:100',
            'email'   => 'required|email|max:150',
            'phone'   => 'max:30',
            'subject' => 'max:150',
            'message' => 'required|min:10|max:3000',
        ]);

        if ($v->fails()) {
            View::render('contact', [
                'old' => $data,
                'errors' => $v->errors(),
                'success' => false,
                'seo' => ['title' => 'Kontak & Konsultasi', 'description' => 'Formulir konsultasi.'],
            ]);
            return;
        }

        if (app_config('features.contact_store', true)) {
            ContactMessage::create($data['name'], $data['email'], $data['phone'], $data['subject'], $data['message']);
        }
        Session::set('_contact_success', true);
        header('Location: /kontak');
        exit;
    }
}
