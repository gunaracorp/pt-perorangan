<?php
/**
 * FILE   : app/Controllers/HomeController.php
 * FUNGSI : Menampilkan beranda dari halaman slug 'beranda' (page builder) atau default.
 * UNTUK  : Route '/'. Konten beranda diedit dari /admin/halaman → "Beranda".
 * KENAPA : Beranda = halaman builder biasa sehingga admin bisa mengubahnya visual.
 * TERKAIT: app/Models/Page.php, admin/PagesController, tema templates/page.php
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;
use App\Models\Page;
use App\Services\SeoService;
use App\Services\BlockSchema;

final class HomeController
{
    public function index(): void
    {
        $page = Page::home();

        if ($page) {
            $blocks = Page::blocksOf($page);
            $seo = Page::seoOf($page);
        } else {
            // Konten cadangan bila installer belum membuat halaman beranda.
            $blocks = [
                ['type' => 'hero', 'hidden' => false, 'data' => [
                    'badge' => 'Layanan Legalitas UMKM',
                    'title' => 'Pendirian PT Perorangan, Cepat & Resmi',
                    'subtitle' => 'Didampingi dari pemeriksaan nama hingga penerbitan NIB melalui portal resmi.',
                    'cta_label' => 'Konsultasi Gratis', 'cta_url' => '/kontak', 'align' => 'center',
                ]],
                ['type' => 'features', 'hidden' => false, 'data' => [
                    'title' => 'Mengapa PT Perorangan?',
                    'items' => [
                        'Tanpa notaris | Cukup surat pernyataan pendirian, tanpa akta notaris.',
                        'Biaya resmi terjangkau | PNBP pemerintah hanya Rp50.000.',
                        'Badan hukum sungguhan | Perlindungan tanggung jawab terbatas.',
                        'Proses online | Difasilitasi portal resmi + OSS-RBA.',
                    ],
                ]],
                ['type' => 'cta', 'hidden' => false, 'data' => [
                    'title' => 'Siap mendirikan PT Perorangan Anda?',
                    'subtitle' => 'Konsultasikan kebutuhan Anda dengan tim kami.',
                    'cta_label' => 'Hubungi Kami', 'cta_url' => '/kontak',
                ]],
            ];
            $seo = [
                'title' => 'Jasa Pendirian PT Perorangan — Cepat, Resmi, Terpandu',
                'description' => 'Dampingan lengkap mendirikan PT Perorangan: cek nama, surat pernyataan pendirian di portal resmi AHU, PNBP Rp50.000, hingga NIB via OSS-RBA.',
            ];
        }

        $faqs = \App\Models\Faq::published(null, 6);
        $jsonld = [
            SeoService::organization(\App\Core\Theme::siteData()),
            SeoService::website(\App\Core\Theme::siteData()),
        ];
        if ($faqs !== []) {
            $jsonld[] = SeoService::faqPage($faqs);
        }

        View::render('page', [
            'page' => $page ?: ['title' => 'Beranda', 'slug' => 'beranda'],
            'blocks' => $blocks,
            'seo' => array_merge($seo, ['jsonld' => $jsonld]),
            'faqs' => $faqs,
        ]);
    }
}
