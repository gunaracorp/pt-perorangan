<?php
/**
 * FILE   : app/Controllers/ServiceController.php
 * FUNGSI : Hub layanan (/layanan), kategori (/layanan/kategori/{slug}), dan detail (/layanan/{slug}).
 * UNTUK  : Halaman layanan utama proyek — tempat SEO intent berkumpul.
 * KENAPA : Hub → layanan memberi struktur internal linking yang membantu pengguna.
 * TERKAIT: app/Models/Service.php, Category, admin/ServicesController
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;
use App\Models\Category;
use App\Models\Faq;
use App\Models\Service;
use App\Services\SeoService;
use App\Services\BlockSchema;

final class ServiceController
{
    public function index(): void
    {
        $categories = Category::published();
        $services = Service::published();
        View::render('service_index', [
            'services' => $services,
            'categories' => $categories,
            'seo' => [
                'title' => 'Layanan Legalitas Usaha',
                'description' => 'Jelajahi layanan pendirian PT Perorangan, NIB/OSS, konsultasi KBLI, dan kepatuhan usaha — lengkap dengan syarat, proses, dan estimasi biaya.',
            ],
        ]);
    }

    public function category(string $slug): void
    {
        $category = Category::findPublished($slug);
        if (!$category) {
            View::renderErrorPage(404, 'Kategori layanan tidak ditemukan.');
            return;
        }
        $services = Service::published(0, (int) $category['id']);
        View::render('service_category', [
            'category' => $category,
            'services' => $services,
            'seo' => array_merge(Category::seoOf($category), [
                'title' => trim((string) (Category::seoOf($category)['title'] ?? '')) ?: $category['title'],
            ]),
        ]);
    }

    public function show(string $slug): void
    {
        $service = Service::findPublished($slug);
        if (!$service) {
            View::renderErrorPage(404, 'Layanan tidak ditemukan.');
            return;
        }
        $blocks = Service::blocksOf($service);
        $facts = Service::factsOf($service);
        $faqs = Faq::published((int) $service['id'], 10);
        $related = Service::published(6);
        $jsonld = [
            SeoService::service($service, $facts),
            SeoService::breadcrumb(['Beranda' => '/', 'Layanan' => '/layanan', $service['title'] => '/layanan/' . $slug]),
        ];
        if ($faqs !== []) {
            $jsonld[] = SeoService::faqPage($faqs);
        }
        View::render('service', [
            'service' => $service,
            'blocks' => $blocks,
            'facts' => $facts,
            'faqs' => $faqs,
            'related' => $related,
            'seo' => array_merge(Service::seoOf($service), ['jsonld' => $jsonld]),
        ]);
    }
}
