<?php
/**
 * FILE   : app/Controllers/SitemapController.php
 * FUNGSI : Melayani sitemap XML tersegmentasi + robots.txt dinamis.
 * UNTUK  : /sitemap.xml, /sitemap-pages.xml, /sitemap-services.xml, /sitemap-articles.xml, /robots.txt
 * KENAPA : robots.txt dinamis agar base_url selalu benar & admin tidak perlu edit file.
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Services\SitemapService;

final class SitemapController
{
    public function index(): void
    {
        SitemapService::output('index');
    }

    public function pages(): void
    {
        SitemapService::output('pages');
    }

    public function services(): void
    {
        SitemapService::output('services');
    }

    public function articles(): void
    {
        SitemapService::output('articles');
    }

    public function robots(): void
    {
        header('Content-Type: text/plain; charset=UTF-8');
        $base = rtrim((string) app_config('base_url', ''), '/');
        echo "User-agent: *\n";
        echo "Allow: /\n";
        echo "Disallow: /admin\n";
        echo "Disallow: /cari\n";
        echo "Disallow: /preview\n";
        echo "Disallow: /theme-assets/\n";
        echo "\nSitemap: " . $base . "/sitemap.xml\n";
    }
}
