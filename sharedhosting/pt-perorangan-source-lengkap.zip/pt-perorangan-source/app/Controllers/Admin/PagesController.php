<?php
/**
 * FILE   : app/Controllers/Admin/PagesController.php
 * FUNGSI : CRUD halaman + EDITOR VISUAL (page builder) + pratinjau + revisi + quality gate.
 * UNTUK  : Semua halaman builder: beranda, tentang, halaman intent, dll.
 * KENAPA : Admin mengubah halaman TANPA menyentuh kode; setiap simpan:
 *          (1) CSRF dicek, (2) blok disanitasi BlockSchema, (3) revisi dicatat,
 *          (4) cache dibersihkan, (5) publish lewat QualityGate.
 * TERKAIT: app/Services/BlockSchema.php, app/Models/Page.php, Revision.php
 * AMAN?  : PRIVAT. Seluruh aksi divalidasi server-side; peran: content.* (editor+).
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Session;
use App\Core\Str;
use App\Models\Page;
use App\Models\Revision;
use App\Services\BlockSchema;
use App\Services\QualityGate;

final class PagesController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $pages = Page::all('updated_at DESC', 200);
        $this->render('pages/index', ['pages' => $pages]);
    }

    public function create(): void
    {
        $this->require('content.*');
        $this->render('pages/edit', [
            'page' => null,
            'blocks' => [],
            'seo' => [],
            'blockDefs' => BlockSchema::all(),
            'mediaList' => \App\Models\Media::search('', 60),
        ]);
    }

    public function store(): void
    {
        $this->require('content.*');
        $this->csrf();
        $data = $this->collectPageData(0);
        $id = Page::saveWithRevision($data, Auth::id(), 'Dibuat');
        $this->ok('/admin/halaman/' . $id . '/edit', 'Halaman dibuat. Status: ' . $data['status'] . '.');
    }

    public function edit(string $id): void
    {
        $this->require('content.view');
        $page = Page::find((int) $id);
        if (!$page) {
            $this->fail('/admin/halaman', 'Halaman tidak ditemukan.');
        }
        $this->render('pages/edit', [
            'page' => $page,
            'blocks' => Page::blocksOf($page),
            'seo' => Page::seoOf($page),
            'blockDefs' => BlockSchema::all(),
            'mediaList' => \App\Models\Media::search('', 60),
            'quality' => QualityGate::check('page', $page),
        ]);
    }

    public function update(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        $page = Page::find((int) $id);
        if (!$page) {
            $this->fail('/admin/halaman', 'Halaman tidak ditemukan.');
        }
        $data = $this->collectPageData((int) $id);
        $data['id'] = (int) $id;

        // GERBANG KUALITAS: publish dilarang bila gate gagal (kecuali dipaksa draft).
        if ($data['status'] === 'published') {
            $gate = QualityGate::check('page', $data);
            if (!$gate['pass']) {
                Session::flash('error', 'Tidak dapat menerbitkan. Perbaiki: ' . implode(' ', $gate['issues']));
                $data['status'] = 'review';
                Page::saveWithRevision($data, Auth::id(), 'Tertahan quality gate');
                $this->fail('/admin/halaman/' . $id . '/edit', 'Status diubah ke "perlu review".');
            }
        }
        Page::saveWithRevision($data, Auth::id());
        $this->ok('/admin/halaman/' . $id . '/edit', 'Perubahan tersimpan. Status: ' . $data['status'] . '.');
    }

    public function autosave(string $id): void
    {
        // Autosave editor visual via fetch: simpan snapshot sebagai REVISI saja.
        $this->require('content.*');
        if (!\App\Core\Csrf::verify()) {
            http_response_code(419);
            echo json_encode(['ok' => false]);
            return;
        }
        $page = Page::find((int) $id);
        if (!$page) {
            http_response_code(404);
            echo json_encode(['ok' => false]);
            return;
        }
        $blocks = json_decode((string) ($_POST['blocks'] ?? '[]'), true);
        if (!is_array($blocks)) {
            http_response_code(400);
            echo json_encode(['ok' => false]);
            return;
        }
        $clean = BlockSchema::sanitizeBlocks($blocks);
        $snapshot = $page;
        $snapshot['blocks'] = json_encode($clean, JSON_UNESCAPED_UNICODE);
        Revision::snapshot('page', (int) $id, $snapshot, Auth::id(), 'Autosave editor visual');
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['ok' => true, 'saved_at' => date('H:i:s')]);
    }

    public function preview(string $id): void
    {
        // Pratinjau draft: hanya untuk yang login. Tidak diindeks (X-Robots-Tag + noindex).
        $this->require('content.view');
        $page = Page::find((int) $id);
        if (!$page) {
            $this->fail('/admin/halaman', 'Halaman tidak ditemukan.');
        }
        header('X-Robots-Tag: noindex, nofollow');
        $blocks = Page::blocksOf($page);
        \App\Core\View::render('page', [
            'page' => $page,
            'blocks' => $blocks,
            'previewMode' => true,
            'faqs' => [],
            'seo' => array_merge(Page::seoOf($page), ['robots' => 'noindex, nofollow']),
        ]);
    }

    public function revisions(string $id): void
    {
        $this->require('content.view');
        $page = Page::find((int) $id);
        if (!$page) {
            $this->fail('/admin/halaman', 'Halaman tidak ditemukan.');
        }
        $this->render('pages/revisions', [
            'page' => $page,
            'revisions' => Revision::forEntity('page', (int) $id),
        ]);
    }

    public function restoreRevision(string $id, string $rid): void
    {
        $this->require('content.*');
        $this->csrf();
        $ok = Revision::restore((int) $rid, Auth::id());
        $ok
            ? $this->ok('/admin/halaman/' . $id . '/edit', 'Revisi dipulihkan.')
            : $this->fail('/admin/halaman/' . $id . '/revisi', 'Revisi tidak dapat dipulihkan.');
    }

    public function destroy(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        Page::deleteById((int) $id);
        \App\Core\Cache::flush();
        $this->ok('/admin/halaman', 'Halaman dihapus. (Tutup akses di mesin pencari dengan redirect 410 di menu SEO bila diperlukan.)');
    }

    /** Kumpulkan & sanitasi input form halaman. $currentId = ID halaman yang diedit (0 bila baru). */
    private function collectPageData(int $currentId = 0): array
    {
        $title = $this->input('title', 150);
        $slugInput = $this->input('slug', 150);
        $slug = $slugInput !== '' ? Str::slug($slugInput) : Str::slug($title);

        // Unikkan slug (slug milik halaman ini sendiri tidak dihitung bentrok).
        $base = $slug;
        $n = 1;
        while (true) {
            $existing = Page::findBySlug($slug);
            if ($existing === null || (int) $existing['id'] === $currentId) {
                break;
            }
            $slug = $base . '-' . (++$n);
        }

        $blocksRaw = json_decode((string) ($_POST['blocks'] ?? '[]'), true);
        $blocks = BlockSchema::sanitizeBlocks(is_array($blocksRaw) ? $blocksRaw : []);

        $seo = [
            'title'       => $this->input('seo_title', 120) ?: $title,
            'description' => $this->input('seo_description', 320),
            'robots'      => $this->input('seo_robots', 60) ?: 'index, follow',
            'sources'     => $this->input('seo_sources', 500),
        ];

        $status = $this->input('status', 20);
        if (!in_array($status, Page::STATUSES, true)) {
            $status = 'draft';
        }

        return [
            'title'       => $title,
            'slug'        => $slug,
            'excerpt'     => $this->input('excerpt', 300),
            'blocks'      => json_encode($blocks, JSON_UNESCAPED_UNICODE),
            'seo'         => json_encode($seo, JSON_UNESCAPED_UNICODE),
            'status'      => $status,
            'published_at'=> $status === 'published' ? date('Y-m-d H:i:s') : null,
            'updated_by'  => Auth::id(),
        ];
    }
}
