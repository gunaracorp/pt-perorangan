<?php
/**
 * FILE   : app/Controllers/Admin/ThemeController.php
 * FUNGSI : Theme customizer — ubah warna, font, radius, lebar, gaya header/footer
 *          melalui kontrol tervalidasi; nilai disimpan di settings lalu jadi CSS variables.
 * AMAN?  : PRIVAT. content.*. Nilai disanitasi oleh Theme::cssVariables() saat keluaran
 *          (tidak mungkin menyuntik CSS/JS berbahaya).
 * TERKAIT: app/Core/Theme.php, admin/views/theme/index.php
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Theme;
use App\Models\Setting;

final class ThemeController extends BaseController
{
    /** Daftar kontrol customizer (label Indonesia + tipe + opsi). */
    public static function controls(): array
    {
        return [
            ['key' => 'color_primary', 'label' => 'Warna utama', 'type' => 'color', 'default' => '#5b3df5', 'desc' => 'Digunakan untuk tombol, tautan aktif, aksen gradient.'],
            ['key' => 'color_accent', 'label' => 'Warna aksen', 'type' => 'color', 'default' => '#22d3ee', 'desc' => 'Glow, garis neon, hover.'],
            ['key' => 'color_bg', 'label' => 'Warna latar', 'type' => 'color', 'default' => '#0b0f1e', 'desc' => 'Latar utama halaman.'],
            ['key' => 'color_surface', 'label' => 'Warna kartu/panel', 'type' => 'color', 'default' => '#121831', 'desc' => 'Latar kartu dan section sekunder.'],
            ['key' => 'color_text', 'label' => 'Warna teks utama', 'type' => 'color', 'default' => '#e8ecff'],
            ['key' => 'color_muted', 'label' => 'Warna teks sekunder', 'type' => 'color', 'default' => '#9aa3c7'],
            ['key' => 'font_heading', 'label' => 'Font judul', 'type' => 'select', 'default' => "'Space Grotesk', system-ui, sans-serif", 'options' => [
                "'Space Grotesk', system-ui, sans-serif" => 'Space Grotesk (futuristik)',
                "'Inter', system-ui, sans-serif" => 'Inter (netral modern)',
                "system-ui, sans-serif" => 'System UI (paling cepat)',
                "Georgia, serif" => 'Georgia (serif klasik)',
            ]],
            ['key' => 'font_body', 'label' => 'Font isi', 'type' => 'select', 'default' => "'Inter', system-ui, sans-serif", 'options' => [
                "'Inter', system-ui, sans-serif" => 'Inter (netral modern)',
                "'Space Grotesk', system-ui, sans-serif" => 'Space Grotesk',
                "system-ui, sans-serif" => 'System UI (paling cepat)',
                "Georgia, serif" => 'Georgia (serif klasik)',
            ]],
            ['key' => 'ui_radius', 'label' => 'Sudut melengkung (radius)', 'type' => 'select', 'default' => '16px', 'options' => [
                '8px' => 'Kecil (8px)', '16px' => 'Sedang (16px)', '24px' => 'Besar (24px)', '4px' => 'Tajam (4px)',
            ]],
            ['key' => 'layout_width', 'label' => 'Lebar konten maksimum', 'type' => 'select', 'default' => '1200px', 'options' => [
                '1080px' => 'Sempit (1080px)', '1200px' => 'Normal (1200px)', '1360px' => 'Lebar (1360px)',
            ]],
            ['key' => 'header_style', 'label' => 'Gaya header', 'type' => 'select', 'default' => 'glass', 'options' => [
                'glass' => 'Glass (kaca blur)', 'solid' => 'Solid', 'outline' => 'Garis tipis',
            ]],
            ['key' => 'footer_style', 'label' => 'Gaya footer', 'type' => 'select', 'default' => 'grid', 'options' => [
                'grid' => 'Grid multi kolom', 'simple' => 'Sederhana satu baris',
            ]],
            ['key' => 'motion_speed', 'label' => 'Kecepatan animasi', 'type' => 'select', 'default' => '0.6s', 'options' => [
                '0.4s' => 'Cepat (0.4s)', '0.6s' => 'Sedang (0.6s)', '0.9s' => 'Lembut (0.9s)',
            ]],
        ];
    }

    public function index(): void
    {
        $this->require('content.view');
        $this->render('theme/index', [
            'controls' => self::controls(),
            'current' => Setting::allGrouped('theme'),
        ]);
    }

    public function save(): void
    {
        $this->require('content.*');
        $this->csrf();
        $values = [];
        foreach (self::controls() as $c) {
            $key = $c['key'];
            if ($c['type'] === 'color') {
                $v = trim((string) ($_POST[$key] ?? ''));
                $values[$key] = preg_match('~^#[0-9a-fA-F]{3,8}$~', $v) ? $v : (string) $c['default'];
            } elseif ($c['type'] === 'select') {
                $v = trim((string) ($_POST[$key] ?? ''));
                $values[$key] = array_key_exists($v, $c['options'] ?? []) ? $v : (string) $c['default'];
            } else {
                $values[$key] = \App\Core\Str::clean((string) ($_POST[$key] ?? '')) ?: (string) $c['default'];
            }
        }
        Setting::putMany('theme', $values);
        $this->ok('/admin/tema', 'Tampilan tema tersimpan. Cache otomatis dibersihkan.');
    }
}
