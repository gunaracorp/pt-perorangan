<?php
/**
 * FILE   : app/Controllers/Admin/SettingsController.php
 * FUNGSI : Pengaturan situs: identitas, kontak, WhatsApp CTA, catatan footer, kebijakan.
 * AMAN?  : PRIVAT. content.* untuk sebagian besar; analytics hanya owner/admin.
 * TERKAIT: app/Core/Theme.php (siteData)
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Models\Setting;

final class SettingsController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('settings/index', [
            'site' => Setting::allGrouped('site'),
            'analytics' => Setting::allGrouped('analytics'),
        ]);
    }

    public function save(): void
    {
        $this->require('content.*');
        $this->csrf();
        $siteKeys = ['site_name', 'site_tagline', 'site_logo', 'contact_phone', 'contact_whatsapp',
            'contact_email', 'contact_address', 'contact_maps', 'cta_wa_message', 'footer_note'];
        $values = [];
        foreach ($siteKeys as $key) {
            $v = $this->input($key, 500);
            if ($key === 'site_logo' && $v !== '' && !preg_match('~^/media/[A-Za-z0-9._-]+$~', $v)) {
                $v = ''; // hanya path media yang sah
            }
            $values[$key] = $v;
        }
        Setting::putMany('site', $values);

        // Analytics/verifikasi: owner & admin saja (akses "users.view" sebagai proxy peran tinggi).
        if (Auth::can('users.view')) {
            $gsc = $this->input('gsc_verification', 500);
            $gtag = $this->input('gtag_id', 60);
            Setting::putMany('analytics', [
                'gsc_verification' => preg_match('~^[A-Za-z0-9_=\-+]+$~', $gsc) ? $gsc : '',
                'gtag_id' => preg_match('~^(G|UA|AW)-[A-Za-z0-9\-]+$~', $gtag) ? $gtag : '',
            ]);
        }
        $this->ok('/admin/pengaturan', 'Pengaturan tersimpan.');
    }
}
