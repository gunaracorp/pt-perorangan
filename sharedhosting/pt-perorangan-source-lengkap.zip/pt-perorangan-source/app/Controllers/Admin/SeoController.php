<?php
/**
 * FILE   : app/Controllers/Admin/SeoController.php
 * FUNGSI : Panel SEO: kelola redirect 301/302/410 + bersihkan cache sitemap.
 * AMAN?  : PRIVAT. content.* untuk redirect.
 * TERKAIT: app/Models/Redirect.php, app/Services/SitemapService.php
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\Redirect;

final class SeoController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('seo/index', [
            'redirects' => \App\Core\Database::all('SELECT * FROM redirects ORDER BY id DESC LIMIT 200'),
            'base' => rtrim((string) app_config('base_url', ''), '/'),
        ]);
    }

    public function addRedirect(): void
    {
        $this->require('content.*');
        $this->csrf();
        $status = (int) ($_POST['status'] ?? 301);
        if (!in_array($status, [301, 302, 410], true)) {
            $status = 301;
        }
        [$ok, $msg] = Redirect::upsert($this->input('from_path', 300), $this->input('target', 300), $status);
        $ok ? $this->ok('/admin/seo', $msg) : $this->fail('/admin/seo', $msg);
    }

    public function deleteRedirect(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        Redirect::deleteById((int) $id);
        \App\Core\Cache::forget('redirect_map');
        $this->ok('/admin/seo', 'Redirect dihapus.');
    }

    public function flushSitemap(): void
    {
        $this->require('content.*');
        $this->csrf();
        \App\Core\Cache::flush();
        $this->ok('/admin/seo', 'Cache sitemap & halaman dibersihkan.');
    }
}
