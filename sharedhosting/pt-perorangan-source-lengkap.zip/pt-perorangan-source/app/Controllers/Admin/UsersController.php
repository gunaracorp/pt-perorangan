<?php
/**
 * FILE   : app/Controllers/Admin/UsersController.php
 * FUNGSI : Manajemen pengguna admin (owner/admin/editor/reviewer).
 * AMAN?  : PRIVAT. Hanya owner/admin ('users.*'). Password minimal 10 karakter.
 *          Tidak boleh menghapus akun sendiri.
 * TERKAIT: app/Models/User.php, app/Core/Auth.php (matrix peran)
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\User;

final class UsersController extends BaseController
{
    public function index(): void
    {
        $this->require('users.view');
        $this->render('users/index', ['users' => User::all('id ASC')]);
    }

    public function store(): void
    {
        $this->require('users.*');
        $this->csrf();
        $name = $this->input('name', 100);
        $email = mb_strtolower($this->input('email', 150));
        $password = (string) ($_POST['password'] ?? '');
        $role = $this->input('role', 20);

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($password) < 10) {
            $this->fail('/admin/pengguna', 'Periksa kembali: nama wajib, email valid, password minimal 10 karakter.');
        }
        if (User::findByEmail($email) !== null) {
            $this->fail('/admin/pengguna', 'Email sudah terdaftar.');
        }
        if (!in_array($role, ['owner', 'admin', 'editor', 'reviewer'], true)) {
            $role = 'editor';
        }
        User::create($name, $email, $password, $role);
        $this->ok('/admin/pengguna', 'Pengguna dibuat dengan peran: ' . $role . '.');
    }

    public function destroy(string $id): void
    {
        $this->require('users.*');
        $this->csrf();
        if ((int) $id === Auth::id()) {
            $this->fail('/admin/pengguna', 'Tidak dapat menghapus akun sendiri.');
        }
        User::deleteById((int) $id);
        $this->ok('/admin/pengguna', 'Pengguna dihapus.');
    }
}
