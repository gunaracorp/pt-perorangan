<?php
/**
 * FILE   : app/Controllers/Admin/MenusController.php
 * FUNGSI : Editor menu navigasi (header & footer) — item disimpan sebagai JSON.
 * AMAN?  : PRIVAT. content.* — URL disanitasi (whitelist format path/URL aman).
 * TERKAIT: app/Models/Menu.php
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\Menu;

final class MenusController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('menus/index', [
            'header' => Menu::items('header'),
            'footer' => Menu::items('footer'),
        ]);
    }

    public function save(): void
    {
        $this->require('content.*');
        $this->csrf();
        foreach (['header', 'footer'] as $location) {
            $items = [];
            $labels = $_POST[$location . '_label'] ?? [];
            $urls   = $_POST[$location . '_url'] ?? [];
            if (is_array($labels) && is_array($urls)) {
                $count = min(count($labels), count($urls), 30);
                for ($i = 0; $i < $count; $i++) {
                    $label = \App\Core\Str::clean((string) $labels[$i]);
                    $url = trim((string) $urls[$i]);
                    if ($label === '' || $url === '') {
                        continue;
                    }
                    // URL aman: path internal ATAU URL absolut http(s).
                    if (str_starts_with($url, '/')) {
                        $url = str_replace(['"', "'", '<', '>'], '', $url);
                    } elseif (filter_var($url, FILTER_VALIDATE_URL) === false || !preg_match('~^https?://~i', $url)) {
                        continue;
                    }
                    $items[] = ['label' => mb_substr($label, 0, 60), 'url' => $url];
                }
            }
            Menu::saveItems($location, $items);
        }
        $this->ok('/admin/menu', 'Menu tersimpan.');
    }
}
