<?php
/**
 * FILE   : app/Controllers/Admin/ImportController.php
 * FUNGSI : Impor massal layanan dari CSV/JSON dengan laporan validasi per baris.
 * AMAN?  : PRIVAT. content.*. Semua hasil impor masuk sebagai DRAFT (tidak langsung publish).
 * TERKAIT: app/Services/ImportService.php
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\ImportService;

final class ImportController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('import/index', ['report' => null]);
    }

    public function run(): void
    {
        $this->require('content.*');
        $this->csrf();

        $mode = $this->input('mode', 10);
        $raw = (string) ($_POST['content'] ?? '');

        // Jika ada file CSV/JSON diunggah, baca isinya.
        if (!empty($_FILES['file']['tmp_name']) && is_uploaded_file((string) $_FILES['file']['tmp_name'])) {
            $ext = strtolower(pathinfo((string) ($_FILES['file']['name'] ?? ''), PATHINFO_EXTENSION));
            if (in_array($ext, ['csv', 'json'], true) && (int) $_FILES['file']['size'] < 2 * 1024 * 1024) {
                $raw = (string) file_get_contents((string) $_FILES['file']['tmp_name']);
                $mode = $ext;
            }
        }

        $raw = trim($raw);
        if ($raw === '') {
            $this->fail('/admin/impor', 'Data impor kosong. Tempel isi CSV/JSON atau unggah file.');
        }
        $result = ImportService::importServices($raw, $mode !== 'json');
        $this->render('import/index', ['report' => $result]);
    }
}
