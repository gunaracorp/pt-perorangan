<?php
/**
 * FILE   : app/Controllers/Admin/FaqController.php
 * FUNGSI : CRUD FAQ (bank pertanyaan untuk halaman FAQ + blok FAQ layanan).
 * AMAN?  : PRIVAT. content.*
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\Faq;

final class FaqController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('faq/index', [
            'faqs' => Faq::all('sort_order ASC, id DESC', 200),
            'services' => \App\Models\Service::all('title ASC'),
        ]);
    }

    public function store(): void
    {
        $this->require('content.*');
        $this->csrf();
        $question = $this->input('question', 300);
        $answer = $this->input('answer', 3000);
        if ($question === '' || $answer === '') {
            $this->fail('/admin/faq', 'Pertanyaan dan jawaban wajib diisi.');
        }
        $serviceId = $this->int('service_id') ?: null;
        Faq::insert([
            'question'    => $question,
            'answer'      => $answer,
            'service_id'  => $serviceId,
            'status'      => $this->input('status', 20) === 'published' ? 'published' : 'draft',
            'sort_order'  => (int) ($_POST['sort_order'] ?? 10),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        \App\Core\Cache::flush();
        $this->ok('/admin/faq', 'FAQ tersimpan.');
    }

    public function destroy(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        Faq::deleteById((int) $id);
        \App\Core\Cache::flush();
        $this->ok('/admin/faq', 'FAQ dihapus.');
    }
}
