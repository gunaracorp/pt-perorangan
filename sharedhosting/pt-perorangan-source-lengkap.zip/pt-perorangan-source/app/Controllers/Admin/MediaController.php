<?php
/**
 * FILE   : app/Controllers/Admin/MediaController.php
 * FUNGSI : Media library: unggah aman, edit metadata (alt/kredit), hapus, cari.
 * AMAN?  : PRIVAT. KEAMANAN UPLOAD WAJIB:
 *          - ekstensi & MIME di-whitelist
 *          - ukuran dibatasi (config uploads.max_size_mb)
 *          - nama file dibuat acak (menghindari overwrite & eksekusi)
 *          - lokasi public/media DILINDUNGI .htaccess (tanpa eksekusi PHP)
 *          - SVG disanitasi ringan (buang script/event handler)
 * TERKAIT: app/Models/Media.php, public/media/.htaccess, config uploads.allowed
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Models\Media;

final class MediaController extends BaseController
{
    public function index(): void
    {
        $this->require('media.*');
        $q = trim((string) ($_GET['q'] ?? ''));
        $this->render('media/index', [
            'mediaList' => Media::search(\App\Core\Str::clean($q), 120),
            'q' => $q,
        ]);
    }

    public function upload(): void
    {
        $this->require('media.*');
        $this->csrf();

        if (empty($_FILES['file']) || !is_array($_FILES['file']) || ($_FILES['file']['error'] ?? 1) !== UPLOAD_ERR_OK) {
            $this->fail('/admin/media', 'Gagal mengunggah. Periksa ukuran file (maks ' . (int) app_config('uploads.max_size_mb', 8) . ' MB).');
        }

        $tmp  = (string) $_FILES['file']['tmp_name'];
        $name = (string) $_FILES['file']['name'];
        $size = (int) $_FILES['file']['size'];

        $maxBytes = (int) app_config('uploads.max_size_mb', 8) * 1024 * 1024;
        if ($size <= 0 || $size > $maxBytes) {
            $this->fail('/admin/media', 'Ukuran file melebihi batas.');
        }

        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $allowed = (array) app_config('uploads.allowed', ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'pdf']);
        if (!in_array($ext, $allowed, true)) {
            $this->fail('/admin/media', 'Format . ' . $ext . ' tidak diizinkan.');
        }

        // Verifikasi MIME nyata dari isi file (bukan sekadar nama).
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = (string) $finfo->file($tmp);
        $mimeMap = [
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
            'webp' => 'image/webp', 'gif' => 'image/gif', 'svg' => 'image/svg+xml',
            'pdf' => 'application/pdf',
        ];
        $expected = $mimeMap[$ext] ?? '';
        if ($expected === '' || $mime !== $expected) {
            $this->fail('/admin/media', 'Tipe file tidak cocok dengan ekstensi (ditemukan: ' . $mime . ').');
        }

        $newName = date('Ymd') . '-' . \App\Core\Str::random(8) . '.' . $ext;
        $destDir = PUBLIC_DIR . '/media';
        if (!is_dir($destDir)) {
            @mkdir($destDir, 0755, true);
        }
        $dest = $destDir . '/' . $newName;

        // Sanitasi SVG sebelum disimpan (buang script).
        if ($ext === 'svg') {
            $content = (string) file_get_contents($tmp);
            $content = preg_replace('~<script\b[^>]*>.*?</script>~is', '', $content) ?? '';
            $content = preg_replace('~\son\w+\s*=\s*("[^"]*"|\'[^\']*\')~i', '', $content) ?? '';
            file_put_contents($dest, $content);
        } else {
            if (!move_uploaded_file($tmp, $dest)) {
                $this->fail('/admin/media', 'Gagal menyimpan file ke folder media.');
            }
            @chmod($dest, 0644);
        }

        // Dimensi gambar (bila tersedia).
        $w = null;
        $h = null;
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) {
            $info = @getimagesize($dest);
            if (is_array($info)) {
                $w = (int) $info[0];
                $h = (int) $info[1];
            }
        }

        $id = Media::insert([
            'filename'      => $newName,
            'original_name' => \App\Core\Str::clean($name),
            'mime'          => $mime,
            'size'          => $size,
            'width'         => $w,
            'height'        => $h,
            'alt'           => $this->input('alt', 200),
            'credit'        => $this->input('credit', 200),
            'created_by'    => Auth::id(),
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
        $this->ok('/admin/media', 'Media terunggah: ' . $newName);
    }

    public function update(string $id): void
    {
        $this->require('media.*');
        $this->csrf();
        $m = Media::find((int) $id);
        if (!$m) {
            $this->fail('/admin/media', 'Media tidak ditemukan.');
        }
        Media::updateById((int) $id, [
            'alt'    => $this->input('alt', 200),
            'credit' => $this->input('credit', 200),
        ]);
        $this->ok('/admin/media', 'Metadata media diperbarui.');
    }

    public function destroy(string $id): void
    {
        $this->require('media.*');
        $this->csrf();
        $m = Media::find((int) $id);
        if ($m) {
            $file = PUBLIC_DIR . '/media/' . basename((string) $m['filename']);
            if (is_file($file)) {
                @unlink($file);
            }
            Media::deleteById((int) $id);
        }
        $this->ok('/admin/media', 'Media dihapus.');
    }
}
