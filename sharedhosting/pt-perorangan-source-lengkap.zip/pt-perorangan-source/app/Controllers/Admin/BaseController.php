<?php
/**
 * FILE   : app/Controllers/Admin/BaseController.php
 * FUNGSI : Kelas dasar seluruh controller admin: login guard, render layout admin,
 *          flash, helper input, dan CSRF guard otomatis pada POST.
 * UNTUK  : Dipewarisi semua Admin/*Controller.
 * KENAPA : Pemeriksaan keamanan tidak boleh tergantung disiplin tiap controller —
 *          ditulis SEKALI di sini.
 * TERKAIT: app/Core/Auth.php, app/Core/Session.php, tema admin layout
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Session;

abstract class BaseController
{
    /** Wajib login (opsional + izin aksi). Panggil di awal tiap method. */
    protected function require(string $action = ''): void
    {
        Auth::requireLogin($action);
    }

    /** Render tampilan admin (layout khusus admin, bukan tema publik). */
    protected function render(string $view, array $data = []): void
    {
        $data['auth'] = [
            'id'   => Auth::id(),
            'name' => Auth::name(),
            'role' => Auth::role(),
        ];
        $data['flashes'] = Session::takeFlashes();
        extract($data, EXTR_SKIP);
        $viewFile = APP_DIR . '/Views/admin/' . $view . '.php';
        if (!is_file($viewFile)) {
            throw new \RuntimeException('View admin tidak ditemukan: ' . $view);
        }
        ob_start();
        include $viewFile;
        $content = (string) ob_get_clean();
        include APP_DIR . '/Views/admin/layout.php';
    }

    /** Jika request POST, verifikasi CSRF (panggilan otomatis helper). */
    protected function csrf(): void
    {
        Csrf::guard();
    }

    /** Redirect dengan flash sukses. */
    protected function ok(string $url, string $message): never
    {
        Session::flash('success', $message);
        header('Location: ' . $url);
        exit;
    }

    /** Redirect dengan flash error. */
    protected function fail(string $url, string $message): never
    {
        Session::flash('error', $message);
        header('Location: ' . $url);
        exit;
    }

    /** Ambil & bersihkan input POST string. */
    protected function input(string $key, int $maxLen = 5000): string
    {
        return mb_substr(\App\Core\Str::clean((string) ($_POST[$key] ?? '')), 0, $maxLen);
    }

    protected function int(string $key): int
    {
        return (int) ($_POST[$key] ?? 0);
    }
}
