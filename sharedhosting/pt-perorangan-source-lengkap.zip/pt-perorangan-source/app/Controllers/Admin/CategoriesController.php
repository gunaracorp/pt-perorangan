<?php
/**
 * FILE   : app/Controllers/Admin/CategoriesController.php
 * FUNGSI : CRUD kategori layanan (hub /layanan/kategori/{slug}).
 * AMAN?  : PRIVAT. content.*
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Str;
use App\Models\Category;

final class CategoriesController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('categories/index', [
            'categories' => Category::all('sort_order ASC'),
        ]);
    }

    public function store(): void
    {
        $this->require('content.*');
        $this->csrf();
        $name = $this->input('name', 100);
        if ($name === '') {
            $this->fail('/admin/kategori', 'Nama kategori wajib diisi.');
        }
        $slug = $this->input('slug', 100) !== '' ? Str::slug($this->input('slug', 100)) : Str::slug($name);
        $n = 1;
        $base = $slug;
        while (Category::findBySlug($slug) !== null) {
            $slug = $base . '-' . (++$n);
        }
        Category::insert([
            'name' => $name,
            'slug' => $slug,
            'description' => $this->input('description', 300),
            'seo' => json_encode(['title' => $name, 'description' => $this->input('description', 300)], JSON_UNESCAPED_UNICODE),
            'status' => 'published',
            'sort_order' => (int) ($_POST['sort_order'] ?? 10),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        \App\Core\Cache::flush();
        $this->ok('/admin/kategori', 'Kategori tersimpan.');
    }

    public function destroy(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        Category::deleteById((int) $id);
        \App\Core\Cache::flush();
        $this->ok('/admin/kategori', 'Kategori dihapus.');
    }
}
