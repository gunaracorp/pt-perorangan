<?php
/**
 * FILE   : app/Controllers/Admin/AuthController.php
 * FUNGSI : Halaman login admin + proses login (rate limited) + logout.
 * AMAN?  : PRIVAT. Pesan error sengaja generik (tidak membocorkan apakah email ada).
 * TERKAIT: app/Core/Auth.php, app/Models/User.php
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Session;

final class AuthController extends BaseController
{
    public function showLogin(): void
    {
        if (Auth::check()) {
            header('Location: /admin');
            exit;
        }
        $this->render('login', ['expired' => isset($_GET['expired'])]);
    }

    public function login(): void
    {
        Csrf::guard();
        $email = $this->input('email', 150);
        $password = (string) ($_POST['password'] ?? '');

        if (Auth::tooManyAttempts($email)) {
            $this->fail('/admin/login', 'Terlalu banyak percobaan login. Tunggu 15 menit lalu coba lagi.');
        }

        if (Auth::attempt($email, $password)) {
            header('Location: /admin');
            exit;
        }
        // Pesan generik: tidak menunjukkan apakah email terdaftar.
        $this->fail('/admin/login', 'Email atau kata sandi salah.');
    }

    public function logout(): void
    {
        Auth::logout();
        header('Location: /admin/login');
        exit;
    }
}
