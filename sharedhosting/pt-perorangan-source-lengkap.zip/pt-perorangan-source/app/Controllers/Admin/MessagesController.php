<?php
/**
 * FILE   : app/Controllers/Admin/MessagesController.php
 * FUNGSI : Kotak masuk pesan formulir kontak (baca, tandai, hapus).
 * AMAN?  : PRIVAT. content.view untuk melihat; content.* untuk mengubah.
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\ContactMessage;

final class MessagesController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('messages/index', ['messages' => ContactMessage::all('id DESC', 200)]);
    }

    public function setStatus(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        $status = $this->input('status', 20);
        if (!in_array($status, ['new', 'read', 'replied'], true)) {
            $status = 'read';
        }
        ContactMessage::updateById((int) $id, ['status' => $status]);
        $this->ok('/admin/pesan', 'Status pesan diperbarui.');
    }

    public function destroy(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        ContactMessage::deleteById((int) $id);
        $this->ok('/admin/pesan', 'Pesan dihapus.');
    }
}
