<?php
/**
 * FILE   : app/Controllers/Admin/ArticlesController.php
 * FUNGSI : CRUD artikel (panduan edukasi) dengan editor visual + quality gate.
 * AMAN?  : PRIVAT. Editor menulis; reviewer meninjau (lihat status di UI).
 * TERKAIT: app/Models/Article.php
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Session;
use App\Core\Str;
use App\Models\Article;
use App\Services\BlockSchema;
use App\Services\QualityGate;

final class ArticlesController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $articles = \App\Core\Database::all(
            'SELECT a.*, u.name AS author_name FROM articles a LEFT JOIN users u ON u.id = a.author_id
             ORDER BY a.updated_at DESC LIMIT 200'
        );
        $this->render('articles/index', ['articles' => $articles]);
    }

    public function create(): void
    {
        $this->require('content.*');
        $this->render('articles/edit', [
            'article' => null, 'blocks' => [], 'seo' => [],
            'blockDefs' => BlockSchema::all(),
            'mediaList' => \App\Models\Media::search('', 60),
        ]);
    }

    public function store(): void
    {
        $this->require('content.*');
        $this->csrf();
        $data = $this->collectArticleData();
        $id = Article::saveWithRevision($data, Auth::id(), 'Dibuat');
        $this->ok('/admin/artikel/' . $id . '/edit', 'Artikel dibuat. Status: ' . $data['status'] . '.');
    }

    public function edit(string $id): void
    {
        $this->require('content.view');
        $article = Article::find((int) $id);
        if (!$article) {
            $this->fail('/admin/artikel', 'Artikel tidak ditemukan.');
        }
        $this->render('articles/edit', [
            'article' => $article,
            'blocks' => Article::blocksOf($article),
            'seo' => Article::seoOf($article),
            'blockDefs' => BlockSchema::all(),
            'mediaList' => \App\Models\Media::search('', 60),
            'quality' => QualityGate::check('article', $article),
        ]);
    }

    public function update(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        $article = Article::find((int) $id);
        if (!$article) {
            $this->fail('/admin/artikel', 'Artikel tidak ditemukan.');
        }
        $data = $this->collectArticleData((int) $id);
        $data['id'] = (int) $id;
        if ($data['status'] === 'published') {
            $gate = QualityGate::check('article', $data);
            if (!$gate['pass']) {
                Session::flash('error', 'Tidak dapat menerbitkan. Perbaiki: ' . implode(' ', $gate['issues']));
                $data['status'] = 'review';
                Article::saveWithRevision($data, Auth::id(), 'Tertahan quality gate');
                $this->fail('/admin/artikel/' . $id . '/edit', 'Status diubah ke "perlu review".');
            }
        }
        Article::saveWithRevision($data, Auth::id());
        $this->ok('/admin/artikel/' . $id . '/edit', 'Perubahan tersimpan. Status: ' . $data['status'] . '.');
    }

    public function preview(string $id): void
    {
        $this->require('content.view');
        $article = Article::find((int) $id);
        if (!$article) {
            $this->fail('/admin/artikel', 'Artikel tidak ditemukan.');
        }
        header('X-Robots-Tag: noindex, nofollow');
        \App\Core\View::render('article', [
            'article' => $article,
            'blocks' => Article::blocksOf($article),
            'related' => Article::published(4),
            'previewMode' => true,
            'seo' => array_merge(Article::seoOf($article), ['robots' => 'noindex, nofollow']),
        ]);
    }

    public function destroy(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        Article::deleteById((int) $id);
        \App\Core\Cache::flush();
        $this->ok('/admin/artikel', 'Artikel dihapus.');
    }

    private function collectArticleData(int $currentId = 0): array
    {
        $title = $this->input('title', 150);
        $slugInput = $this->input('slug', 150);
        $slug = $slugInput !== '' ? Str::slug($slugInput) : Str::slug($title);
        $base = $slug;
        $n = 1;
        while (true) {
            $existing = Article::findBySlug($slug);
            if ($existing === null || (int) $existing['id'] === $currentId) {
                break;
            }
            $slug = $base . '-' . (++$n);
        }
        $blocksRaw = json_decode((string) ($_POST['blocks'] ?? '[]'), true);
        $blocks = BlockSchema::sanitizeBlocks(is_array($blocksRaw) ? $blocksRaw : []);
        $seo = [
            'title'       => $this->input('seo_title', 120) ?: $title,
            'description' => $this->input('seo_description', 320),
            'robots'      => $this->input('seo_robots', 60) ?: 'index, follow',
            'sources'     => $this->input('seo_sources', 500),
        ];
        $status = $this->input('status', 20);
        if (!in_array($status, ['draft', 'review', 'published', 'scheduled', 'needs_update'], true)) {
            $status = 'draft';
        }
        return [
            'title'        => $title,
            'slug'         => $slug,
            'excerpt'      => $this->input('excerpt', 300),
            'blocks'       => json_encode($blocks, JSON_UNESCAPED_UNICODE),
            'seo'          => json_encode($seo, JSON_UNESCAPED_UNICODE),
            'author_id'    => Auth::id(),
            'reviewed_by'  => $status === 'published' ? Auth::id() : null,
            'status'       => $status,
            'published_at' => $status === 'published' ? date('Y-m-d H:i:s') : null,
        ];
    }
}
