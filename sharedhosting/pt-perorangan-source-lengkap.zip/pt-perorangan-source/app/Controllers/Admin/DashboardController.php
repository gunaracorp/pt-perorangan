<?php
/**
 * FILE   : app/Controllers/Admin/DashboardController.php
 * FUNGSI : Dasbor admin: ringkasan konten, pesan baru, status quality gate.
 * AMAN?  : PRIVAT (login wajib).
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Database;
use App\Models\Article;
use App\Models\ContactMessage;
use App\Models\Page;
use App\Models\Service;

final class DashboardController extends BaseController
{
    public function index(): void
    {
        $this->require();
        $stats = [
            'pages'    => Page::count(),
            'published_pages' => Page::count("status = 'published'"),
            'services' => Service::count(),
            'published_services' => Service::count("status = 'published'"),
            'articles' => Article::count(),
            'drafts'   => Page::count("status IN ('draft','review')") + Service::count("status IN ('draft','review')") + Article::count("status IN ('draft','review')"),
            'messages' => ContactMessage::count("status = 'new'"),
        ];

        $recent = Database::all(
            "SELECT 'Layanan' AS jenis, title, status, updated_at, id FROM services
             UNION ALL SELECT 'Halaman', title, status, updated_at, id FROM pages
             UNION ALL SELECT 'Artikel', title, status, updated_at, id FROM articles
             ORDER BY updated_at DESC LIMIT 8"
        );

        $this->render('dashboard', ['stats' => $stats, 'recent' => $recent]);
    }
}
