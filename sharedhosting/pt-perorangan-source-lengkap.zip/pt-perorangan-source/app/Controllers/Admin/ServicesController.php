<?php
/**
 * FILE   : app/Controllers/Admin/ServicesController.php
 * FUNGSI : CRUD layanan dengan editor visual + fakta terstruktur + quality gate.
 * UNTUK  : Halaman /layanan/{slug} — mesin utama SEO intent.
 * AMAN?  : PRIVAT. content.* untuk editor, content.view untuk melihat.
 * TERKAIT: app/Models/Service.php, Service blocks, admin/views/services/*
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Auth;
use App\Core\Session;
use App\Core\Str;
use App\Models\Service;
use App\Services\BlockSchema;
use App\Services\QualityGate;

final class ServicesController extends BaseController
{
    public function index(): void
    {
        $this->require('content.view');
        $this->render('services/index', [
            'services' => Service::all('sort_order ASC, updated_at DESC', 300),
            'categories' => \App\Models\Category::all('sort_order ASC'),
        ]);
    }

    public function create(): void
    {
        $this->require('content.*');
        $this->render('services/edit', [
            'service' => null,
            'blocks' => [],
            'seo' => [],
            'facts' => ['official_fee' => '', 'service_fee' => '', 'est_time' => '', 'requirements' => []],
            'blockDefs' => BlockSchema::all(),
            'categories' => \App\Models\Category::all('sort_order ASC'),
            'mediaList' => \App\Models\Media::search('', 60),
        ]);
    }

    public function store(): void
    {
        $this->require('content.*');
        $this->csrf();
        $data = $this->collectServiceData();
        $id = Service::saveWithRevision($data, Auth::id(), 'Dibuat');
        $this->ok('/admin/layanan/' . $id . '/edit', 'Layanan dibuat. Status: ' . $data['status'] . '.');
    }

    public function edit(string $id): void
    {
        $this->require('content.view');
        $service = Service::find((int) $id);
        if (!$service) {
            $this->fail('/admin/layanan', 'Layanan tidak ditemukan.');
        }
        $this->render('services/edit', [
            'service' => $service,
            'blocks' => Service::blocksOf($service),
            'seo' => Service::seoOf($service),
            'facts' => Service::factsOf($service),
            'blockDefs' => BlockSchema::all(),
            'categories' => \App\Models\Category::all('sort_order ASC'),
            'mediaList' => \App\Models\Media::search('', 60),
            'quality' => QualityGate::check('service', $service),
        ]);
    }

    public function update(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        $service = Service::find((int) $id);
        if (!$service) {
            $this->fail('/admin/layanan', 'Layanan tidak ditemukan.');
        }
        $data = $this->collectServiceData((int) $id);
        $data['id'] = (int) $id;

        if ($data['status'] === 'published') {
            $gate = QualityGate::check('service', $data);
            if (!$gate['pass']) {
                Session::flash('error', 'Tidak dapat menerbitkan. Perbaiki: ' . implode(' ', $gate['issues']));
                $data['status'] = 'review';
                Service::saveWithRevision($data, Auth::id(), 'Tertahan quality gate');
                $this->fail('/admin/layanan/' . $id . '/edit', 'Status diubah ke "perlu review".');
            }
        }
        Service::saveWithRevision($data, Auth::id());
        $this->ok('/admin/layanan/' . $id . '/edit', 'Perubahan tersimpan. Status: ' . $data['status'] . '.');
    }

    public function preview(string $id): void
    {
        $this->require('content.view');
        $service = Service::find((int) $id);
        if (!$service) {
            $this->fail('/admin/layanan', 'Layanan tidak ditemukan.');
        }
        header('X-Robots-Tag: noindex, nofollow');
        \App\Core\View::render('service', [
            'service' => $service,
            'blocks' => Service::blocksOf($service),
            'facts' => Service::factsOf($service),
            'faqs' => \App\Models\Faq::published((int) $service['id'], 10),
            'related' => Service::published(6),
            'previewMode' => true,
            'seo' => array_merge(Service::seoOf($service), ['robots' => 'noindex, nofollow']),
        ]);
    }

    public function destroy(string $id): void
    {
        $this->require('content.*');
        $this->csrf();
        Service::deleteById((int) $id);
        \App\Core\Cache::flush();
        $this->ok('/admin/layanan', 'Layanan dihapus.');
    }

    private function collectServiceData(int $currentId = 0): array
    {
        $title = $this->input('title', 150);
        $slugInput = $this->input('slug', 150);
        $slug = $slugInput !== '' ? Str::slug($slugInput) : Str::slug($title);
        $base = $slug;
        $n = 1;
        while (true) {
            $existing = Service::findBySlug($slug);
            if ($existing === null || (int) $existing['id'] === $currentId) {
                break;
            }
            $slug = $base . '-' . (++$n);
        }

        $blocksRaw = json_decode((string) ($_POST['blocks'] ?? '[]'), true);
        $blocks = BlockSchema::sanitizeBlocks(is_array($blocksRaw) ? $blocksRaw : []);

        $seo = [
            'title'       => $this->input('seo_title', 120) ?: $title,
            'description' => $this->input('seo_description', 320),
            'robots'      => $this->input('seo_robots', 60) ?: 'index, follow',
            'sources'     => $this->input('seo_sources', 500),
        ];

        $requirements = array_values(array_filter(array_map('trim', explode("\n", (string) ($_POST['fact_requirements'] ?? '')))));

        $facts = [
            'official_fee' => $this->input('fact_official_fee', 200),
            'service_fee'  => $this->input('fact_service_fee', 200),
            'est_time'     => $this->input('fact_est_time', 100),
            'region'       => $this->input('fact_region', 100) ?: 'Indonesia',
            'requirements' => $requirements,
        ];

        $status = $this->input('status', 20);
        if (!in_array($status, ['draft', 'review', 'published', 'scheduled', 'needs_update'], true)) {
            $status = 'draft';
        }

        return [
            'title'        => $title,
            'slug'         => $slug,
            'excerpt'      => $this->input('excerpt', 300),
            'blocks'       => json_encode($blocks, JSON_UNESCAPED_UNICODE),
            'seo'          => json_encode($seo, JSON_UNESCAPED_UNICODE),
            'facts'        => json_encode($facts, JSON_UNESCAPED_UNICODE),
            'category_id'  => $this->int('category_id') ?: null,
            'featured'     => isset($_POST['featured']) ? 1 : 0,
            'status'       => $status,
            'published_at' => $status === 'published' ? date('Y-m-d H:i:s') : null,
            'updated_by'   => Auth::id(),
        ];
    }
}
