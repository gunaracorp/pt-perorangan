<?php
/**
 * FILE   : app/Controllers/ArticleController.php
 * FUNGSI : Daftar artikel (/artikel) dan detail (/artikel/{slug}).
 * TERKAIT: app/Models/Article.php, admin/ArticlesController
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;
use App\Models\Article;
use App\Services\SeoService;

final class ArticleController
{
    public function index(): void
    {
        $articles = Article::published(24);
        View::render('article_index', [
            'articles' => $articles,
            'seo' => [
                'title' => 'Artikel & Panduan Legalitas Usaha',
                'description' => 'Panduan praktis pendirian PT Perorangan, NIB, KBLI, kewajiban pajak, dan perizinan usaha lainnya.',
            ],
        ]);
    }

    public function show(string $slug): void
    {
        $article = Article::findPublished($slug);
        if (!$article) {
            View::renderErrorPage(404, 'Artikel tidak ditemukan.');
            return;
        }
        $author = '';
        if ((int) ($article['author_id'] ?? 0) > 0) {
            $u = \App\Models\User::find((int) $article['author_id']);
            $author = (string) ($u['name'] ?? '');
        }
        $jsonld = [
            SeoService::article($article, $author),
            SeoService::breadcrumb(['Beranda' => '/', 'Artikel' => '/artikel', $article['title'] => '/artikel/' . $slug]),
        ];
        View::render('article', [
            'article' => $article,
            'blocks' => Article::blocksOf($article),
            'related' => Article::published(4),
            'seo' => array_merge(Article::seoOf($article), ['jsonld' => $jsonld]),
        ]);
    }
}
