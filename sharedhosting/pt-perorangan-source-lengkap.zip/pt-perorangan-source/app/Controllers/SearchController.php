<?php
/**
 * FILE   : app/Controllers/SearchController.php
 * FUNGSI : Pencarian internal /cari?q=... (noindex — tidak dibuat sebagai halaman SEO).
 * KENAPA : Hasil pencarian internal TIDAK punya nilai mandiri; noindex mencegah
 *          banjir URL duplikat di indeks (selaras spam policies).
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;

final class SearchController
{
    public function index(): void
    {
        header('X-Robots-Tag: noindex, follow');
        $q = trim((string) ($_GET['q'] ?? ''));
        $q = mb_substr(\App\Core\Str::clean($q), 0, 80);
        $results = [];

        if ($q !== '') {
            $like = '%' . $q . '%';
            $results = \App\Core\Database::all(
                "SELECT 'service' AS kind, title, slug, excerpt FROM services
                 WHERE status = 'published' AND (title LIKE ? OR excerpt LIKE ?)
                 UNION ALL
                 SELECT 'article', title, slug, excerpt FROM articles
                 WHERE status = 'published' AND (title LIKE ? OR excerpt LIKE ?)
                 UNION ALL
                 SELECT 'page', title, slug, '' FROM pages
                 WHERE status = 'published' AND slug NOT IN ('beranda') AND title LIKE ?
                 LIMIT 30",
                [$like, $like, $like, $like, $like]
            );
        }

        View::render('search', [
            'q' => $q,
            'results' => $results,
            'seo' => [
                'title' => 'Hasil Pencarian' . ($q !== '' ? ': ' . $q : ''),
                'robots' => 'noindex, follow',
            ],
        ]);
    }
}
