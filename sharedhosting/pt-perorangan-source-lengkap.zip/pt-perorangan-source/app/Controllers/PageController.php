<?php
/**
 * FILE   : app/Controllers/PageController.php
 * FUNGSI : Menampilkan halaman builder publik /p/{slug} dengan status published.
 * UNTUK  : Halaman statis (tentang, kebijakan privasi, syarat layanan, panduan...).
 * KENAPA : Halaman tidak published TIDAK ditampilkan (404 asli) — draft tetap rahasia.
 * TERKAIT: app/Models/Page.php, admin/PagesController
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;
use App\Models\Page;
use App\Services\SeoService;
use App\Services\BlockSchema;

final class PageController
{
    public function show(string $slug): void
    {
        $page = Page::findPublished($slug);
        if (!$page) {
            \App\Core\View::renderErrorPage(404, 'Halaman tidak ditemukan.');
            return;
        }
        $blocks = Page::blocksOf($page);
        $seo = Page::seoOf($page);
        $jsonld = [SeoService::breadcrumb(['Beranda' => '/', $page['title'] => '/p/' . $slug])];

        View::render('page', [
            'page' => $page,
            'blocks' => $blocks,
            'faqs' => \App\Models\Faq::published(null, 8),
            'seo' => array_merge($seo, ['jsonld' => $jsonld]),
        ]);
    }
}
