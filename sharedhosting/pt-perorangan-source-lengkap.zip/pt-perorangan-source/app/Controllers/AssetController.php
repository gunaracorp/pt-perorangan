<?php
/**
 * FILE   : app/Controllers/AssetController.php
 * FUNGSI : Melayani aset tema (CSS/JS/gambar) dari folder themes/ dengan aman.
 * UNTUK  : Route /theme-assets/{path} — tema tetap self-contained di folder themes/.
 * KENAPA : PHP yang melayani file = kontrol penuh MIME + proteksi path traversal
 *          (sangat penting: jangan biarkan ../../config.php bocor).
 * TERKAIT: themes/pt-perorangan/assets/*, tema components/head.php
 * AMAN?  : PRIVAT (hanya file dari folder aset tema yang boleh keluar).
 * PEMULA : Path traversal = serangan menelusuri "../" untuk membaca file rahasia.
 */

declare(strict_types=1);

namespace App\Controllers;

final class AssetController
{
    public function serve(string $path): void
    {
        $theme = \App\Core\View::themeName();
        $base = realpath(THEMES_DIR . '/' . $theme . '/assets');
        if ($base === false) {
            http_response_code(404);
            return;
        }
        // Bersihkan path: tolak traversal, batasi karakter.
        if (str_contains($path, '..') || str_contains($path, '\\') || str_contains($path, "\0")) {
            http_response_code(403);
            return;
        }
        $file = realpath($base . '/' . ltrim($path, '/'));
        if ($file === false || !str_starts_with($file, $base . DIRECTORY_SEPARATOR) || !is_file($file)) {
            http_response_code(404);
            return;
        }
        // Cache browser 1 hari + MIME yang benar.
        $mime = match (strtolower(pathinfo($file, PATHINFO_EXTENSION))) {
            'css'   => 'text/css; charset=UTF-8',
            'js'    => 'application/javascript; charset=UTF-8',
            'svg'   => 'image/svg+xml',
            'png'   => 'image/png',
            'jpg', 'jpeg' => 'image/jpeg',
            'webp'  => 'image/webp',
            'gif'   => 'image/gif',
            'ico'   => 'image/x-icon',
            'woff2' => 'font/woff2',
            'json'  => 'application/json; charset=UTF-8',
            default => 'application/octet-stream',
        };
        header('Content-Type: ' . $mime);
        header('Cache-Control: public, max-age=86400');
        header('Content-Length: ' . (string) filesize($file));
        readfile($file);
    }
}
