<?php
/**
 * FILE   : app/Core/Session.php
 * FUNGSI : Memulai sesi dengan konfigurasi aman, flash message, dan regenerasi ID.
 * UNTUK  : Dipanggil pada App::run() sebelum routing; dipakai Auth, Csrf, Flash.
 * KENAPA : Cookie sesi yang aman (HttpOnly, SameSite, Secure) mencegah pembajakan sesi.
 * TERKAIT: app/Core/App.php, app/Core/Auth.php, app/Core/Csrf.php
 * AMAN?  : PRIVAT.
 * PEMULA : Sesi = cara server mengingat status login Anda antar halaman.
 * JANGAN : Menyimpan data sensitif mentah di $_SESSION selain yang diperlukan.
 */

declare(strict_types=1);

namespace App\Core;

final class Session
{
    private static bool $started = false;

    public static function start(): void
    {
        if (self::$started) {
            return;
        }
        $lifetime = (int) app_config('security.session_lifetime_minutes', 120) * 60;
        $secure = (($_SERVER['HTTPS'] ?? '') === 'on') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        session_set_cookie_params([
            'lifetime' => $lifetime,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,   // hanya HTTPS; di lokal http otomatis false
            'httponly' => true,      // JS tidak dapat membaca cookie sesi
            'samesite' => 'Lax',     // proteksi dasar CSRF lintas situs
        ]);
        session_name('ptper_session');
        session_start();
        self::$started = true;

        // Aktivitas terbaru → perbarui waktu hidup sesi admin.
        if (isset($_SESSION['auth_user_id'])) {
            $_SESSION['auth_last_activity'] = time();
        }
    }

    /** Regenerasi ID sesi (wajib setelah login agar sesi lama tidak bisa dipakai ulang). */
    public static function regenerate(): void
    {
        session_regenerate_id(true);
    }

    /** Hancurkan sesi (logout). */
    public static function destroy(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        self::$started = false;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function forget(string $key): void
    {
        unset($_SESSION[$key]);
    }

    /** Flash = pesan sekali tampil (sukses/gagal) setelah redirect. */
    public static function flash(string $type, string $message): void
    {
        $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
    }

    /** Ambil semua flash lalu hapus. Dipanggil dari layout admin. */
    public static function takeFlashes(): array
    {
        $f = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);
        return $f;
    }
}
