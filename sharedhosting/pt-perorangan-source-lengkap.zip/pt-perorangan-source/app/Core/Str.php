<?php
/**
 * FILE   : app/Core/Str.php
 * FUNGSI : Utilitas teks: slug, escaper HTML, potongan teks, diformat tanggal Indonesia.
 * UNTUK  : Dipakai hampir semua controller dan template tema.
 * KENAPA : Escaper terpusat mencegah XSS lupa htmlspecialchars.
 * TERKAIT: semua View/Controller. Pemanggilan paling umum: App\Core\Str::e($teks)
 * AMAN?  : PRIVAT.
 * PEMULA : Fungsi e() = "escape" = membersihkan teks agar aman ditampilkan di HTML.
 * JANGAN : Menampilkan data pengguna langsung tanpa e().
 */

declare(strict_types=1);

namespace App\Core;

final class Str
{
    /** Bersihkan teks agar aman ditampilkan di HTML (anti-XSS). */
    public static function e(mixed $value): string
    {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /** Buat slug URL: "Pendirian PT Perorangan!" → "pendirian-pt-perorangan". */
    public static function slug(string $text): string
    {
        $text = mb_strtolower(trim($text), 'UTF-8');
        if (function_exists('transliterator_transliterate')) {
            $text = (string) transliterator_transliterate('Any-Latin; Latin-ASCII', $text);
        } else {
            $t = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
            if ($t !== false) {
                $text = strtolower($t);
            }
        }
        $text = preg_replace('~[^a-z0-9]+~', '-', $text) ?? '';
        return trim($text, '-') ?: 'halaman';
    }

    /** Potong teks menjadi ringkasan dengan panjang tertentu. */
    public static function excerpt(string $text, int $length = 160): string
    {
        $text = trim(preg_replace('~\s+~', ' ', strip_tags($text)) ?? '');
        if (mb_strlen($text, 'UTF-8') <= $length) {
            return $text;
        }
        return mb_substr($text, 0, $length - 1, 'UTF-8') . '…';
    }

    /** Hapus karakter kontrol untuk input pengguna. */
    public static function clean(string $text): string
    {
        $text = trim(strip_tags($text));
        return preg_replace('~[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]~', '', $text) ?? '';
    }

    /** Format tanggal Indonesia: 2026-01-05 → 5 Januari 2026 */
    public static function tanggalIndo(?string $date): string
    {
        if (!$date) {
            return '';
        }
        $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        $ts = strtotime($date);
        if ($ts === false) {
            return '';
        }
        return (int) date('j', $ts) . ' ' . $bulan[(int) date('n', $ts)] . ' ' . date('Y', $ts);
    }

    /** Kunci acak (untuk token preview, dsb). */
    public static function random(int $bytes = 16): string
    {
        return bin2hex(random_bytes($bytes));
    }
}
