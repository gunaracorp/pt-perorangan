<?php
/**
 * FILE   : app/Core/Cache.php
 * FUNGSI : Cache file sederhana dengan tag + pembersihan saat konten berubah.
 * UNTUK  : Sitemap, daftar layanan, dan halaman yang jarang berubah.
 * KENAPA : Shared hosting tanpa Redis — file cache cukup dan aman; invalidasi wajib
 *          benar agar pengunjung tidak melihat konten lama setelah publish.
 * TERKAIT: app/Services/SitemapService.php, app/Models/Page.php (invalidate saat save)
 * AMAN?  : PRIVAT (cache disimpan di storage/cache, dilindungi .htaccess).
 * PEMULA : Cache = salinan sementara agar halaman lebih cepat. Saat konten diubah,
 *          cache lama otomatis dihapus (invalidasi).
 */

declare(strict_types=1);

namespace App\Core;

final class Cache
{
    private static function path(string $key): string
    {
        return STORAGE_DIR . '/cache/' . md5($key) . '.cache.json';
    }

    /** Ambil dari cache; bila kosong/kedaluwarsa, hitung lewat closure lalu simpan. */
    public static function remember(string $key, int $ttlSeconds, callable $compute): mixed
    {
        if (!app_config('features.cache_enabled', true)) {
            return $compute();
        }
        $file = self::path($key);
        if (is_file($file)) {
            $raw = json_decode((string) file_get_contents($file), true);
            if (is_array($raw) && ($raw['expires'] ?? 0) > time()) {
                return $raw['value'];
            }
        }
        $value = $compute();
        @file_put_contents($file, json_encode(['expires' => time() + $ttlSeconds, 'value' => $value]), LOCK_EX);
        return $value;
    }

    /** Hapus satu kunci. */
    public static function forget(string $key): void
    {
        @unlink(self::path($key));
    }

    /** Hapus semua cache — dipanggil ketika konten/tema/SEO diubah. */
    public static function flush(): void
    {
        foreach (glob(STORAGE_DIR . '/cache/*.cache.json') ?: [] as $file) {
            @unlink($file);
        }
    }
}
