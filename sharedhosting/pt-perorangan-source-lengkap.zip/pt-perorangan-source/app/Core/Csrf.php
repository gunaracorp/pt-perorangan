<?php
/**
 * FILE   : app/Core/Csrf.php
 * FUNGSI : Token CSRF untuk semua formulir yang mengubah data.
 * UNTUK  : Setiap <form> memanggil Csrf::field(); setiap POST tervalidasi Csrf::verify().
 * KENAPA : CSRF = serangan yang memaksa browser korban mengirim aksi tanpa sepengetahuannya.
 *          Token per-sesi yang hanya diketahui situs kita menggagalkannya.
 * TERKAIT: app/Core/Session.php, semua view admin & form publik.
 * AMAN?  : PRIVAT.
 * PEMULA : Jika membuat form baru, WAJIB menyisipkan {csrf} dan memanggil verify di controller.
 */

declare(strict_types=1);

namespace App\Core;

final class Csrf
{
    /** Ambil (atau buat) token sesi ini. */
    public static function token(): string
    {
        if (empty($_SESSION['_csrf'])) {
            $_SESSION['_csrf'] = bin2hex(random_bytes(32));
        }
        return (string) $_SESSION['_csrf'];
    }

    /** HTML input tersembunyi untuk ditempel di form. */
    public static function field(): string
    {
        return '<input type="hidden" name="_csrf" value="' . Str::e(self::token()) . '">';
    }

    /** Validasi token pada request POST saat ini. Mengembalikan true bila valid. */
    public static function verify(?string $token = null): bool
    {
        $token ??= (string) ($_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        $known = (string) ($_SESSION['_csrf'] ?? '');
        return $known !== '' && $token !== '' && hash_equals($known, $token);
    }

    /** Validasi + gagalkan request bila tidak valid (dipakai controller admin). */
    public static function guard(): void
    {
        if (!self::verify()) {
            http_response_code(419);
            Session::flash('error', 'Sesi keamanan formulir berakhir. Halaman dimuat ulang — silakan coba lagi.');
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/admin'));
            exit;
        }
    }
}
