<?php
/**
 * FILE   : app/Core/App.php
 * FUNGSI : Kernel aplikasi: urutan siklus request yang aman.
 * UNTUK  : Dipanggil public/index.php sekali untuk setiap kunjungan.
 * KENAPA : Alur tetap dan terdokumentasi: sesi → redirect 301/410 → route publik
 *          → 404 asli; route admin dipisah agar keamanan tidak tercampur.
 * TERKAIT: public/index.php, config/routes.php, app/Core/Router.php, app/Core/Session.php
 * AMAN?  : PRIVAT.
 * PEMULA : Ini "otak" yang menghubungkan URL → controller → tema → HTML yang dilihat pengunjung.
 */

declare(strict_types=1);

namespace App\Core;

use App\Models\Redirect;

final class App
{
    public static function run(): void
    {
        Session::start();

        $uri = (string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        // Normalisasi: buang trailing slash (kecuali root) untuk URL konsisten (SEO).
        if ($uri !== '/' && str_ends_with($uri, '/')) {
            $clean = rtrim($uri, '/');
            header('Location: ' . $clean, true, 301);
            exit;
        }
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

        // 1. Redirect manager (301/302/410) — sebelum routing agar URL lama tetap hidup.
        if ($method === 'GET') {
            $redirect = Redirect::match($uri);
            if ($redirect !== null) {
                Redirect::hit((int) $redirect['id']);
                if ($redirect['status'] === 410) {
                    http_response_code(410);
                    View::renderErrorPage(410, 'Konten ini telah dihapus permanen.');
                    return;
                }
                $target = (string) $redirect['target'];
                header('Location: ' . $target, true, (int) $redirect['status']);
                exit;
            }
        }

        // 2. Daftarkan route (publik + admin) dari config/routes.php.
        $router = new Router();
        (require CONFIG_DIR . '/routes.php')($router);

        // 3. Cocokkan dan jalankan.
        $match = $router->match($method, $uri);
        if ($match === null) {
            http_response_code(404);
            View::renderErrorPage(404, 'Halaman yang Anda cari tidak ditemukan.');
            return;
        }
        [$handler, $params] = $match;
        if (is_array($handler)) {
            [$class, $action] = $handler;
            $instance = new $class();
            $instance->{$action}(...array_values($params));
            return;
        }
        $handler($params);
    }

    /** URL absolut dari path relatif (memakai base_url config). */
    public static function url(string $path = '/'): string
    {
        return rtrim((string) app_config('base_url', ''), '/') . $path;
    }
}
