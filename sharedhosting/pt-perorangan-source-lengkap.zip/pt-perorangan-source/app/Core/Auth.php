<?php
/**
 * FILE   : app/Core/Auth.php
 * FUNGSI : Autentikasi admin (login, logout, rate limit, peran/permission).
 * UNTUK  : Semua controller admin. Halaman publik tidak memakai kelas ini.
 * KENAPA : Password di-hash (tidak pernah disimpan teks asli), percobaan login dibatasi,
 *          dan peran diperiksa DI SERVER — bukan hanya menyembunyikan tombol.
 * TERKAIT: app/Models/User.php, app/Controllers/Admin/AuthController.php
 * AMAN?  : PRIVAT.
 * PEMULA : Peran: owner (pemilik, semua akses), admin, editor (konten), reviewer.
 * JANGAN : Menonaktifkan rate limit atau menyimpan password tanpa hash.
 */

declare(strict_types=1);

namespace App\Core;

use App\Models\User;

final class Auth
{
    /** Coba login. Mengembalikan true bila berhasil. */
    public static function attempt(string $email, string $password): bool
    {
        $email = mb_strtolower(trim($email));
        if (self::tooManyAttempts($email)) {
            return false;
        }
        $user = User::findByEmail($email);
        $ok = $user && password_verify($password, (string) $user['password_hash'])
            && password_needs_rehash((string) $user['password_hash'], PASSWORD_DEFAULT) === false;

        self::logAttempt($email, $ok);

        if (!$ok) {
            return false;
        }
        Session::regenerate();
        Session::set('auth_user_id', (int) $user['id']);
        Session::set('auth_role', (string) $user['role']);
        Session::set('auth_name', (string) $user['name']);
        Session::set('auth_last_activity', time());
        User::touchLogin((int) $user['id']);
        return true;
    }

    public static function check(): bool
    {
        return (int) Session::get('auth_user_id', 0) > 0;
    }

    public static function id(): int
    {
        return (int) Session::get('auth_user_id', 0);
    }

    public static function role(): string
    {
        return (string) Session::get('auth_role', 'guest');
    }

    public static function name(): string
    {
        return (string) Session::get('auth_name', '');
    }

    /** Peran boleh melakukan aksi tertentu? (dipanggil di server, bukan hanya UI) */
    public static function can(string $action): bool
    {
        $role = self::role();
        $matrix = [
            'owner'    => ['*'],
            'admin'    => ['*'],
            'editor'   => ['content.*', 'media.*'],
            'reviewer' => ['content.view', 'content.review'],
        ];
        $allowed = $matrix[$role] ?? [];
        foreach ($allowed as $pattern) {
            if ($pattern === '*' || $pattern === $action || str_ends_with($pattern, '.*') && str_starts_with($action, substr($pattern, 0, -1))) {
                return true;
            }
        }
        return false;
    }

    /** Pintu masuk admin: redirect ke /admin/login bila belum login / tak berizin. */
    public static function requireLogin(string $action = '', string $redirect = '/admin/login'): void
    {
        if (!self::check()) {
            Session::flash('error', 'Silakan masuk terlebih dahulu.');
            header('Location: ' . $redirect);
            exit;
        }
        // Sesi kedaluwarsa (idle terlalu lama) → paksa keluar.
        $last = (int) Session::get('auth_last_activity', 0);
        $max  = (int) app_config('security.session_lifetime_minutes', 120) * 60;
        if ($last && (time() - $last) > $max) {
            self::logout(false);
            header('Location: /admin/login?expired=1');
            exit;
        }
        if ($action !== '' && !self::can($action)) {
            http_response_code(403);
            Session::flash('error', 'Peran Anda (' . self::role() . ') tidak memiliki izin untuk aksi ini.');
            header('Location: /admin');
            exit;
        }
    }

    public static function logout(bool $regenerate = true): void
    {
        Session::destroy();
    }

    // ---- Rate limit login (file-based; tanpa Redis sesuai batasan shared hosting) ----

    private static function attemptsFile(string $email): string
    {
        $safe = md5(mb_strtolower($email) . '|' . self::clientIp());
        return STORAGE_DIR . '/logs/login-attempts-' . $safe . '.json';
    }

    public static function tooManyAttempts(string $email): bool
    {
        $max = (int) app_config('security.login_max_attempts', 5);
        $decay = (int) app_config('security.login_decay_minutes', 15) * 60;
        $file = self::attemptsFile($email);
        if (!is_file($file)) {
            return false;
        }
        $data = json_decode((string) file_get_contents($file), true) ?: [];
        $data = array_values(array_filter($data, static fn($t) => (time() - (int) $t) < $decay));
        return count($data) >= $max;
    }

    private static function logAttempt(string $email, bool $success): void
    {
        $file = self::attemptsFile($email);
        $data = [];
        if (is_file($file)) {
            $data = json_decode((string) file_get_contents($file), true) ?: [];
        }
        $now = time();
        $decay = (int) app_config('security.login_decay_minutes', 15) * 60;
        $data = array_values(array_filter($data, static fn($t) => ($now - (int) $t) < $decay));
        $data[] = $now;
        @file_put_contents($file, json_encode($data), LOCK_EX);
    }

    /** IP klien (hash untuk privasi) — menghormati proxy standar cPanel. */
    public static function clientIp(): string
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if (in_array($ip, ['127.0.0.1', '::1'], true) && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (in_array($ip, ['127.0.0.1', '::1'], true) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $candidate = trim(explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
            if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                $ip = $candidate;
            }
        }
        return $ip;
    }

    public static function ipHash(): string
    {
        return hash('sha256', self::clientIp() . (string) app_config('security.app_key', ''));
    }
}
