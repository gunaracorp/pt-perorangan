<?php
/**
 * FILE   : app/Core/Database.php
 * FUNGSI : Koneksi database tunggal (singleton) via PDO + helper query aman.
 * UNTUK  : Semua Model. Mendukung MySQL (produksi cPanel) dan SQLite (uji lokal).
 * KENAPA : PDO prepared statement adalah benteng utama anti SQL Injection.
 * TERKAIT: app/Models/*, config/config.php (driver, kredensial).
 * AMAN?  : PRIVAT.
 * PEMULA : PDO = cara PHP berbicara dengan database secara aman. Prepared statement =
 *          data pengguna TIDAK digabung ke teks SQL, sehingga injeksi gagal.
 * JANGAN : Menggabungkan input pengguna langsung ke string SQL.
 */

declare(strict_types=1);

namespace App\Core;

use PDO;
use RuntimeException;

final class Database
{
    private static ?PDO $pdo = null;
    /** true bila driver = sqlite (dipakai untuk penyesuaian SQL kecil). */
    private static bool $sqlite = false;

    public static function pdo(): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }
        $cfg = (array) app_config('database', []);
        $driver = $cfg['driver'] ?? 'mysql';

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            if ($driver === 'sqlite') {
                self::$sqlite = true;
                $path = $cfg['sqlite_path'] ?? STORAGE_DIR . '/database.sqlite';
                @mkdir(dirname($path), 0755, true);
                self::$pdo = new PDO('sqlite:' . $path, null, null, $options);
                self::$pdo->exec('PRAGMA foreign_keys = ON');
                self::$pdo->exec('PRAGMA journal_mode = WAL');
            } else {
                self::$sqlite = false;
                $dsn = sprintf(
                    'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                    $cfg['host'] ?? 'localhost',
                    (int) ($cfg['port'] ?? 3306),
                    $cfg['database'] ?? '',
                    $cfg['charset'] ?? 'utf8mb4'
                );
                self::$pdo = new PDO($dsn, $cfg['username'] ?? '', $cfg['password'] ?? '', $options);
            }
        } catch (\PDOException $e) {
            // Jangan tampilkan kredensial. Log, lalu sampaikan pesan umum.
            @file_put_contents(
                STORAGE_DIR . '/logs/db-' . date('Y-m-d') . '.log',
                '[' . date('c') . '] Koneksi DB gagal: ' . $e->getMessage() . "\n",
                FILE_APPEND | LOCK_EX
            );
            throw new RuntimeException('Koneksi database gagal. Periksa config/config.php atau lihat log storage/logs.', 500, $e);
        }
        return self::$pdo;
    }

    public static function isSqlite(): bool
    {
        self::pdo();
        return self::$sqlite;
    }

    /** Jalankan query dengan parameter terikat (selalu gunakan ini untuk input pengguna). */
    public static function run(string $sql, array $params = []): \PDOStatement
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /** Ambil semua baris. */
    public static function all(string $sql, array $params = []): array
    {
        return self::run($sql, $params)->fetchAll();
    }

    /** Ambil satu baris (atau null). */
    public static function one(string $sql, array $params = []): ?array
    {
        $row = self::run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    /** Ambil satu nilai kolom pertama. */
    public static function value(string $sql, array $params = []): mixed
    {
        $row = self::run($sql, $params)->fetch(\PDO::FETCH_NUM);
        return $row === false ? null : $row[0];
    }

    /** ID dari insert terakhir. */
    public static function lastId(): int
    {
        return (int) self::pdo()->lastInsertId();
    }
}
