<?php
/**
 * FILE   : app/Core/Validator.php
 * FUNGSI : Validasi input server-side yang mudah dipakai.
 * UNTUK  : Semua controller yang menerima POST (admin + form kontak + impor).
 * KENAPA : Validasi client-side bisa dilewati; server wajib memeriksa ulang.
 * TERKAIT: semua controller.
 * AMAN?  : PRIVAT.
 * PEMULA : Aturan ditulis "namafield:required|min:3|max:100|email" dsb.
 */

declare(strict_types=1);

namespace App\Core;

final class Validator
{
    /** @var array<string,string> */
    private array $errors = [];

    /**
     * @param array<string,mixed> $data
     * @param array<string,string> $rules  contoh: ['email' => 'required|email', 'nama' => 'required|min:2|max:100']
     */
    public function __construct(private array $data, private array $rules)
    {
        foreach ($rules as $field => $ruleString) {
            $this->validateField((string) $field, $ruleString);
        }
    }

    public static function make(array $data, array $rules): self
    {
        return new self($data, $rules);
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    /** @return array<string,string> */
    public function errors(): array
    {
        return $this->errors;
    }

    public function firstError(): string
    {
        return (string) (reset($this->errors) ?: '');
    }

    private function validateField(string $field, string $ruleString): void
    {
        $value = $this->data[$field] ?? null;
        $label = $field;
        foreach (explode('|', $ruleString) as $rule) {
            [$name, $param] = array_pad(explode(':', $rule, 2), 2, null);
            switch ($name) {
                case 'required':
                    if ($value === null || trim((string) $value) === '') {
                        $this->errors[$field] = "$label wajib diisi.";
                        return;
                    }
                    break;
                case 'min':
                    if ($value !== null && mb_strlen(trim((string) $value), 'UTF-8') < (int) $param) {
                        $this->errors[$field] = "$label minimal $param karakter.";
                    }
                    break;
                case 'max':
                    if ($value !== null && mb_strlen(trim((string) $value), 'UTF-8') > (int) $param) {
                        $this->errors[$field] = "$label maksimal $param karakter.";
                    }
                    break;
                case 'email':
                    if ($value !== null && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $this->errors[$field] = "$label harus berupa email yang valid.";
                    }
                    break;
                case 'url':
                    if ($value !== null && $value !== '' && !filter_var($value, FILTER_VALIDATE_URL) && !preg_match('~^/[^\s]*$~', (string) $value)) {
                        $this->errors[$field] = "$label harus berupa URL atau path internal yang valid.";
                    }
                    break;
                case 'slug':
                    if ($value !== null && $value !== '' && !preg_match('~^[a-z0-9]+(?:-[a-z0-9]+)*$~', (string) $value)) {
                        $this->errors[$field] = "$label hanya boleh huruf kecil, angka, dan tanda hubung (format slug).";
                    }
                    break;
                case 'in':
                    $allowed = explode(',', (string) $param);
                    if ($value !== null && $value !== '' && !in_array((string) $value, $allowed, true)) {
                        $this->errors[$field] = "$label harus salah satu dari: " . implode(', ', $allowed) . '.';
                    }
                    break;
                case 'numeric':
                    if ($value !== null && $value !== '' && !is_numeric($value)) {
                        $this->errors[$field] = "$label harus berupa angka.";
                    }
                    break;
                case 'maxsize': // ukuran file MB
                    $size = isset($this->data['__file_size_' . $field]) ? (int) $this->data['__file_size_' . $field] : 0;
                    if ($size > ((int) $param) * 1024 * 1024) {
                        $this->errors[$field] = "$label melebihi batas $param MB.";
                    }
                    break;
            }
        }
    }
}
