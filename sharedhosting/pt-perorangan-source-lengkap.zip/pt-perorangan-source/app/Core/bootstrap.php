<?php
/**
 * FILE   : app/Core/bootstrap.php
 * FUNGSI : Autoloader sederhana, pemuatan konfigurasi, konstanta, dan handler error.
 * UNTUK  : Dipanggil paling awal oleh public/index.php dan public/install.php.
 * KENAPA : Satu titik masuk agar semua kelas dimuat konsisten tanpa Composer.
 * TERKAIT: app/Core/App.php, config/config.example.php
 * AMAN?  : PRIVAT (tidak boleh diakses langsung browser).
 * PEMULA : Tidak perlu mengedit file ini. Error tampilan debug hanya aktif jika
 *          config 'features.debug' = true (jangan aktifkan di produksi).
 */

declare(strict_types=1);

// ---- Konstanta dasar ----
if (!defined('APP_ROOT')) define('APP_ROOT', dirname(__DIR__, 2));   // root proyek
if (!defined('APP_DIR')) define('APP_DIR', APP_ROOT . '/app');
if (!defined('PUBLIC_DIR')) define('PUBLIC_DIR', APP_ROOT . '/public');
if (!defined('THEMES_DIR')) define('THEMES_DIR', APP_ROOT . '/themes');
if (!defined('CONTENT_DIR')) define('CONTENT_DIR', APP_ROOT . '/content');
if (!defined('CONFIG_DIR')) define('CONFIG_DIR', APP_ROOT . '/config');
if (!defined('STORAGE_DIR')) define('STORAGE_DIR', APP_ROOT . '/storage');

// ---- Autoloader PSR-4 mini (App\ → app/) tanpa Composer ----
spl_autoload_register(static function (string $class): void {
    if (str_starts_with($class, 'App\\')) {
        $path = APP_DIR . '/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (is_file($path)) {
            require $path;
        }
    }
});

// ---- Muat konfigurasi ----
if (!function_exists('app_config')) {
    /** Simpan konfigurasi global dalam variabel statis ringan. */
    $GLOBALS['__APP_CONFIG'] = null;

    function app_config(?string $key = null, mixed $default = null): mixed
    {
        if ($GLOBALS['__APP_CONFIG'] === null) {
            $file = CONFIG_DIR . '/config.php';
            if (!is_file($file)) {
                // Installer belum dijalankan → konfigurasi minimal untuk installer.
                $GLOBALS['__APP_CONFIG'] = ['environment' => 'development', 'base_url' => ''];
                return $key === null ? $GLOBALS['__APP_CONFIG'] : $default;
            }
            $GLOBALS['__APP_CONFIG'] = require $file;
        }
        if ($key === null) {
            return $GLOBALS['__APP_CONFIG'];
        }
        $value = $GLOBALS['__APP_CONFIG'];
        foreach (explode('.', $key) as $part) {
            if (!is_array($value) || !array_key_exists($part, $value)) {
                return $default;
            }
            $value = $value[$part];
        }
        return $value;
    }
}

// ---- Handler error & exception yang aman (tidak membocorkan detail di produksi) ----
set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(static function (Throwable $e): void {
    $debug = (bool) app_config('features.debug', false);
    $logLine = sprintf(
        "[%s] %s: %s in %s:%d\n%s\n",
        date('c'),
        get_class($e),
        $e->getMessage(),
        $e->getFile(),
        $e->getLine(),
        $e->getTraceAsString()
    );
    @file_put_contents(STORAGE_DIR . '/logs/error-' . date('Y-m-d') . '.log', $logLine, FILE_APPEND | LOCK_EX);

    http_response_code(500);
    header('Content-Type: text/html; charset=UTF-8');
    if ($debug) {
        echo '<h1>Terjadi Error (mode debug)</h1><pre>'
            . htmlspecialchars($e->getMessage() . "\n" . $e->getFile() . ':' . $e->getLine(), ENT_QUOTES, 'UTF-8')
            . '</pre>';
    } else {
        // Tampilkan halaman 500 bertema bila memungkinkan, tanpa detail teknis.
        echo '<!doctype html><html lang="id"><meta charset="utf-8">'
            . '<title>Kesalahan Server</title><body style="font-family:sans-serif;text-align:center;padding:10vh 5%">'
            . '<h1>500 — Kesalahan Server</h1><p>Maaf, terjadi kesalahan pada server kami. '
            . 'Silakan coba beberapa saat lagi.</p></body></html>';
    }
});

// ---- Pastikan folder storage bisa ditulis ----
foreach (['cache', 'logs', 'backups'] as $dir) {
    $path = STORAGE_DIR . '/' . $dir;
    if (!is_dir($path)) {
        @mkdir($path, 0755, true);
    }
}
