<?php
/**
 * FILE   : app/Core/Router.php
 * FUNGSI : Router front-controller: mencocokkan URL dengan route terdaftar & jalur {param}.
 * UNTUK  : Dipakai App::run(). Route didefinisikan di config/routes.php (terpusat).
 * KENAPA : URL dikelola eksplisit & konsisten — fondasi keamanan dan SEO.
 * TERKAIT: config/routes.php, app/Core/App.php
 * AMAN?  : PRIVAT.
 * PEMULA : Route = aturan "URL ini ditangani fungsi ini". {slug} = bagian dinamis.
 */

declare(strict_types=1);

namespace App\Core;

final class Router
{
    /** @var array<string, array<int, array{pattern:string, handler:callable|array}>> */
    private array $routes = ['GET' => [], 'POST' => []];

    public function get(string $pattern, array|callable $handler): void
    {
        $this->routes['GET'][] = ['pattern' => $pattern, 'handler' => $handler];
    }

    public function post(string $pattern, array|callable $handler): void
    {
        $this->routes['POST'][] = ['pattern' => $pattern, 'handler' => $handler];
    }

    /** Jalankan pencocokan. Mengembalikan [handler, params] atau null. */
    public function match(string $method, string $path): ?array
    {
        $method = strtoupper($method);
        foreach ($this->routes[$method] ?? [] as $route) {
            $regex = $this->toRegex($route['pattern']);
            if (preg_match($regex, $path, $m)) {
                $params = [];
                foreach ($m as $k => $v) {
                    if (!is_int($k)) {
                        $params[$k] = $v;
                    }
                }
                return [$route['handler'], $params];
            }
        }
        return null;
    }

    /** Ubah pola "/layanan/{slug}" menjadi regex bernama. Param "path" menerima multi-segmen. */
    private function toRegex(string $pattern): string
    {
        $regex = preg_replace_callback('~\{([a-zA-Z_][a-zA-Z0-9_]*)\}~', static function ($m) {
            return $m[1] === 'path'
                ? '(?P<path>(?:[A-Za-z0-9._\-\/]+)?)'
                : '(?P<' . $m[1] . '>[^/]+)';
        }, $pattern) ?? $pattern;
        return '~^' . $regex . '$~u';
    }
}
