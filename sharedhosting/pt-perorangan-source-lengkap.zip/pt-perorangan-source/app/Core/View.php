<?php
/**
 * FILE   : app/Core/View.php
 * FUNGSI : Renderer tema: menggabungkan template tema + layout + komponen + data.
 * UNTUK  : Semua controller publik memanggil View::render('template', $data).
 * KENAPA : Tema benar-benar mengendalikan tampilan — core hanya menyediakan data.
 * TERKAIT: themes/pt-perorangan/**, app/Core/Theme.php
 * AMAN?  : PRIVAT.
 * PEMULA : "Template" = kerangka halaman; "komponen" = potongan kecil (header, footer).
 *          Data dari controller dikirim ke template lewat variabel $ (diescape saat echo).
 * JANGAN : Menulis HTML mentah dari input pengguna di template tanpa e().
 */

declare(strict_types=1);

namespace App\Core;

final class View
{
    /** Nama tema aktif (dari config). */
    public static function themeName(): string
    {
        return (string) app_config('theme', 'pt-perorangan');
    }

    private static function themeDir(): string
    {
        return THEMES_DIR . '/' . self::themeName();
    }

    /**
     * Render halaman publik utuh: template + layout + head SEO + tokens CSS.
     * @param array<string,mixed> $data
     */
    public static function render(string $template, array $data = []): void
    {
        $theme = self::themeDir();
        $templateFile = $theme . '/templates/' . $template . '.php';
        if (!is_file($templateFile)) {
            throw new \RuntimeException('Template tema tidak ditemukan: ' . $template);
        }

        // Data umum untuk semua halaman.
        $data['site'] = Theme::siteData();
        $data['seo'] = Theme::buildSeo($data['seo'] ?? []);
        $data['cssVars'] = Theme::cssVariables();

        // Ekstrak data menjadi variabel lokal template.
        extract($data, EXTR_SKIP);
        ob_start();
        include $templateFile;
        $content = (string) ob_get_clean();

        $layoutFile = $theme . '/layouts/' . ($data['layout'] ?? 'default') . '.php';
        if (!is_file($layoutFile)) {
            $layoutFile = $theme . '/layouts/default.php';
        }
        include $layoutFile; // layout mencetak $content dan memanggil komponen
    }

    /** Sertakan komponen tema (header/footer/blok). Path relatif ke folder komponen. */
    public static function component(string $name, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        $file = self::themeDir() . '/components/' . $name . '.php';
        if (is_file($file)) {
            include $file;
        }
    }

    /** Render satu blok konten (page builder) dari tema. */
    public static function block(array $block): void
    {
        $type = (string) ($block['type'] ?? '');
        $file = self::themeDir() . '/templates/blocks/' . $type . '.php';
        if (!is_file($file)) {
            return; // blok tidak dikenal dilewati diam-diam (schema blocks.php menfilter di admin)
        }
        $data = $block['data'] ?? [];
        extract($data, EXTR_SKIP);
        include $file;
    }

    /** Halaman error publik (404/410/500) bertema, dengan status code yang benar. */
    public static function renderErrorPage(int $code, string $message): void
    {
        $theme = self::themeDir();
        $data = [
            'site' => Theme::siteData(),
            'seo'  => ['title' => ($code === 410 ? 'Konten Dihapus' : 'Halaman Tidak Ditemukan'),
                       'description' => $message, 'robots' => 'noindex, follow', 'canonical' => null],
            'cssVars' => Theme::cssVariables(),
            'code' => $code,
            'message' => $message,
        ];
        extract($data, EXTR_SKIP);
        $errorFile = $theme . '/templates/' . ($code === 410 ? '410' : '404') . '.php';
        if (!is_file($errorFile)) {
            $errorFile = $theme . '/templates/404.php';
        }
        $templateFile = is_file($errorFile) ? $errorFile : null;
        if ($templateFile === null) {
            echo '<!doctype html><html lang="id"><meta charset="utf-8"><title>404</title>'
                . '<body style="font-family:sans-serif;text-align:center;padding:15vh 5%"><h1>404</h1>'
                . '<p>' . Str::e($message) . '</p><a href="/">Kembali ke beranda</a></body></html>';
            return;
        }
        ob_start();
        include $templateFile;
        $content = (string) ob_get_clean();
        include $theme . '/layouts/default.php';
    }
}
