<?php
/**
 * FILE   : app/Core/Theme.php
 * FUNGSI : Jembatan core ↔ tema: data situs, design tokens → CSS variables, SEO head.
 * UNTUK  : View, layout, dan customizer admin (opsi tampilan tanpa edit kode).
 * KENAPA : Opsi tema disimpan di tabel settings; tema membacanya lewat sini —
 *          sehingga admin bisa mengubah warna/logo/tipografi dari dashboard.
 * TERKAIT: themes/pt-perorangan/theme.json, app/Models/Setting.php, app/Core/Cache.php
 * AMAN?  : PRIVAT.
 * PEMULA : "Design token" = daftar pengaturan desain (warna, radius, lebar) yang
 *          diubah dari admin, lalu disisipkan sebagai CSS variables di <head>.
 */

declare(strict_types=1);

namespace App\Core;

use App\Models\Setting;

final class Theme
{
    /** Data situs yang sering dipakai tema (nama, logo, kontak, sosial). */
    public static function siteData(): array
    {
        $s = Setting::allGrouped('site');
        return [
            'name'        => (string) ($s['site_name'] ?? 'PT Perorangan'),
            'tagline'     => (string) ($s['site_tagline'] ?? 'Pendirian PT Perorangan Cepat, Resmi, Terpandu'),
            'logo'        => (string) ($s['site_logo'] ?? ''),
            'phone'       => (string) ($s['contact_phone'] ?? ''),
            'whatsapp'    => (string) ($s['contact_whatsapp'] ?? ''),
            'email'       => (string) ($s['contact_email'] ?? ''),
            'address'     => (string) ($s['contact_address'] ?? ''),
            'maps_embed'  => (string) ($s['contact_maps'] ?? ''),
            'social'      => [
                'instagram' => (string) ($s['social_instagram'] ?? ''),
                'facebook'  => (string) ($s['social_facebook'] ?? ''),
                'linkedin'  => (string) ($s['social_linkedin'] ?? ''),
                'tiktok'    => (string) ($s['social_tiktok'] ?? ''),
            ],
            'wa_message'  => (string) ($s['cta_wa_message'] ?? 'Halo, saya ingin konsultasi pendirian PT Perorangan.'),
            'footer_note' => (string) ($s['footer_note'] ?? 'Konsultan independen untuk pendirian PT Perorangan. Bukan afiliasi instansi pemerintah.'),
        ];
    }

    /** Susun CSS custom properties dari pengaturan customizer (dengan nilai default). */
    public static function cssVariables(): string
    {
        $c = Setting::allGrouped('theme');
        $map = [
            '--c-primary'    => $c['color_primary']    ?? '#5b3df5',
            '--c-accent'     => $c['color_accent']     ?? '#22d3ee',
            '--c-bg'         => $c['color_bg']         ?? '#0b0f1e',
            '--c-surface'    => $c['color_surface']    ?? '#121831',
            '--c-text'       => $c['color_text']       ?? '#e8ecff',
            '--c-muted'      => $c['color_muted']      ?? '#9aa3c7',
            '--radius'       => $c['ui_radius']        ?? '16px',
            '--container'    => $c['layout_width']     ?? '1200px',
            '--font-head'    => $c['font_heading']     ?? "'Space Grotesk', system-ui, sans-serif",
            '--font-body'    => $c['font_body']        ?? "'Inter', system-ui, sans-serif",
            '--motion-speed' => $c['motion_speed']     ?? '0.6s',
            '--header-style' => $c['header_style']     ?? 'glass',
            '--footer-style' => $c['footer_style']     ?? 'grid',
        ];
        // Validasi nilai agar tidak bisa menyuntik CSS berbahaya.
        $safe = static function (string $v): string {
            $v = trim(str_replace(['<', '>', '"', "'", '\\', ';', '{', '}', 'url('], '', $v));
            return $v === '' ? 'inherit' : $v;
        };
        $out = [];
        foreach ($map as $key => $value) {
            $out[] = $key . ': ' . $safe((string) $value) . ';';
        }
        return implode(' ', $out);
    }

    /** Bentuk tag SEO lengkap untuk <head> dari data per halaman. */
    public static function buildSeo(array $seo): array
    {
        $base = rtrim((string) app_config('base_url', ''), '/');
        $title = trim((string) ($seo['title'] ?? '')) ?: 'PT Perorangan';
        $siteName = self::siteData()['name'];
        $fullTitle = $title === $siteName ? $title : $title . ' — ' . $siteName;
        return [
            'title'       => $fullTitle,
            'description' => Str::excerpt((string) ($seo['description'] ?? ''), 160),
            'canonical'   => !empty($seo['canonical']) ? $seo['canonical'] : ($base . ($_SERVER['REQUEST_URI'] ?? '/')),
            'robots'      => (string) ($seo['robots'] ?? 'index, follow'),
            'og_image'    => !empty($seo['og_image']) ? (str_starts_with($seo['og_image'], 'http') ? $seo['og_image'] : $base . $seo['og_image']) : '',
            'og_type'     => (string) ($seo['og_type'] ?? 'website'),
            'jsonld'      => $seo['jsonld'] ?? [],
        ];
    }
}
