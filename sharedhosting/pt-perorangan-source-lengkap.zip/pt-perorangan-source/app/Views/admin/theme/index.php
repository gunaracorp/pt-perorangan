<?php
/**
 * FILE   : app/Views/admin/theme/index.php
 * FUNGSI : Theme customizer — ubah warna/font/gaya dengan pratinjau iframe langsung.
 * AMAN?  : PRIVAT. Nilai tervalidasi controller; CSS variables disanitasi Theme.php.
 * PEMULA : Setiap kontrol punya penjelasan. Klik "Simpan" → situs langsung berubah.
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Theme Customizer</h1></div>

<div class="customizer-layout">
  <form method="post" action="/admin/tema" class="admin-card customizer-controls">
    <?= Csrf::field() ?>
    <?php foreach ($controls as $c): ?>
    <div class="form-row">
      <label for="<?= Str::e($c['key']) ?>"><?= Str::e($c['label']) ?></label>
      <?php if ($c['type'] === 'color'): ?>
      <input type="color" id="<?= Str::e($c['key']) ?>" name="<?= Str::e($c['key']) ?>" value="<?= Str::e($current[$c['key']] ?? $c['default']) ?>">
      <?php elseif ($c['type'] === 'select'): ?>
      <select id="<?= Str::e($c['key']) ?>" name="<?= Str::e($c['key']) ?>" data-customizer="1">
        <?php foreach ($c['options'] as $val => $label): ?>
        <option value="<?= Str::e($val) ?>" <?= (($current[$c['key']] ?? '') === $val || (!isset($current[$c['key']]) && $c['default'] === $val)) ? 'selected' : '' ?>><?= Str::e($label) ?></option>
        <?php endforeach; ?>
      </select>
      <?php else: ?>
      <input type="text" id="<?= Str::e($c['key']) ?>" name="<?= Str::e($c['key']) ?>" value="<?= Str::e($current[$c['key']] ?? $c['default']) ?>">
      <?php endif; ?>
      <p class="hint"><?= Str::e($c['desc'] ?? '') ?></p>
    </div>
    <?php endforeach; ?>
    <button class="btn btn-primary btn-lg" type="submit">💾 Simpan Tampilan</button>
  </form>

  <div class="admin-card preview-card">
    <div class="preview-head"><h2>Pratinjau</h2>
      <div class="viewport-switch" role="group" aria-label="Ukuran pratinjau">
        <button type="button" data-vp="desktop" class="active" aria-pressed="true">🖥</button>
        <button type="button" data-vp="tablet" aria-pressed="false">📱</button>
      </div>
    </div>
    <div class="preview-frame-wrap" id="previewWrap">
      <iframe id="previewFrame" src="/" title="Pratinjau situs" loading="lazy"></iframe>
    </div>
    <p class="hint">Pratinjau menampilkan situs live. Perubahan warna akan terlihat setelah disimpan.</p>
  </div>
</div>
