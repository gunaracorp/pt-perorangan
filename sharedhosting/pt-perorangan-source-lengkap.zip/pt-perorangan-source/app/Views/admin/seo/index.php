<?php
/**
 * FILE   : app/Views/admin/seo/index.php — redirect manager + sitemap.
 * AMAN?  : PRIVAT.
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>SEO</h1></div>

<div class="admin-grid-2">
  <section class="admin-card">
    <h2>Tambah Redirect</h2>
    <form method="post" action="/admin/seo/redirect">
      <?= Csrf::field() ?>
      <div class="form-row"><label>URL lama (path)</label>
        <input name="from_path" type="text" required maxlength="300" placeholder="/layanan-lama"></div>
      <div class="form-row"><label>Tipe</label>
        <select name="status">
          <option value="301">301 — Pindah permanen (untuk SEO)</option>
          <option value="302">302 — Sementara</option>
          <option value="410">410 — Konten dihapus permanen</option>
        </select></div>
      <div class="form-row"><label>URL tujuan (kosongkan bila 410)</label>
        <input name="target" type="text" maxlength="300" placeholder="/layanan-baru"></div>
      <button class="btn btn-primary" type="submit">Simpan Redirect</button>
    </form>

    <h2 style="margin-top:32px">Sitemap</h2>
    <p class="hint">Sitemap otomatis diperbarui (cache 10 menit):</p>
    <ul class="source-list">
      <li><a href="<?= Str::e($base) ?>/sitemap.xml" target="_blank" rel="noopener"><?= Str::e($base) ?>/sitemap.xml</a> (indeks)</li>
      <li><a href="<?= Str::e($base) ?>/sitemap-pages.xml" target="_blank" rel="noopener">sitemap-pages.xml</a></li>
      <li><a href="<?= Str::e($base) ?>/sitemap-services.xml" target="_blank" rel="noopener">sitemap-services.xml</a></li>
      <li><a href="<?= Str::e($base) ?>/sitemap-articles.xml" target="_blank" rel="noopener">sitemap-articles.xml</a></li>
    </ul>
    <form method="post" action="/admin/seo/sitemap-bersihkan-cache" style="margin-top:12px">
      <?= Csrf::field() ?>
      <button class="btn btn-ghost" type="submit">♻️ Bersihkan Cache Sitemap Sekarang</button>
    </form>
  </section>

  <section class="admin-card">
    <h2>Daftar Redirect (<?= count($redirects) ?>)</h2>
    <table class="admin-table">
      <thead><tr><th>Dari</th><th>Ke</th><th>Status</th><th>Hit</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($redirects as $r): ?>
      <tr>
        <td><code><?= Str::e($r['from_path']) ?></code></td>
        <td><code><?= Str::e($r['target'] ?: '—') ?></code></td>
        <td><?= (int) $r['status'] ?></td>
        <td><?= (int) $r['hits'] ?></td>
        <td>
          <form method="post" action="/admin/seo/redirect/<?= (int) $r['id'] ?>/hapus" data-confirm="Hapus redirect ini?">
            <?= Csrf::field() ?>
            <button type="submit" class="link-danger">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>
</div>
