<?php
/**
 * FILE   : app/Views/admin/users/index.php
 * AMAN?  : PRIVAT (owner/admin saja).
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Pengguna</h1></div>

<div class="admin-grid-2">
  <section class="admin-card">
    <h2>Tambah Pengguna</h2>
    <form method="post" action="/admin/pengguna">
      <?= Csrf::field() ?>
      <div class="form-row"><label>Nama <span class="req">*</span></label>
        <input name="name" type="text" required maxlength="100"></div>
      <div class="form-row"><label>Email <span class="req">*</span></label>
        <input name="email" type="email" required maxlength="150"></div>
      <div class="form-row"><label>Kata sandi (min 10 karakter) <span class="req">*</span></label>
        <input name="password" type="password" required minlength="10" autocomplete="new-password"></div>
      <div class="form-row"><label>Peran</label>
        <select name="role">
          <option value="editor">Editor — kelola konten</option>
          <option value="reviewer">Reviewer — tinjau konten</option>
          <option value="admin">Admin — akses penuh</option>
          <option value="owner">Owner — pemilik</option>
        </select></div>
      <button class="btn btn-primary" type="submit">Buat Pengguna</button>
    </form>
  </section>

  <section class="admin-card">
    <h2>Daftar Pengguna</h2>
    <table class="admin-table">
      <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Login terakhir</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
      <tr>
        <td><?= Str::e($u['name']) ?><?= (int) $u['id'] === (int) $auth['id'] ? ' (Anda)' : '' ?></td>
        <td><?= Str::e($u['email']) ?></td>
        <td><span class="status-pill status-<?= Str::e($u['role']) ?>"><?= Str::e($u['role']) ?></span></td>
        <td><?= $u['last_login_at'] ? Str::e(Str::tanggalIndo($u['last_login_at'])) : 'belum pernah' ?></td>
        <td>
          <?php if ((int) $u['id'] !== (int) $auth['id']): ?>
          <form method="post" action="/admin/pengguna/<?= (int) $u['id'] ?>/hapus" data-confirm="Hapus pengguna ini?">
            <?= Csrf::field() ?>
            <button type="submit" class="link-danger">Hapus</button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>
</div>
