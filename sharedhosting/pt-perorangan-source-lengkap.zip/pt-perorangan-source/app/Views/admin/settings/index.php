<?php
/**
 * FILE   : app/Views/admin/settings/index.php
 * AMAN?  : PRIVAT.
 * PEMULA : Logo harus diunggah dulu di menu Media, lalu salin path-nya ke sini.
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Pengaturan Situs</h1></div>

<form method="post" action="/admin/pengaturan">
  <?= Csrf::field() ?>
  <div class="admin-grid-2">
    <section class="admin-card">
      <h2>Identitas</h2>
      <div class="form-row"><label>Nama situs</label>
        <input name="site_name" type="text" maxlength="100" value="<?= Str::e($site['site_name'] ?? '') ?>"></div>
      <div class="form-row"><label>Tagline</label>
        <input name="site_tagline" type="text" maxlength="200" value="<?= Str::e($site['site_tagline'] ?? '') ?>"></div>
      <div class="form-row"><label>Logo (path media)</label>
        <input name="site_logo" type="text" maxlength="300" value="<?= Str::e($site['site_logo'] ?? '') ?>" placeholder="/media/namafile.png">
        <p class="hint">Unggah dulu di menu Media, lalu salin path <code>/media/...</code> ke sini.</p></div>
      <div class="form-row"><label>Catatan footer / disclaimer</label>
        <textarea name="footer_note" rows="2" maxlength="300"><?= Str::e($site['footer_note'] ?? '') ?></textarea></div>
    </section>

    <section class="admin-card">
      <h2>Kontak & CTA</h2>
      <div class="form-row"><label>Nomor WhatsApp (CTA tombol)</label>
        <input name="contact_whatsapp" type="text" maxlength="30" value="<?= Str::e($site['contact_whatsapp'] ?? '') ?>" placeholder="6281234567890"></div>
      <div class="form-row"><label>Pesan otomatis WhatsApp</label>
        <input name="cta_wa_message" type="text" maxlength="200" value="<?= Str::e($site['cta_wa_message'] ?? '') ?>"></div>
      <div class="form-row"><label>Telepon</label>
        <input name="contact_phone" type="text" maxlength="30" value="<?= Str::e($site['contact_phone'] ?? '') ?>"></div>
      <div class="form-row"><label>Email</label>
        <input name="contact_email" type="email" maxlength="150" value="<?= Str::e($site['contact_email'] ?? '') ?>"></div>
      <div class="form-row"><label>Alamat</label>
        <textarea name="contact_address" rows="2" maxlength="300"><?= Str::e($site['contact_address'] ?? '') ?></textarea></div>
      <div class="form-row"><label>Embed Google Maps (iframe, opsional)</label>
        <textarea name="contact_maps" rows="2" maxlength="2000" placeholder="<iframe ...></iframe>"><?= Str::e($site['contact_maps'] ?? '') ?></textarea>
        <p class="hint">Hanya diisi admin terpercaya. Tempel kode embed iframe resmi dari Google Maps.</p></div>
    </section>
  </div>

  <?php if ($auth['role'] === 'owner' || $auth['role'] === 'admin'): ?>
  <section class="admin-card" style="max-width:560px">
    <h2>Verifikasi & Analitik (opsional)</h2>
    <div class="form-row"><label>Kode verifikasi Google Search Console</label>
      <input name="gsc_verification" type="text" maxlength="100" value="<?= Str::e($analytics['gsc_verification'] ?? '') ?>" placeholder="contoh: abc123...="></div>
    <div class="form-row"><label>ID Google Analytics (G-XXXXXXX)</label>
      <input name="gtag_id" type="text" maxlength="30" value="<?= Str::e($analytics['gtag_id'] ?? '') ?>" placeholder="G-XXXXXXXXXX"></div>
  </section>
  <?php endif; ?>

  <button class="btn btn-primary btn-lg" type="submit">💾 Simpan Pengaturan</button>
</form>
