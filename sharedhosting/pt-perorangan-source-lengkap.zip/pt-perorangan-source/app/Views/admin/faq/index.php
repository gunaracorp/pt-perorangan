<?php
/**
 * FILE   : app/Views/admin/faq/index.php
 * AMAN?  : PRIVAT.
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>FAQ</h1></div>

<div class="admin-grid-2">
  <section class="admin-card">
    <h2>Tambah FAQ</h2>
    <form method="post" action="/admin/faq">
      <?= Csrf::field() ?>
      <div class="form-row"><label>Pertanyaan <span class="req">*</span></label>
        <input name="question" type="text" required maxlength="300"></div>
      <div class="form-row"><label>Jawaban <span class="req">*</span></label>
        <textarea name="answer" rows="4" required></textarea></div>
      <div class="form-row"><label>Terhubung ke layanan (opsional)</label>
        <select name="service_id">
          <option value="0">— umum (tampil di semua) —</option>
          <?php foreach ($services as $s): ?>
          <option value="<?= (int) $s['id'] ?>"><?= Str::e(Str::excerpt((string) $s['title'], 50)) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="form-row"><label>Status</label>
        <select name="status">
          <option value="published">Published</option>
          <option value="draft">Draft</option>
        </select></div>
      <button class="btn btn-primary" type="submit">Simpan</button>
    </form>
  </section>

  <section class="admin-card">
    <h2>Daftar FAQ</h2>
    <table class="admin-table">
      <thead><tr><th>Pertanyaan</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($faqs as $f): ?>
      <tr>
        <td><?= Str::e(Str::excerpt((string) $f['question'], 60)) ?></td>
        <td><span class="status-pill status-<?= Str::e($f['status']) ?>"><?= Str::e($f['status']) ?></span></td>
        <td>
          <form method="post" action="/admin/faq/<?= (int) $f['id'] ?>/hapus" data-confirm="Hapus FAQ ini?">
            <input type="hidden" name="_csrf" value="<?= Csrf::token() ?>">
            <button type="submit" class="link-danger">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>
</div>
