<?php
/**
 * FILE   : app/Views/admin/login.php
 * FUNGSI : Formulir login admin.
 * AMAN?  : PRIVAT. Token CSRF wajib; error sengaja generik.
 */

use App\Core\Csrf;
use App\Core\Str;
?>
<div class="login-wrap">
  <form class="login-card" method="post" action="/admin/login">
    <?= Csrf::field() ?>
    <h1>◆ Masuk Dashboard</h1>
    <?php if (!empty($expired)): ?><p class="login-note">Sesi Anda berakhir. Silakan masuk kembali.</p><?php endif; ?>
    <div class="form-row">
      <label for="email">Email</label>
      <input id="email" name="email" type="email" required autocomplete="username" autofocus>
    </div>
    <div class="form-row">
      <label for="password">Kata sandi</label>
      <input id="password" name="password" type="password" required autocomplete="current-password" minlength="8">
    </div>
    <button class="btn btn-primary" type="submit">Masuk</button>
    <p class="login-note">Percobaan login dibatasi 5 kali per 15 menit demi keamanan.</p>
  </form>
</div>
