<?php
/**
 * FILE   : app/Views/admin/messages/index.php
 * AMAN?  : PRIVAT.
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Pesan Masuk</h1></div>

<?php if (empty($messages)): ?>
<p>Belum ada pesan dari formulir kontak.</p>
<?php else: ?>
<table class="admin-table">
  <thead><tr><th>Waktu</th><th>Nama</th><th>Kontak</th><th>Pesan</th><th>Status</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($messages as $m): ?>
  <tr>
    <td><?= Str::e(date('d M H:i', strtotime((string) $m['created_at']))) ?></td>
    <td><strong><?= Str::e($m['name']) ?></strong><br><?= Str::e($m['subject'] ?? '') ?></td>
    <td><?= Str::e($m['email']) ?><br><?= Str::e($m['phone'] ?? '') ?></td>
    <td class="msg-cell"><?= Str::e(Str::excerpt((string) $m['message'], 140)) ?></td>
    <td><span class="status-pill status-<?= Str::e($m['status']) ?>"><?= Str::e($m['status']) ?></span></td>
    <td class="row-actions">
      <?php foreach (['read' => 'Dibaca', 'replied' => 'Dibalas'] as $val => $label): ?>
      <form method="post" action="/admin/pesan/<?= (int) $m['id'] ?>/status">
        <?= Csrf::field() ?>
        <input type="hidden" name="status" value="<?= Str::e($val) ?>">
        <button type="submit" class="btn-ghost btn-sm as-link"><?= $label ?></button>
      </form>
      <?php endforeach; ?>
      <form method="post" action="/admin/pesan/<?= (int) $m['id'] ?>/hapus" data-confirm="Hapus pesan ini?">
        <?= Csrf::field() ?>
        <button type="submit" class="link-danger">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php endif; ?>
