<?php
/**
 * FILE   : app/Views/admin/services/index.php
 * AMAN?  : PRIVAT.
 */
use App\Core\Str;
?>
<div class="admin-head">
  <h1>Layanan</h1>
  <a class="btn btn-primary" href="/admin/layanan/baru">+ Layanan Baru</a>
</div>

<table class="admin-table">
  <thead><tr><th>Judul</th><th>Slug</th><th>Kategori</th><th>Status</th><th>Diubah</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php $catNames = []; foreach ($categories as $c) { $catNames[(int) $c['id']] = $c['name']; } ?>
  <?php foreach ($services as $s): ?>
  <tr>
    <td><strong><?= Str::e(Str::excerpt((string) $s['title'], 42)) ?></strong><?= !empty($s['featured']) ? ' ⭐' : '' ?></td>
    <td><code>/layanan/<?= Str::e($s['slug']) ?></code></td>
    <td><?= Str::e($catNames[(int) ($s['category_id'] ?? 0)] ?? '—') ?></td>
    <td><span class="status-pill status-<?= Str::e($s['status']) ?>"><?= Str::e($s['status']) ?></span></td>
    <td><?= Str::e(Str::tanggalIndo($s['updated_at'])) ?></td>
    <td class="row-actions">
      <a href="/admin/layanan/<?= (int) $s['id'] ?>/edit">Edit</a>
      <a href="/admin/layanan/<?= (int) $s['id'] ?>/pratinjau" target="_blank" rel="noopener">Pratinjau</a>
      <form method="post" action="/admin/layanan/<?= (int) $s['id'] ?>/hapus" data-confirm="Hapus layanan ini?">
        <input type="hidden" name="_csrf" value="<?= \App\Core\Csrf::token() ?>">
        <button type="submit" class="link-danger">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
