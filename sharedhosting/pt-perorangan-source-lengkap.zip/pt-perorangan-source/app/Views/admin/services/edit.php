<?php
/**
 * FILE   : app/Views/admin/services/edit.php
 * FUNGSI : Editor layanan: metadata + fakta terstruktur (biaya resmi vs jasa, waktu,
 *          syarat) + page builder (UI identik dengan editor halaman) + SEO.
 * AMAN?  : PRIVAT.
 * PEMULA : Fakta terstruktur di sini muncul sebagai "kartu fakta" di halaman publik
 *          dan membantu gerbang kualitas + JSON-LD.
 */

use App\Core\Csrf;
use App\Core\Str;

$isEdit = $service !== null;
$id = $isEdit ? (int) $service['id'] : 0;
?>
<div class="admin-head">
  <h1><?= $isEdit ? 'Edit Layanan' : 'Layanan Baru' ?></h1>
  <div class="head-actions">
    <?php if ($isEdit): ?><a class="btn btn-ghost" href="/admin/layanan/<?= $id ?>/pratinjau" target="_blank" rel="noopener">👁 Pratinjau</a><?php endif; ?>
    <a class="btn btn-ghost" href="/admin/layanan">← Daftar</a>
  </div>
</div>

<?php if ($isEdit && !empty($quality)): ?>
<div class="quality-panel admin-card <?= $quality['pass'] ? 'qg-pass' : 'qg-fail' ?>">
  <strong><?= $quality['pass'] ? '✓ Siap terbitkan' : '✕ Belum siap terbitkan' ?></strong>
  <span>Skor: <?= (int) $quality['score'] ?>/100</span>
  <ul><?php foreach ($quality['issues'] as $i): ?><li><?= Str::e($i) ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<form method="post" action="<?= $isEdit ? '/admin/layanan/' . $id . '/simpan' : '/admin/layanan/baru' ?>">
  <?= Csrf::field() ?>
  <input type="hidden" name="blocks" id="blocksInput" value='<?= Str::e(json_encode($blocks ?: [], JSON_UNESCAPED_UNICODE)) ?>'>

  <div class="editor-layout">
    <div class="editor-col-left">
      <section class="admin-card">
        <h2>Informasi Layanan</h2>
        <div class="form-row"><label>Judul layanan <span class="req">*</span></label>
          <input name="title" type="text" required maxlength="150" value="<?= Str::e($service['title'] ?? '') ?>"></div>
        <div class="form-row"><label>Slug URL (kosong = otomatis)</label>
          <input name="slug" type="text" maxlength="150" value="<?= Str::e($service['slug'] ?? '') ?>"></div>
        <div class="form-row"><label>Ringkasan</label>
          <textarea name="excerpt" rows="2" maxlength="300"><?= Str::e($service['excerpt'] ?? '') ?></textarea></div>
        <div class="form-row"><label>Kategori</label>
          <select name="category_id">
            <option value="0">— tanpa kategori —</option>
            <?php foreach ($categories as $c): ?>
            <option value="<?= (int) $c['id'] ?>" <?= ((int) ($service['category_id'] ?? 0) === (int) $c['id']) ? 'selected' : '' ?>><?= Str::e($c['name']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="form-row"><label>Status</label>
          <select name="status">
            <?php foreach (['draft' => 'Draft', 'review' => 'Perlu review', 'published' => 'Published (gerbang kualitas aktif)'] as $val => $label): ?>
            <option value="<?= Str::e($val) ?>" <?= (($service['status'] ?? 'draft') === $val) ? 'selected' : '' ?>><?= Str::e($label) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="form-row form-inline">
          <label><input type="checkbox" name="featured" value="1" <?= !empty($service['featured']) ? 'checked' : '' ?>> Tandai sebagai layanan unggulan ⭐</label>
        </div>
      </section>

      <section class="admin-card">
        <h2>Fakta Layanan (tampil sebagai kartu di halaman)</h2>
        <div class="form-row"><label>Tarif resmi pemerintah</label>
          <input name="fact_official_fee" type="text" maxlength="200" value="<?= Str::e($facts['official_fee'] ?? '') ?>" placeholder="Contoh: Rp50.000 (PNBP)"></div>
        <div class="form-row"><label>Estimasi biaya jasa</label>
          <input name="fact_service_fee" type="text" maxlength="200" value="<?= Str::e($facts['service_fee'] ?? '') ?>" placeholder="Contoh: Mulai Rp750.000"></div>
        <div class="form-row"><label>Estimasi waktu proses</label>
          <input name="fact_est_time" type="text" maxlength="100" value="<?= Str::e($facts['est_time'] ?? '') ?>" placeholder="Contoh: 1–3 hari kerja"></div>
        <div class="form-row"><label>Cakupan wilayah</label>
          <input name="fact_region" type="text" maxlength="100" value="<?= Str::e($facts['region'] ?? 'Indonesia') ?>" placeholder="Indonesia / Jawa & Bali / kota tertentu"></div>
        <div class="form-row"><label>Syarat/dokumen (satu per baris)</label>
          <textarea name="fact_requirements" rows="4" placeholder="KTP pendiri&#10;NPWP pendiri&#10;..."><?= Str::e(implode("\n", (array) ($facts['requirements'] ?? []))) ?></textarea></div>
        <p class="hint">Isi hanya yang benar-benar diketahui. Jangan mengarang biaya atau waktu — informasi belum pasti lebih baik kosong daripada salah.</p>
      </section>

      <section class="admin-card">
        <h2>Section (Blok) Halaman</h2>
        <div id="blockList" class="block-list"></div>
        <div class="block-adder">
          <label for="addBlockType">Tambah section:</label>
          <select id="addBlockType">
            <option value="">— pilih jenis —</option>
            <?php foreach ($blockDefs as $type => $def): ?>
            <option value="<?= Str::e($type) ?>"><?= Str::e($def['label']) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="button" class="btn btn-primary btn-sm" id="addBlockBtn">+ Tambah</button>
        </div>
      </section>

      <section class="admin-card">
        <h2>SEO</h2>
        <div class="form-row"><label>Meta title</label>
          <input name="seo_title" type="text" maxlength="120" value="<?= Str::e($seo['title'] ?? '') ?>"></div>
        <div class="form-row"><label>Meta description</label>
          <textarea name="seo_description" rows="3" maxlength="320"><?= Str::e($seo['description'] ?? '') ?></textarea></div>
        <div class="form-row"><label>Robots</label>
          <select name="seo_robots">
            <?php foreach (['index, follow' => 'index, follow', 'noindex, follow' => 'noindex, follow', 'noindex, nofollow' => 'noindex, nofollow'] as $val => $label): ?>
            <option value="<?= Str::e($val) ?>" <?= (($seo['robots'] ?? 'index, follow') === $val) ? 'selected' : '' ?>><?= Str::e($label) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="form-row"><label>Sumber resmi</label>
          <textarea name="seo_sources" rows="2" maxlength="500"><?= Str::e($seo['sources'] ?? '') ?></textarea></div>
      </section>

      <div class="editor-actions">
        <button type="submit" class="btn btn-primary btn-lg"><?= $isEdit ? '💾 Simpan Perubahan' : '💾 Buat Layanan' ?></button>
      </div>
    </div>
    <div class="editor-col-right">
      <section class="admin-card preview-card">
        <div class="preview-head">
          <h2>Pratinjau Langsung</h2>
          <div class="viewport-switch" role="group" aria-label="Ukuran pratinjau">
            <button type="button" data-vp="desktop" class="active" aria-pressed="true">🖥</button>
            <button type="button" data-vp="tablet" aria-pressed="false">📱</button>
            <button type="button" data-vp="mobile" aria-pressed="false">📲</button>
          </div>
        </div>
        <div class="preview-frame-wrap" id="previewWrap">
          <?php if ($isEdit): ?>
          <iframe id="previewFrame" src="/admin/layanan/<?= $id ?>/pratinjau" title="Pratinjau layanan" loading="lazy"></iframe>
          <?php else: ?>
          <div class="preview-empty">Simpan dulu untuk melihat pratinjau.</div>
          <?php endif; ?>
        </div>
      </section>
    </div>
  </div>
</form>

<script id="blockDefsJson" type="application/json"><?= json_encode($blockDefs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script id="initialBlocks" type="application/json"><?= json_encode($blocks ?: [], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
