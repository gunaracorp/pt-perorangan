<?php
/**
 * FILE   : app/Views/admin/articles/edit.php — editor artikel (page builder ringan).
 * AMAN?  : PRIVAT.
 */
use App\Core\Csrf;
use App\Core\Str;
$isEdit = $article !== null;
$id = $isEdit ? (int) $article['id'] : 0;
?>
<div class="admin-head">
  <h1><?= $isEdit ? 'Edit Artikel' : 'Artikel Baru' ?></h1>
  <div class="head-actions"><a class="btn btn-ghost" href="/admin/artikel">← Daftar</a></div>
</div>

<form method="post" action="<?= $isEdit ? '/admin/artikel/' . $id . '/simpan' : '/admin/artikel/baru' ?>">
  <?= Csrf::field() ?>
  <input type="hidden" name="blocks" id="blocksInput" value='<?= Str::e(json_encode($blocks ?: [], JSON_UNESCAPED_UNICODE)) ?>'>

  <div class="editor-layout">
    <div class="editor-col-left">
      <section class="admin-card">
        <h2>Informasi Artikel</h2>
        <div class="form-row"><label>Judul <span class="req">*</span></label>
          <input name="title" type="text" required maxlength="150" value="<?= Str::e($article['title'] ?? '') ?>"></div>
        <div class="form-row"><label>Slug (kosong = otomatis)</label>
          <input name="slug" type="text" maxlength="150" value="<?= Str::e($article['slug'] ?? '') ?>"></div>
        <div class="form-row"><label>Ringkasan</label>
          <textarea name="excerpt" rows="2" maxlength="300"><?= Str::e($article['excerpt'] ?? '') ?></textarea></div>
        <div class="form-row"><label>Status</label>
          <select name="status">
            <?php foreach (['draft' => 'Draft', 'review' => 'Perlu review', 'published' => 'Published (gerbang kualitas aktif)'] as $val => $label): ?>
            <option value="<?= Str::e($val) ?>" <?= (($article['status'] ?? 'draft') === $val) ? 'selected' : '' ?>><?= Str::e($label) ?></option>
            <?php endforeach; ?>
          </select></div>
      </section>

      <section class="admin-card">
        <h2>Isi Artikel (Section)</h2>
        <div id="blockList" class="block-list"></div>
        <div class="block-adder">
          <label for="addBlockType">Tambah section:</label>
          <select id="addBlockType">
            <option value="">— pilih jenis —</option>
            <?php foreach ($blockDefs as $type => $def): ?>
            <option value="<?= Str::e($type) ?>"><?= Str::e($def['label']) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="button" class="btn btn-primary btn-sm" id="addBlockBtn">+ Tambah</button>
        </div>
      </section>

      <section class="admin-card">
        <h2>SEO</h2>
        <div class="form-row"><label>Meta title</label>
          <input name="seo_title" type="text" maxlength="120" value="<?= Str::e($seo['title'] ?? '') ?>"></div>
        <div class="form-row"><label>Meta description</label>
          <textarea name="seo_description" rows="3" maxlength="320"><?= Str::e($seo['description'] ?? '') ?></textarea></div>
        <div class="form-row"><label>Sumber resmi</label>
          <textarea name="seo_sources" rows="2" maxlength="500"><?= Str::e($seo['sources'] ?? '') ?></textarea></div>
      </section>

      <div class="editor-actions">
        <button type="submit" class="btn btn-primary btn-lg"><?= $isEdit ? '💾 Simpan Perubahan' : '💾 Buat Artikel' ?></button>
      </div>
    </div>
    <div class="editor-col-right">
      <section class="admin-card preview-card">
        <div class="preview-head"><h2>Pratinjau</h2></div>
        <div class="preview-frame-wrap" id="previewWrap">
          <?php if ($isEdit): ?>
          <iframe id="previewFrame" src="/admin/artikel/<?= $id ?>/pratinjau" title="Pratinjau artikel" loading="lazy"></iframe>
          <?php else: ?>
          <div class="preview-empty">Simpan dulu untuk melihat pratinjau.</div>
          <?php endif; ?>
        </div>
      </section>
    </div>
  </div>
</form>

<script id="blockDefsJson" type="application/json"><?= json_encode($blockDefs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script id="initialBlocks" type="application/json"><?= json_encode($blocks ?: [], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
