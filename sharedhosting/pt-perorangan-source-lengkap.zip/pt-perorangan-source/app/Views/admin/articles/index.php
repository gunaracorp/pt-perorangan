<?php
/**
 * FILE   : app/Views/admin/articles/index.php
 * AMAN?  : PRIVAT.
 */
use App\Core\Str;
?>
<div class="admin-head">
  <h1>Artikel</h1>
  <a class="btn btn-primary" href="/admin/artikel/baru">+ Artikel Baru</a>
</div>

<table class="admin-table">
  <thead><tr><th>Judul</th><th>Slug</th><th>Penulis</th><th>Status</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($articles as $a): ?>
  <tr>
    <td><strong><?= Str::e(Str::excerpt((string) $a['title'], 42)) ?></strong></td>
    <td><code>/artikel/<?= Str::e($a['slug']) ?></code></td>
    <td><?= Str::e($a['author_name'] ?? '—') ?></td>
    <td><span class="status-pill status-<?= Str::e($a['status']) ?>"><?= Str::e($a['status']) ?></span></td>
    <td class="row-actions">
      <a href="/admin/artikel/<?= (int) $a['id'] ?>/edit">Edit</a>
      <a href="/admin/artikel/<?= (int) $a['id'] ?>/pratinjau" target="_blank" rel="noopener">Pratinjau</a>
      <form method="post" action="/admin/artikel/<?= (int) $a['id'] ?>/hapus" data-confirm="Hapus artikel ini?">
        <input type="hidden" name="_csrf" value="<?= \App\Core\Csrf::token() ?>">
        <button type="submit" class="link-danger">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
