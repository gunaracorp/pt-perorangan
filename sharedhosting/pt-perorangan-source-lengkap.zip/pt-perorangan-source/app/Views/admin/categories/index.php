<?php
/**
 * FILE   : app/Views/admin/categories/index.php
 * AMAN?  : PRIVAT.
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Kategori Layanan</h1></div>

<div class="admin-grid-2">
  <section class="admin-card">
    <h2>Tambah Kategori</h2>
    <form method="post" action="/admin/kategori">
      <?= Csrf::field() ?>
      <div class="form-row"><label>Nama kategori <span class="req">*</span></label>
        <input name="name" type="text" required maxlength="100" placeholder="Contoh: Pendirian Badan Usaha"></div>
      <div class="form-row"><label>Deskripsi singkat</label>
        <textarea name="description" rows="2" maxlength="300"></textarea></div>
      <div class="form-row"><label>Urutan</label>
        <input name="sort_order" type="number" value="10" min="0"></div>
      <button class="btn btn-primary" type="submit">Simpan</button>
    </form>
  </section>

  <section class="admin-card">
    <h2>Daftar Kategori</h2>
    <table class="admin-table">
      <thead><tr><th>Nama</th><th>Slug</th><th>URL</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($categories as $c): ?>
      <tr>
        <td><?= Str::e($c['name']) ?></td>
        <td><code><?= Str::e($c['slug']) ?></code></td>
        <td><code>/layanan/kategori/<?= Str::e($c['slug']) ?></code></td>
        <td>
          <form method="post" action="/admin/kategori/<?= (int) $c['id'] ?>/hapus" data-confirm="Hapus kategori?">
            <input type="hidden" name="_csrf" value="<?= Csrf::token() ?>">
            <button type="submit" class="link-danger">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>
</div>
