<?php
/**
 * FILE   : app/Views/admin/layout.php
 * FUNGSI : Layout panel admin (dipakai semua view admin via $content).
 * UNTUK  : Sidebar navigasi, flash message, header user, konten.
 * AMAN?  : PRIVAT.
 * PEMULA : Variabel $content = isi halaman admin yang sedang dibuka.
 */

use App\Core\Str;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Dashboard Admin</title>
<link rel="stylesheet" href="/assets/admin/admin.css">
</head>
<body class="admin-body" data-role="<?= Str::e($auth['role']) ?>">

<?php if (($auth['name'] ?? '') !== ''): ?>
<aside class="admin-sidebar">
  <div class="admin-brand">◆ <?= Str::e($auth['name']) ?> <small>(<?= Str::e($auth['role']) ?>)</small></div>
  <nav class="admin-nav" aria-label="Menu admin">
    <a href="/admin">📊 Dasbor</a>
    <a href="/admin/halaman">📄 Halaman</a>
    <a href="/admin/layanan">🏢 Layanan</a>
    <a href="/admin/kategori">🗂️ Kategori</a>
    <a href="/admin/artikel">📰 Artikel</a>
    <a href="/admin/faq">❓ FAQ</a>
    <a href="/admin/media">🖼️ Media</a>
    <a href="/admin/menu">🧭 Menu</a>
    <a href="/admin/tema">🎨 Tema</a>
    <a href="/admin/seo">🔗 SEO</a>
    <a href="/admin/impor">📥 Impor Massal</a>
    <a href="/admin/pesan">✉️ Pesan</a>
    <a href="/admin/pengaturan">⚙️ Pengaturan</a>
    <?php if ($auth['role'] === 'owner' || $auth['role'] === 'admin'): ?>
    <a href="/admin/pengguna">👥 Pengguna</a>
    <?php endif; ?>
  </nav>
  <div class="admin-sidebar-foot">
    <a href="/" target="_blank" rel="noopener">🌐 Lihat Situs</a>
    <a href="/admin/logout">🚪 Keluar</a>
  </div>
</aside>
<?php endif; ?>

<main class="admin-main">
  <?php foreach (($flashes ?? []) as $flash): ?>
  <div class="admin-flash admin-flash-<?= Str::e($flash['type']) ?>" role="status"><?= Str::e($flash['message']) ?></div>
  <?php endforeach; ?>

  <?= $content ?>
</main>

<script src="/assets/admin/admin.js" defer></script>
</body>
</html>
