<?php
/**
 * FILE   : app/Views/admin/media/index.php
 * AMAN?  : PRIVAT. Upload tervalidasi server (MIME nyata, ekstensi whitelist, ukuran).
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Media Library</h1></div>

<div class="admin-grid-2">
  <section class="admin-card">
    <h2>Unggah Media</h2>
    <form method="post" action="/admin/media" enctype="multipart/form-data">
      <?= Csrf::field() ?>
      <div class="form-row"><label>File (jpg, png, webp, gif, svg, pdf — maks <?= (int) app_config('uploads.max_size_mb', 8) ?> MB)</label>
        <input type="file" name="file" accept=".jpg,.jpeg,.png,.webp,.gif,.svg,.pdf" required></div>
      <div class="form-row"><label>Alt text (deskripsi gambar — penting untuk SEO &amp; aksesibilitas)</label>
        <input type="text" name="alt" maxlength="200" placeholder="Contoh: Logo PT Perorangan berwarna putih"></div>
      <div class="form-row"><label>Kredit / sumber (opsional)</label>
        <input type="text" name="credit" maxlength="200"></div>
      <button class="btn btn-primary" type="submit">Unggah</button>
    </form>
    <form method="get" action="/admin/media" class="search-inline">
      <input type="search" name="q" value="<?= Str::e($q) ?>" placeholder="Cari media…" maxlength="60">
      <button class="btn btn-ghost btn-sm" type="submit">Cari</button>
    </form>
  </section>

  <section class="admin-card">
    <h2>Galeri (<?= count($mediaList) ?>)</h2>
    <?php if (empty($mediaList)): ?>
    <p>Belum ada media. Unggah gambar pertama Anda.</p>
    <?php else: ?>
    <div class="media-grid">
      <?php foreach ($mediaList as $m): ?>
      <div class="media-item">
        <?php if (str_starts_with((string) $m['mime'], 'image/')): ?>
        <img src="/media/<?= Str::e($m['filename']) ?>" alt="<?= Str::e($m['alt'] ?? '') ?>" loading="lazy">
        <?php else: ?>
        <span class="media-file-icon">📄</span>
        <?php endif; ?>
        <code>/media/<?= Str::e($m['filename']) ?></code>
        <form method="post" action="/admin/media/<?= (int) $m['id'] ?>/simpan" class="media-meta-form">
          <?= Csrf::field() ?>
          <input type="text" name="alt" value="<?= Str::e($m['alt'] ?? '') ?>" placeholder="Alt text" maxlength="200" aria-label="Alt text">
          <input type="text" name="credit" value="<?= Str::e($m['credit'] ?? '') ?>" placeholder="Kredit" maxlength="200" aria-label="Kredit">
          <button type="submit" class="btn btn-ghost btn-sm">Simpan</button>
        </form>
        <form method="post" action="/admin/media/<?= (int) $m['id'] ?>/hapus" data-confirm="Hapus file ini dari server?">
          <?= Csrf::field() ?>
          <button type="submit" class="link-danger btn-sm">Hapus</button>
        </form>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </section>
</div>
