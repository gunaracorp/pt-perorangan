<?php
/**
 * FILE   : app/Views/admin/menus/index.php
 * AMAN?  : PRIVAT.
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Menu Navigasi</h1></div>

<form method="post" action="/admin/menu">
  <?= Csrf::field() ?>
  <div class="admin-grid-2">
    <?php foreach (['header' => 'Menu Header (atas)', 'footer' => 'Menu Footer (bawah)'] as $loc => $label): ?>
    <section class="admin-card" data-menu="<?= Str::e($loc) ?>">
      <h2><?= Str::e($label) ?></h2>
      <p class="hint">Baris 1 sudah terisi; gunakan tombol "+ Baris" untuk menambah tautan.</p>
      <div class="menu-rows">
        <?php $items = ($loc === 'header') ? $header : $footer; ?>
        <?php foreach ($items as $item): ?>
        <div class="menu-row">
          <input type="text" name="<?= Str::e($loc) ?>_label[]" value="<?= Str::e($item['label']) ?>" placeholder="Label" maxlength="60" aria-label="Label tautan">
          <input type="text" name="<?= Str::e($loc) ?>_url[]" value="<?= Str::e($item['url']) ?>" placeholder="/layanan atau https://..." maxlength="300" aria-label="URL tautan">
          <button type="button" class="btn btn-ghost btn-sm remove-row" aria-label="Hapus baris">✕</button>
        </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="btn btn-ghost btn-sm add-menu-row" data-target="<?= Str::e($loc) ?>">+ Baris</button>
    </section>
    <?php endforeach; ?>
  </div>
  <button class="btn btn-primary btn-lg" type="submit">💾 Simpan Semua Menu</button>
</form>
