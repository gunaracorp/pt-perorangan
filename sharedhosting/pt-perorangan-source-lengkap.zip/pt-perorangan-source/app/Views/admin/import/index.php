<?php
/**
 * FILE   : app/Views/admin/import/index.php
 * AMAN?  : PRIVAT. Semua hasil impor = DRAFT (direview sebelum terbit).
 */
use App\Core\Csrf;
use App\Core\Str;
?>
<div class="admin-head"><h1>Impor Massal Layanan</h1></div>

<div class="admin-grid-2">
  <section class="admin-card">
    <h2>Sumber Data</h2>
    <form method="post" action="/admin/impor" enctype="multipart/form-data">
      <?= Csrf::field() ?>
      <div class="form-row"><label>Unggah file CSV / JSON (maks 2 MB)</label>
        <input type="file" name="file" accept=".csv,.json"></div>
      <div class="form-row"><label>atau tempel langsung</label>
        <textarea name="content" rows="10" placeholder='title,slug,excerpt,body,official_fee,service_fee,est_time
"Pendirian PT Perorangan","pendirian-pt-perorangan","Ringkasan...","Isi panjang minimal 200 karakter...","Rp50.000","Mulai Rp750.000","1-3 hari kerja"'></textarea></div>
      <button class="btn btn-primary" type="submit">🚀 Proses Impor</button>
    </form>

    <h3 style="margin-top:28px">Format CSV (header wajib)</h3>
    <pre class="code-sample">title,slug,excerpt,body,official_fee,service_fee,est_time</pre>
    <ul class="hint-list">
      <li><strong>title</strong> wajib</li>
      <li><strong>body</strong> minimal 200 karakter (anti thin content)</li>
      <li>Kolom lain opsional</li>
      <li>Hasil impor selalu <strong>draft</strong> — review dulu lalu terbitkan satu per satu</li>
    </ul>
  </section>

  <section class="admin-card">
    <h2>Laporan Impor</h2>
    <?php if ($report === null): ?>
    <p>Belum ada impor yang dijalankan pada sesi ini.</p>
    <?php else: ?>
    <p><strong><?= (int) $report['ok'] ?></strong> baris berhasil → draft dibuat. <strong class="link-danger"><?= (int) $report['fail'] ?></strong> baris gagal validasi.</p>
    <table class="admin-table">
      <thead><tr><th>Baris</th><th>Hasil</th></tr></thead>
      <tbody>
      <?php foreach ($report['report'] as $row): ?>
      <tr>
        <td>#<?= (int) $row['row'] ?></td>
        <td class="<?= $row['ok'] ? 'import-ok' : 'import-fail' ?>"><?= $row['ok'] ? '✓' : '✕' ?> <?= Str::e($row['msg']) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <p class="hint">Cek hasilnya di menu <a href="/admin/layanan">Layanan</a> (status draft).</p>
    <?php endif; ?>
  </section>
</div>
