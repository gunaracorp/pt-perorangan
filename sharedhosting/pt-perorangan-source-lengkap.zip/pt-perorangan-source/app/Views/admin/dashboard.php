<?php
/**
 * FILE   : app/Views/admin/dashboard.php
 * FUNGSI : Dasbor: statistik konten + daftar terbaru + petunjuk pemula.
 * AMAN?  : PRIVAT.
 */

use App\Core\Str;
?>
<h1>Dasbor</h1>
<p class="admin-sub">Selamat datang, <?= Str::e($auth['name']) ?>. Berikut ringkasan situs Anda.</p>

<div class="stat-cards">
  <div class="stat-box"><strong><?= (int) $stats['published_services'] ?></strong><span>Layanan terbit / <?= (int) $stats['services'] ?></span></div>
  <div class="stat-box"><strong><?= (int) $stats['published_pages'] ?></strong><span>Halaman terbit / <?= (int) $stats['pages'] ?></span></div>
  <div class="stat-box"><strong><?= (int) $stats['articles'] ?></strong><span>Artikel</span></div>
  <div class="stat-box"><strong><?= (int) $stats['drafts'] ?></strong><span>Draft / review</span></div>
  <div class="stat-box"><strong><?= (int) $stats['messages'] ?></strong><span>Pesan baru</span></div>
</div>

<div class="admin-grid-2">
  <section class="admin-card">
    <h2>Konten Terakhir Diubah</h2>
    <table class="admin-table">
      <thead><tr><th>Jenis</th><th>Judul</th><th>Status</th><th>Diubah</th></tr></thead>
      <tbody>
      <?php foreach ($recent as $row): ?>
        <tr>
          <td><?= Str::e($row['jenis']) ?></td>
          <td><?= Str::e(Str::excerpt((string) $row['title'], 40)) ?></td>
          <td><span class="status-pill status-<?= Str::e($row['status']) ?>"><?= Str::e($row['status']) ?></span></td>
          <td><?= Str::e(Str::tanggalIndo($row['updated_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>

  <section class="admin-card">
    <h2>Mulai Dari Sini (Pemula)</h2>
    <ol class="starter-list">
      <li><strong>Isi identitas situs</strong> di <a href="/admin/pengaturan">Pengaturan</a> — nama, WhatsApp, email.</li>
      <li><strong>Sesuaikan tampilan</strong> di <a href="/admin/tema">Tema</a> — warna, font, gaya header.</li>
      <li><strong>Sunting beranda</strong> di <a href="/admin/halaman">Halaman</a> → "Beranda" (editor visual).</li>
      <li><strong>Tambah layanan</strong> di <a href="/admin/layanan">Layanan</a> — atau <a href="/admin/impor">impor massal CSV</a>.</li>
      <li><strong>Uji situs</strong> → klik "Lihat Situs" di kiri bawah, lalu periksa sitemap <code>/sitemap.xml</code>.</li>
    </ol>
  </section>
</div>
