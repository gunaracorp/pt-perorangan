<?php
/**
 * FILE   : app/Views/admin/pages/index.php
 * FUNGSI : Daftar halaman dengan status, pratinjau, edit, hapus, revisi.
 * AMAN?  : PRIVAT. Hapus memakai POST + CSRF + konfirmasi JS.
 */

use App\Core\Str;
?>
<div class="admin-head">
  <h1>Halaman</h1>
  <a class="btn btn-primary" href="/admin/halaman/baru">+ Halaman Baru</a>
</div>

<table class="admin-table">
  <thead><tr><th>Judul</th><th>Slug</th><th>Status</th><th>Diubah</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($pages as $p): ?>
  <tr>
    <td><strong><?= Str::e(Str::excerpt((string) $p['title'], 42)) ?></strong></td>
    <td><code>/p/<?= Str::e($p['slug']) ?></code><?= $p['slug'] === 'beranda' ? ' (beranda: /)' : '' ?></td>
    <td><span class="status-pill status-<?= Str::e($p['status']) ?>"><?= Str::e($p['status']) ?></span></td>
    <td><?= Str::e(Str::tanggalIndo($p['updated_at'])) ?></td>
    <td class="row-actions">
      <a href="/admin/halaman/<?= (int) $p['id'] ?>/edit">Edit</a>
      <a href="/admin/halaman/<?= (int) $p['id'] ?>/pratinjau" target="_blank" rel="noopener">Pratinjau</a>
      <a href="/admin/halaman/<?= (int) $p['id'] ?>/revisi">Revisi</a>
      <form method="post" action="/admin/halaman/<?= (int) $p['id'] ?>/hapus" data-confirm="Hapus halaman ini secara permanen?">
        <input type="hidden" name="_csrf" value="<?= \App\Core\Csrf::token() ?>">
        <button type="submit" class="link-danger">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
