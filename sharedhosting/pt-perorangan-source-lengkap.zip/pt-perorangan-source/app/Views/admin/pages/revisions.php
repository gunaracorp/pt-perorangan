<?php
/**
 * FILE   : app/Views/admin/pages/revisions.php
 * FUNGSI : Riwayat revisi halaman + tombol pulihkan.
 * AMAN?  : PRIVAT. Restore = POST + CSRF (snapshot otomatis sebelum restore).
 */

use App\Core\Str;
?>
<div class="admin-head">
  <h1>Riwayat Revisi — <?= Str::e(Str::excerpt((string) $page['title'], 40)) ?></h1>
  <a class="btn btn-ghost" href="/admin/halaman/<?= (int) $page['id'] ?>/edit">← Kembali ke editor</a>
</div>

<?php if (empty($revisions)): ?>
<p>Belum ada revisi. Setiap penyimpanan membuat satu catatan revisi (maks 20 terakhir).</p>
<?php else: ?>
<table class="admin-table">
  <thead><tr><th>Waktu</th><th>Oleh</th><th>Catatan</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($revisions as $rev): ?>
  <tr>
    <td><?= Str::e(date('d M Y H:i', strtotime((string) $rev['created_at']))) ?></td>
    <td><?= Str::e($rev['author'] ?? '—') ?></td>
    <td><?= Str::e($rev['note'] ?? '') ?></td>
    <td>
      <form method="post" action="/admin/halaman/<?= (int) $page['id'] ?>/revisi/<?= (int) $rev['id'] ?>/pulihkan" data-confirm="Pulihkan kondisi halaman seperti pada revisi ini?">
        <input type="hidden" name="_csrf" value="<?= \App\Core\Csrf::token() ?>">
        <button type="submit" class="btn btn-ghost btn-sm">↩️ Pulihkan</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php endif; ?>
