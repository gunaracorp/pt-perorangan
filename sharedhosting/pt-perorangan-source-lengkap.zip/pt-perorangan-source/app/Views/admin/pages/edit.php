<?php
/**
 * FILE   : app/Views/admin/pages/edit.php
 * FUNGSI : EDITOR VISUAL halaman (page builder): susun blok, atur field tiap blok,
 *          pratinjau live (desktop/tablet/mobile), autosave, SEO, status publish.
 * UNTUK  : Dipakai create() & update(). Data dikirim sebagai JSON ke endpoint simpan.
 * KENAPA : Inilah "editor visual front-end" yang diminta: admin memilih blok,
 *          mengubah isinya, melihat pratinjau, menyimpan draft, lalu publish.
 * AMAN?  : PRIVAT. Server tetap menyaring SEMUA input (BlockSchema) — UI bukan keamanan.
 * PEMULA : - "Blok" = satu section halaman (hero, fitur, FAQ...).
 *          - Tombol "Simpan" = draft/perubahan; "Terbitkan" = cek kualitas lalu tayang.
 *          - Autosave otomatis menyimpan salinan revisi tiap 60 detik.
 */

use App\Core\Csrf;
use App\Core\Str;

$isEdit = $page !== null;
$pageId = $isEdit ? (int) $page['id'] : 0;
?>
<div class="admin-head">
  <h1><?= $isEdit ? 'Edit Halaman' : 'Halaman Baru' ?></h1>
  <div class="head-actions">
    <?php if ($isEdit): ?>
    <a class="btn btn-ghost" href="/admin/halaman/<?= $pageId ?>/pratinjau" target="_blank" rel="noopener">👁 Pratinjau Tab Baru</a>
    <?php endif; ?>
    <a class="btn btn-ghost" href="/admin/halaman">← Daftar</a>
  </div>
</div>

<?php if ($isEdit && !empty($quality)): ?>
<div class="quality-panel admin-card <?= $quality['pass'] ? 'qg-pass' : 'qg-fail' ?>">
  <strong><?= $quality['pass'] ? '✓ Siap terbitkan' : '✕ Belum siap terbitkan' ?></strong>
  <span>Skor kualitas: <?= (int) $quality['score'] ?>/100</span>
  <ul>
    <?php foreach ($quality['issues'] as $issue): ?><li><?= Str::e($issue) ?></li><?php endforeach; ?>
    <?php foreach ($quality['warnings'] as $warn): ?><li>⚠️ <?= Str::e($warn) ?></li><?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<form id="editorForm" method="post" action="<?= $isEdit ? '/admin/halaman/' . $pageId . '/simpan' : '/admin/halaman/baru' ?>">
  <?= Csrf::field() ?>
  <input type="hidden" name="blocks" id="blocksInput" value='<?= Str::e(json_encode($blocks ?: [], JSON_UNESCAPED_UNICODE)) ?>'>

  <div class="editor-layout">
    <!-- ============ KOLOM KIRI: METADATA + DAFTAR BLOK ============ -->
    <div class="editor-col-left">
      <section class="admin-card">
        <h2>Informasi Halaman</h2>
        <div class="form-row">
          <label for="title">Judul halaman <span class="req">*</span></label>
          <input id="title" name="title" type="text" required maxlength="150"
                 value="<?= Str::e($page['title'] ?? '') ?>" placeholder="Contoh: Panduan Pendirian PT Perorangan 2026">
        </div>
        <div class="form-row">
          <label for="slug">Slug URL (biarkan kosong = otomatis dari judul)</label>
          <input id="slug" name="slug" type="text" maxlength="150"
                 value="<?= Str::e($page['slug'] ?? '') ?>" placeholder="panduan-pendirian-pt-perorangan">
          <?php if ($isEdit): ?><p class="hint">URL sekarang: <code><?= $page['slug'] === 'beranda' ? '/' : '/p/' . Str::e($page['slug']) ?></code></p><?php endif; ?>
        </div>
        <div class="form-row">
          <label for="excerpt">Ringkasan singkat (dipakai daftar &amp; preview)</label>
          <textarea id="excerpt" name="excerpt" rows="2" maxlength="300"><?= Str::e($page['excerpt'] ?? '') ?></textarea>
        </div>
        <div class="form-row">
          <label for="status">Status publikasi</label>
          <select id="status" name="status">
            <?php foreach (['draft' => 'Draft (belum tayang)', 'review' => 'Perlu review', 'published' => 'Published (tayang)', 'scheduled' => 'Terjadwal', 'needs_update' => 'Perlu pembaruan'] as $val => $label): ?>
            <option value="<?= Str::e($val) ?>" <?= (($page['status'] ?? 'draft') === $val) ? 'selected' : '' ?>><?= Str::e($label) ?></option>
            <?php endforeach; ?>
          </select>
          <p class="hint">Memilih "Published" akan menjalankan <strong>gerbang kualitas</strong>: halaman tipis tidak boleh terbit.</p>
        </div>
      </section>

      <section class="admin-card">
        <h2>Section (Blok) Halaman</h2>
        <p class="hint">Susun isi halaman dari bawah ke atas. Klik blok untuk mengatur isinya. Urutan dapat digeser dengan tombol ↑ ↓.</p>
        <div id="blockList" class="block-list"></div>

        <div class="block-adder">
          <label for="addBlockType">Tambah section baru:</label>
          <select id="addBlockType">
            <option value="">— pilih jenis —</option>
            <?php foreach ($blockDefs as $type => $def): ?>
            <option value="<?= Str::e($type) ?>"><?= Str::e($def['label']) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="button" class="btn btn-primary btn-sm" id="addBlockBtn">+ Tambah</button>
        </div>
      </section>

      <section class="admin-card">
        <h2>SEO</h2>
        <div class="form-row">
          <label for="seo_title">Meta title</label>
          <input id="seo_title" name="seo_title" type="text" maxlength="120" value="<?= Str::e($seo['title'] ?? '') ?>">
          <p class="hint">Idealnya 40–60 karakter. Contoh: "Pendirian PT Perorangan: Syarat &amp; Proses 2026".</p>
        </div>
        <div class="form-row">
          <label for="seo_description">Meta description</label>
          <textarea id="seo_description" name="seo_description" rows="3" maxlength="320"><?= Str::e($seo['description'] ?? '') ?></textarea>
          <p class="hint">120–156 karakter. Wajib — dipakai di hasil pencarian Google.</p>
        </div>
        <div class="form-row">
          <label for="seo_robots">Robots</label>
          <select id="seo_robots" name="seo_robots">
            <?php foreach (['index, follow' => 'index, follow (normal)', 'noindex, follow' => 'noindex, follow (sembunyikan dari pencarian)', 'noindex, nofollow' => 'noindex, nofollow (sembunyikan total)'] as $val => $label): ?>
            <option value="<?= Str::e($val) ?>" <?= (($seo['robots'] ?? 'index, follow') === $val) ? 'selected' : '' ?>><?= Str::e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <label for="seo_sources">Sumber resmi (wajib bila menyebut regulasi/biaya resmi)</label>
          <textarea id="seo_sources" name="seo_sources" rows="2" maxlength="500" placeholder="Contoh: PP 8/2021, layanan.ahu.go.id"><?= Str::e($seo['sources'] ?? '') ?></textarea>
        </div>
      </section>

      <div class="editor-actions">
        <button type="submit" class="btn btn-primary btn-lg"><?= $isEdit ? '💾 Simpan Perubahan' : '💾 Buat Halaman' ?></button>
      </div>
    </div>

    <!-- ============ KOLOM KANAN: PRATINJAU LIVE ============ -->
    <div class="editor-col-right">
      <section class="admin-card preview-card">
        <div class="preview-head">
          <h2>Pratinjau Langsung</h2>
          <div class="viewport-switch" role="group" aria-label="Ukuran pratinjau">
            <button type="button" data-vp="desktop" class="active" aria-pressed="true">🖥</button>
            <button type="button" data-vp="tablet" aria-pressed="false">📱</button>
            <button type="button" data-vp="mobile" aria-pressed="false">📲</button>
          </div>
        </div>
        <div class="preview-frame-wrap" id="previewWrap">
          <?php if ($isEdit): ?>
          <iframe id="previewFrame" src="/admin/halaman/<?= $pageId ?>/pratinjau" title="Pratinjau halaman" loading="lazy"></iframe>
          <?php else: ?>
          <div class="preview-empty">Simpan halaman dulu untuk melihat pratinjau.</div>
          <?php endif; ?>
        </div>
        <p class="hint" id="autosaveStatus"><?= $isEdit ? 'Autosave aktif: salinan revisi otomatis tiap 60 detik setelah Anda mengubah blok.' : '' ?></p>
      </section>
    </div>
  </div>
</form>

<script id="blockDefsJson" type="application/json"><?= json_encode($blockDefs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script id="initialBlocks" type="application/json"><?= json_encode($blocks ?: [], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
