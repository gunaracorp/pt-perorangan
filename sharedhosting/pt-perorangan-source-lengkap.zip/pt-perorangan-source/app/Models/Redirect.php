<?php
/**
 * FILE   : app/Models/Redirect.php
 * FUNGSI : Pengelolaan redirect 301/302/410 (URL lama → baru).
 * UNTUK  : Dipanggil App::run() sebelum routing; panel /admin/seo.
 * KENAPA : Saat URL berubah (migrasi/renaming), 301 menjaga nilai SEO tanpa 404.
 * TERKAIT: app/Core/App.php, admin/SeoController
 * AMAN?  : PRIVAT.
 * PEMULA : 301 = pindah permanen; 410 = konten dihapus permanen (dihormati mesin cari).
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Redirect extends BaseModel
{
    protected static string $table = 'redirects';

    /** Cari redirect untuk path. Hasil di-cache agar cepat. */
    public static function match(string $path): ?array
    {
        $map = Cache::remember('redirect_map', 300, static function () {
            $rows = Database::all('SELECT id, from_path, target, status FROM redirects');
            $map = [];
            foreach ($rows as $r) {
                $map[$r['from_path']] = ['id' => (int) $r['id'], 'target' => $r['target'], 'status' => (int) $r['status']];
            }
            return $map;
        });
        if (isset($map[$path])) {
            $entry = $map[$path];
            return ['id' => $entry['id'], 'target' => $entry['target'], 'status' => $entry['status']];
        }
        return null;
    }

    public static function hit(int $id): void
    {
        Database::run('UPDATE redirects SET hits = hits + 1 WHERE id = ?', [$id]);
    }

    /** Tambah/update redirect dengan validasi loop sederhana. */
    public static function upsert(string $from, string $target, int $status): array
    {
        $from = '/' . ltrim(trim($from), '/');
        $target = trim($target);
        $errors = [];
        if ($from === '/' || mb_strlen($from) < 2) {
            $errors[] = 'Path sumber tidak boleh berupa akar situs.';
        }
        if ($status !== 410 && $target === '') {
            $errors[] = 'Tujuan wajib diisi untuk redirect 301/302.';
        }
        if ($status !== 410 && $from === $target) {
            $errors[] = 'Redirect ke dirinya sendiri akan membuat loop.';
        }
        if ($errors !== []) {
            return [false, implode(' ', $errors)];
        }
        $existing = Database::one('SELECT id FROM redirects WHERE from_path = ?', [$from]);
        $now = date('Y-m-d H:i:s');
        if ($existing) {
            self::updateById((int) $existing['id'], ['target' => $target, 'status' => $status, 'updated_at' => $now]);
        } else {
            self::insert(['from_path' => $from, 'target' => $target, 'status' => $status, 'hits' => 0, 'created_at' => $now]);
        }
        Cache::forget('redirect_map');
        return [true, 'Redirect tersimpan.'];
    }
}
