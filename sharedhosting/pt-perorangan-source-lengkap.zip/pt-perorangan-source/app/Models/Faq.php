<?php
/**
 * FILE   : app/Models/Faq.php
 * FUNGSI : Bank FAQ (dipakai halaman FAQ + blok FAQ pada layanan + JSON-LD FAQPage).
 * UNTUK  : /faq, editor FAQ admin, dan blok faq di page builder.
 * KENAPA : FAQ berbasis pertanyaan nyata menangkap intent tanya langsung di SERP.
 * TERKAIT: admin/FaqController, tema blocks/faq.php
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Faq extends BaseModel
{
    protected static string $table = 'faqs';

    public static function published(?int $serviceId = null, int $limit = 0): array
    {
        if ($serviceId !== null) {
            $sql = "SELECT * FROM faqs WHERE status = 'published' AND (service_id = ? OR service_id IS NULL)
                    ORDER BY sort_order ASC, id ASC" . ($limit > 0 ? ' LIMIT ' . (int) $limit : '');
            return Database::all($sql, [$serviceId]);
        }
        $sql = "SELECT * FROM faqs WHERE status = 'published' ORDER BY sort_order ASC, id ASC" . ($limit > 0 ? ' LIMIT ' . (int) $limit : '');
        return Database::all($sql);
    }
}
