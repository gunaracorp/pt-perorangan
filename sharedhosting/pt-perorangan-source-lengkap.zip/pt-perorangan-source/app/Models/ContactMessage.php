<?php
/**
 * FILE   : app/Models/ContactMessage.php
 * FUNGSI : Pesan dari formulir kontak (disimpan ke database, tanpa server email).
 * UNTUK  : /kontak (POST) dan kotak masuk /admin/pesan.
 * KENAPA : Shared hosting sering membatasi mail(); menyimpan pesan ke DB lebih andal
 *          dan tetap bisa dibaca admin dari dashboard.
 * TERKAIT: public ContactController, admin MessagesController
 * AMAN?  : PRIVAT. IP disimpan sebagai hash (privasi, sesuai kebijakan data pribadi).
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Auth;

final class ContactMessage extends BaseModel
{
    protected static string $table = 'contact_messages';

    public static function create(string $name, string $email, string $phone, string $subject, string $message): int
    {
        return self::insert([
            'name'       => $name,
            'email'      => mb_strtolower($email),
            'phone'      => $phone,
            'subject'    => $subject,
            'message'    => $message,
            'status'     => 'new',
            'ip_hash'    => Auth::ipHash(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
