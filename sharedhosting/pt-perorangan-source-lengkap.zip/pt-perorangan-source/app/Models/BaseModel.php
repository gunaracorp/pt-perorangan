<?php
/**
 * FILE   : app/Models/BaseModel.php
 * FUNGSI : Fondasi CRUD untuk semua model (find, all, insert, update, delete, paginate).
 * UNTUK  : Dipewarisi Page, Service, Article, dll.
 * KENAPA : Satu implementasi query yang benar (prepared statement) dipakai ulang
 *          mengurangi risiko salah tulis SQL di banyak tempat.
 * TERKAIT: app/Core/Database.php
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

abstract class BaseModel
{
    /** Nama tabel di database (didefinisikan tiap model). */
    protected static string $table = '';

    public static function find(int $id): ?array
    {
        return Database::one('SELECT * FROM ' . static::$table . ' WHERE id = ?', [$id]);
    }

    public static function findBySlug(string $slug): ?array
    {
        return Database::one('SELECT * FROM ' . static::$table . ' WHERE slug = ?', [$slug]);
    }

    public static function all(string $orderBy = 'id DESC', int $limit = 0): array
    {
        $sql = 'SELECT * FROM ' . static::$table . ' ORDER BY ' . $orderBy
            . ($limit > 0 ? ' LIMIT ' . (int) $limit : '');
        return Database::all($sql);
    }

    /** @param array<string,mixed> $data */
    public static function insert(array $data): int
    {
        $cols = array_keys($data);
        $ph = implode(',', array_fill(0, count($cols), '?'));
        $sql = 'INSERT INTO ' . static::$table . ' (' . implode(',', $cols) . ') VALUES (' . $ph . ')';
        Database::run($sql, array_values($data));
        return Database::lastId();
    }

    /** @param array<string,mixed> $data */
    public static function updateById(int $id, array $data): void
    {
        $cols = array_keys($data);
        $set = implode(',', array_map(static fn($c) => "$c = ?", $cols));
        Database::run('UPDATE ' . static::$table . " SET $set WHERE id = ?", [...array_values($data), $id]);
    }

    public static function deleteById(int $id): void
    {
        Database::run('DELETE FROM ' . static::$table . ' WHERE id = ?', [$id]);
    }

    /** Hitung total baris (opsional filter where sederhana "kolom = ?"). */
    public static function count(string $where = '', array $params = []): int
    {
        $sql = 'SELECT COUNT(*) FROM ' . static::$table . ($where !== '' ? ' WHERE ' . $where : '');
        return (int) Database::value($sql, $params);
    }
}
