<?php
/**
 * FILE   : app/Models/User.php
 * FUNGSI : Akun admin (owner/admin/editor/reviewer).
 * UNTUK  : Login, manajemen pengguna di /admin/pengguna.
 * KENAPA : Password selalu lewat password_hash()/password_verify(); tidak ada plaintext.
 * TERKAIT: app/Core/Auth.php, database/schema.mysql.sql
 * AMAN?  : PRIVAT.
 * PEMULA : Buat pengguna baru dari dashboard — jangan edit tabel database manual.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class User extends BaseModel
{
    protected static string $table = 'users';

    public static function findByEmail(string $email): ?array
    {
        return Database::one('SELECT * FROM users WHERE email = ?', [mb_strtolower(trim($email))]);
    }

    /** Buat pengguna baru. Role di-validasi whitelist. */
    public static function create(string $name, string $email, string $password, string $role = 'editor'): int
    {
        $roles = ['owner', 'admin', 'editor', 'reviewer'];
        if (!in_array($role, $roles, true)) {
            $role = 'editor';
        }
        return self::insert([
            'name'          => trim($name),
            'email'         => mb_strtolower(trim($email)),
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'role'          => $role,
            'created_at'    => date('Y-m-d H:i:s'),
        ]);
    }

    /** Ganti password (hash ulang). */
    public static function changePassword(int $id, string $newPassword): void
    {
        self::updateById($id, ['password_hash' => password_hash($newPassword, PASSWORD_DEFAULT)]);
    }

    public static function touchLogin(int $id): void
    {
        self::updateById($id, ['last_login_at' => date('Y-m-d H:i:s')]);
    }
}
