<?php
/**
 * FILE   : app/Models/Revision.php
 * FUNGSI : Riwayat revisi konten (snapshot penuh sebelum setiap penyimpanan).
 * UNTUK  : Undo/restore di admin; memenuhi kebutuhan draft → review → publish → rollback.
 * KENAPA : Kesalahan edit harus bisa dipulihkan tanpa backup database manual.
 * TERKAIT: Page/Service/Article::saveWithRevision(), admin RevisionsController
 * AMAN?  : PRIVAT. Snapshot bisa besar — batasi 20 revisi terakhir per entitas.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class Revision extends BaseModel
{
    protected static string $table = 'revisions';

    /** Simpan salinan lengkap sebelum perubahan. */
    public static function snapshot(string $entityType, int $entityId, array $old, int $userId, ?string $note = null): void
    {
        self::insert([
            'entity_type' => $entityType,
            'entity_id'   => $entityId,
            'snapshot'    => json_encode($old, JSON_UNESCAPED_UNICODE),
            'note'        => $note,
            'created_by'  => $userId,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        // Pruning: simpan 20 revisi terakhir per entitas.
        Database::run(
            'DELETE FROM revisions WHERE entity_type = ? AND entity_id = ? AND id NOT IN (
                SELECT id FROM (SELECT id FROM revisions WHERE entity_type = ? AND entity_id = ? ORDER BY id DESC LIMIT 20) keep
            )',
            [$entityType, $entityId, $entityType, $entityId]
        );
    }

    /** Daftar revisi terbaru untuk satu entitas. */
    public static function forEntity(string $entityType, int $entityId, int $limit = 20): array
    {
        $rows = Database::all(
            'SELECT r.*, u.name AS author FROM revisions r LEFT JOIN users u ON u.id = r.created_by
             WHERE r.entity_type = ? AND r.entity_id = ? ORDER BY r.id DESC LIMIT ' . (int) $limit,
            [$entityType, $entityId]
        );
        foreach ($rows as &$row) {
            $row['snapshot_arr'] = json_decode((string) $row['snapshot'], true) ?: [];
        }
        return $rows;
    }

    /** Pulihkan satu revisi (mengembalikan snapshot menjadi data aktif). */
    public static function restore(int $revisionId, int $userId): bool
    {
        $rev = self::find($revisionId);
        if (!$rev) {
            return false;
        }
        $snap = json_decode((string) $rev['snapshot'], true);
        if (!is_array($snap)) {
            return false;
        }
        $type = (string) $rev['entity_type'];
        $id = (int) $rev['entity_id'];
        // Snapshot dulu kondisi saat ini, agar restore juga bisa di-undo.
        $model = match ($type) {
            'page'    => Page::class,
            'service' => Service::class,
            'article' => Article::class,
            default   => null,
        };
        if ($model === null) {
            return false;
        }
        $current = $model::find($id);
        if ($current) {
            self::snapshot($type, $id, $current, $userId, 'Sebelum restore revisi #' . $revisionId);
        }
        $current === null ? null : $model::updateById($id, $snap);
        \App\Core\Cache::flush();
        return true;
    }
}
