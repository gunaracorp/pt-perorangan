<?php
/**
 * FILE   : app/Models/Service.php
 * FUNGSI : Layanan (pendirian PT, NIB, KBLI, konsultasi pajak, dsb) — inti SEO skala besar.
 * UNTUK  : Route /layanan dan /layanan/{slug}, hub kategori, editor visual admin.
 * KENAPA : Tiap layanan punya blok konten + fakta terstruktur (biaya resmi vs jasa,
 *          estimasi waktu, syarat) sehingga halaman berkualitas, bukan template tipis.
 * TERKAIT: app/Models/Category.php, admin/ServicesController, config/blocks.php
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Service extends BaseModel
{
    protected static string $table = 'services';

    public static function findPublished(string $slug): ?array
    {
        return Database::one("SELECT * FROM services WHERE slug = ? AND status = 'published' LIMIT 1", [$slug]);
    }

    public static function published(int $limit = 0, int $categoryId = 0): array
    {
        $sql = "SELECT * FROM services WHERE status = 'published'";
        $params = [];
        if ($categoryId > 0) {
            $sql .= ' AND category_id = ?';
            $params[] = $categoryId;
        }
        $sql .= ' ORDER BY featured DESC, sort_order ASC, id ASC' . ($limit > 0 ? ' LIMIT ' . (int) $limit : '');
        return Database::all($sql, $params);
    }

    public static function blocksOf(array $service): array
    {
        $blocks = json_decode((string) ($service['blocks'] ?? '[]'), true);
        return is_array($blocks) ? $blocks : [];
    }

    public static function seoOf(array $service): array
    {
        $seo = json_decode((string) ($service['seo'] ?? '{}'), true);
        return is_array($seo) ? $seo : [];
    }

    /** Fakta terstruktur layanan (dipakai tema + JSON-LD Service). */
    public static function factsOf(array $service): array
    {
        $facts = json_decode((string) ($service['facts'] ?? '{}'), true);
        return is_array($facts) ? array_merge([
            'official_fee'  => '',
            'service_fee'   => '',
            'est_time'      => '',
            'requirements'  => [],
            'region'        => 'Indonesia',
        ], $facts) : [
            'official_fee' => '', 'service_fee' => '', 'est_time' => '', 'requirements' => [], 'region' => 'Indonesia',
        ];
    }

    public static function saveWithRevision(array $data, int $userId, ?string $note = null): int
    {
        $id = (int) ($data['id'] ?? 0);
        $now = date('Y-m-d H:i:s');
        if ($id > 0) {
            $old = self::find($id);
            if ($old) {
                Revision::snapshot('service', $id, $old, $userId, $note);
            }
            $data['updated_at'] = $now;
            self::updateById($id, $data);
        } else {
            $data['created_at'] = $now;
            $data['updated_at'] = $now;
            $id = self::insert($data);
        }
        Cache::flush();
        return $id;
    }

    public static function forSitemap(): array
    {
        return Database::all("SELECT slug, updated_at FROM services WHERE status = 'published'");
    }
}
