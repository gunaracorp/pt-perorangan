<?php
/**
 * FILE   : app/Models/Menu.php
 * FUNGSI : Menu navigasi (header, footer, mobile) dari database, bukan hard-coded.
 * UNTUK  : Komponen header/footer tema; editor menu di /admin/menu.
 * KENAPA : Menu dikelola dari CMS — perubahan tidak menyentuh file tema.
 * TERKAIT: themes/pt-perorangan/components/header.php & footer.php, admin/MenusController
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Menu extends BaseModel
{
    protected static string $table = 'menus';

    /** Ambil item menu per lokasi (header/footer). Fallback ke default bila kosong. */
    public static function items(string $location): array
    {
        $row = Database::one('SELECT items FROM menus WHERE location = ? LIMIT 1', [$location]);
        if (!$row) {
            return self::defaults($location);
        }
        $items = json_decode((string) $row['items'], true);
        return is_array($items) && $items !== [] ? $items : self::defaults($location);
    }

    /** Simpan item menu per lokasi. */
    public static function saveItems(string $location, array $items): void
    {
        $json = json_encode(array_values($items), JSON_UNESCAPED_UNICODE);
        $exists = Database::one('SELECT id FROM menus WHERE location = ?', [$location]);
        if ($exists) {
            self::updateById((int) $exists['id'], ['items' => $json, 'updated_at' => date('Y-m-d H:i:s')]);
        } else {
            self::insert(['location' => $location, 'items' => $json, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
        }
        Cache::flush();
    }

    /** Menu default (dipakai sebelum admin mengatur apa pun). */
    public static function defaults(string $location): array
    {
        if ($location === 'header') {
            return [
                ['label' => 'Beranda', 'url' => '/'],
                ['label' => 'Layanan', 'url' => '/layanan'],
                ['label' => 'Artikel', 'url' => '/artikel'],
                ['label' => 'FAQ', 'url' => '/faq'],
                ['label' => 'Kontak', 'url' => '/kontak'],
            ];
        }
        return [
            ['label' => 'Layanan', 'url' => '/layanan'],
            ['label' => 'Artikel', 'url' => '/artikel'],
            ['label' => 'FAQ', 'url' => '/faq'],
            ['label' => 'Kebijakan Privasi', 'url' => '/p/kebijakan-privasi'],
            ['label' => 'Syarat Layanan', 'url' => '/p/syarat-layanan'],
        ];
    }
}
