<?php
/**
 * FILE   : app/Models/Category.php
 * FUNGSI : Kategori layanan (pendirian, perizinan, pajak, dsb) — struktur hub → layanan.
 * UNTUK  : /layanan (hub), breadcrumb, internal linking, sitemap.
 * KENAPA : Arsitektur situs yang jelas (hub kategori → layanan → pendukung) membantu
 *          pengguna dan mesin pencari memahami struktur informasi.
 * TERKAIT: app/Models/Service.php, admin/CategoriesController
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class Category extends BaseModel
{
    protected static string $table = 'categories';

    public static function published(): array
    {
        return Database::all("SELECT * FROM categories WHERE status = 'published' ORDER BY sort_order ASC, id ASC");
    }

    public static function findPublished(string $slug): ?array
    {
        return Database::one("SELECT * FROM categories WHERE slug = ? AND status = 'published' LIMIT 1", [$slug]);
    }

    public static function seoOf(array $category): array
    {
        $seo = json_decode((string) ($category['seo'] ?? '{}'), true);
        return is_array($seo) ? $seo : [];
    }
}
