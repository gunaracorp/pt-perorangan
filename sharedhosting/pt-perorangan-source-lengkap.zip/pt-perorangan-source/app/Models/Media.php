<?php
/**
 * FILE   : app/Models/Media.php
 * FUNGSI : Katalog file media yang diunggah (gambar/logo/PDF) + metadata alt & kredit.
 * UNTUK  : Media library admin, pilih gambar di blok, OG image.
 * KENAPA : Metadata (alt text, dimensi, kredit) penting untuk SEO & aksesibilitas.
 * TERKAIT: admin/MediaController (validasi upload), public/media/ (file fisik)
 * AMAN?  : PRIVAT. File fisik di public/media DILINDUNGI .htaccess (tanpa eksekusi PHP).
 */

declare(strict_types=1);

namespace App\Models;

final class Media extends BaseModel
{
    protected static string $table = 'media';

    /** URL publik file media. */
    public static function url(array $media): string
    {
        return '/media/' . rawurlencode((string) $media['filename']);
    }

    /** Cari berdasarkan kata kunci (nama/alt). */
    public static function search(string $q = '', int $limit = 60): array
    {
        if ($q !== '') {
            $like = '%' . $q . '%';
            return self::runWhere("original_name LIKE ? OR alt LIKE ?", [$like, $like], $limit);
        }
        return self::runWhere('1=1', [], $limit);
    }

    /** Cari satu media berdasarkan nama file. */
    public static function findByFilename(string $filename): ?array
    {
        return \App\Core\Database::one('SELECT * FROM media WHERE filename = ?', [$filename]);
    }

    private static function runWhere(string $where, array $params, int $limit): array
    {
        return \App\Core\Database::all(
            'SELECT * FROM media WHERE ' . $where . ' ORDER BY id DESC LIMIT ' . (int) $limit,
            $params
        );
    }
}
