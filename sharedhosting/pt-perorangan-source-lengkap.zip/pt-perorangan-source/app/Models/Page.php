<?php
/**
 * FILE   : app/Models/Page.php
 * FUNGSI : Halaman statis/builder (beranda, tentang, layanan turunan, panduan, dll).
 * UNTUK  : Route /p/{slug}, halaman beranda, dan editor visual di /admin/halaman.
 * KENAPA : Konten disimpan sebagai daftar blok JSON (tervalidasi) → mendukung
 *          page builder + revisi + quality gate + SEO skala besar.
 * TERKAIT: config/blocks.php (schema), app/Models/Revision.php, admin/PagesController
 * AMAN?  : PRIVAT.
 * PEMULA : "Blok" = section halaman (hero, fitur, FAQ...). Susunannya bisa diubah
 *          dari editor visual tanpa menyentuh kode.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Page extends BaseModel
{
    protected static string $table = 'pages';

    public const STATUSES = ['draft', 'review', 'scheduled', 'published', 'needs_update'];

    /** Ambil halaman PUBLISHED berdasarkan slug (untuk route /p/{slug}). */
    public static function findPublished(string $slug): ?array
    {
        return Database::one(
            "SELECT * FROM pages WHERE slug = ? AND status = 'published' LIMIT 1",
            [$slug]
        );
    }

    /** Halaman beranda: slug 'beranda' dipakai khusus. */
    public static function home(): ?array
    {
        return self::findPublished('beranda');
    }

    /** Daftar anak untuk breadcrumb (parent_id). */
    public static function childrenOf(int $parentId): array
    {
        return Database::all(
            "SELECT id, title, slug FROM pages WHERE parent_id = ? AND status = 'published' ORDER BY sort_order ASC",
            [$parentId]
        );
    }

    /** Decode blok JSON menjadi array PHP. */
    public static function blocksOf(array $page): array
    {
        $blocks = json_decode((string) ($page['blocks'] ?? '[]'), true);
        return is_array($blocks) ? $blocks : [];
    }

    /** Decode metadata SEO JSON. */
    public static function seoOf(array $page): array
    {
        $seo = json_decode((string) ($page['seo'] ?? '{}'), true);
        return is_array($seo) ? $seo : [];
    }

    /** Simpan halaman + catat revisi + bersihkan cache. */
    public static function saveWithRevision(array $pageData, int $userId, ?string $note = null): int
    {
        $id = (int) ($pageData['id'] ?? 0);
        $now = date('Y-m-d H:i:s');

        if ($id > 0) {
            $old = self::find($id);
            if ($old) {
                Revision::snapshot('page', $id, $old, $userId, $note);
            }
            $pageData['updated_at'] = $now;
            self::updateById($id, $pageData);
            Cache::flush();
            return $id;
        }
        $pageData['created_at'] = $now;
        $pageData['updated_at'] = $now;
        $newId = self::insert($pageData);
        Cache::flush();
        return $newId;
    }

    /** Sitemap: semua halaman published + canonical + waktu ubah. */
    public static function forSitemap(): array
    {
        return Database::all(
            "SELECT slug, updated_at FROM pages WHERE status = 'published' AND slug NOT LIKE '_preview%' ORDER BY id ASC"
        );
    }

    /** Penanda halaman perlu diperbarui (review kedaluwarsa). */
    public static function markNeedsUpdate(int $id): void
    {
        self::updateById($id, ['status' => 'needs_update']);
        Cache::flush();
    }
}
