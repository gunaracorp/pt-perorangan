<?php
/**
 * FILE   : app/Models/Article.php
 * FUNGSI : Artikel/panduan edukasi (mendukung internal linking & top of funnel SEO).
 * UNTUK  : /artikel dan /artikel/{slug}, blok "artikel terkait" di halaman layanan.
 * KENAPA : Artikel menjawab pertanyaan pencarian edukatif dan menautkan ke layanan.
 * TERKAIT: app/Models/User.php (penulis/reviewer), admin/ArticlesController
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Article extends BaseModel
{
    protected static string $table = 'articles';

    public static function findPublished(string $slug): ?array
    {
        return Database::one("SELECT * FROM articles WHERE slug = ? AND status = 'published' LIMIT 1", [$slug]);
    }

    public static function published(int $limit = 0): array
    {
        $sql = "SELECT a.*, u.name AS author_name FROM articles a LEFT JOIN users u ON u.id = a.author_id
                WHERE a.status = 'published' ORDER BY a.published_at DESC, a.id DESC" . ($limit > 0 ? ' LIMIT ' . (int) $limit : '');
        return Database::all($sql);
    }

    public static function blocksOf(array $article): array
    {
        $b = json_decode((string) ($article['blocks'] ?? '[]'), true);
        return is_array($b) ? $b : [];
    }

    public static function seoOf(array $article): array
    {
        $seo = json_decode((string) ($article['seo'] ?? '{}'), true);
        return is_array($seo) ? $seo : [];
    }

    public static function saveWithRevision(array $data, int $userId, ?string $note = null): int
    {
        $id = (int) ($data['id'] ?? 0);
        $now = date('Y-m-d H:i:s');
        if ($id > 0) {
            $old = self::find($id);
            if ($old) {
                Revision::snapshot('article', $id, $old, $userId, $note);
            }
            $data['updated_at'] = $now;
            self::updateById($id, $data);
        } else {
            $data['created_at'] = $now;
            $data['updated_at'] = $now;
            $id = self::insert($data);
        }
        Cache::flush();
        return $id;
    }

    public static function forSitemap(): array
    {
        return Database::all("SELECT slug, updated_at FROM articles WHERE status = 'published'");
    }
}
