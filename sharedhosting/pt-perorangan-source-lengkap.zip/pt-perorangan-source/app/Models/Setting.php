<?php
/**
 * FILE   : app/Models/Setting.php
 * FUNGSI : Penyimpanan pengaturan situs (identitas, kontak, customizer tema, SEO global).
 * UNTUK  : Theme::siteData(), Theme::cssVariables(), halaman /admin/pengaturan & /admin/tema.
 * KENAPA : Semua opsi tampilan/konten rutin diatur dari dashboard, tanpa edit file.
 * TERKAIT: app/Core/Theme.php, app/Core/Cache.php
 * AMAN?  : PRIVAT.
 * PEMULA : "Group" = kelompok pengaturan: site, theme, seo, analytics.
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Cache;
use App\Core\Database;

final class Setting extends BaseModel
{
    protected static string $table = 'settings';

    /** Ambil semua pengaturan dalam satu kelompok → [key => value]. */
    public static function allGrouped(string $group): array
    {
        $rows = Database::all('SELECT skey, svalue FROM settings WHERE sgroup = ?', [$group]);
        $out = [];
        foreach ($rows as $row) {
            $out[$row['skey']] = $row['svalue'];
        }
        return $out;
    }

    /** Simpan (upsert) satu pengaturan. */
    public static function put(string $group, string $key, string $value): void
    {
        $driver = \App\Core\Database::isSqlite();
        if ($driver) {
            Database::run(
                'INSERT INTO settings (sgroup, skey, svalue) VALUES (?, ?, ?)
                 ON CONFLICT(sgroup, skey) DO UPDATE SET svalue = excluded.svalue',
                [$group, $key, $value]
            );
        } else {
            Database::run(
                'INSERT INTO settings (sgroup, skey, svalue) VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)',
                [$group, $key, $value]
            );
        }
        Cache::flush();
    }

    /** Simpan banyak pengaturan sekaligus (dari form customizer). */
    public static function putMany(string $group, array $keyValue): void
    {
        foreach ($keyValue as $key => $value) {
            self::put($group, (string) $key, (string) $value);
        }
    }
}
