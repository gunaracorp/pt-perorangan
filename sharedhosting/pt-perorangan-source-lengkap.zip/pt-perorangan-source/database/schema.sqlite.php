<?php
/**
 * FILE   : database/schema.sqlite.php
 * FUNGSI : Skema SQLite (perintah CREATE TABLE) untuk pengujian lokal tanpa MySQL.
 * UNTUK  : Dipanggil installer bila config database.driver = sqlite.
 * KENAPA : Pemula bisa mencoba aplikasi di komputer lokal sebelum deploy cPanel.
 * AMAN?  : PRIVAT.
 */

declare(strict_types=1);

return [
    'users' => 'CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT "editor",
        last_login_at TEXT NULL,
        created_at TEXT NOT NULL
    )',
    'settings' => 'CREATE TABLE IF NOT EXISTS settings (
        sgroup TEXT NOT NULL,
        skey TEXT NOT NULL,
        svalue TEXT NOT NULL,
        PRIMARY KEY (sgroup, skey)
    )',
    'pages' => 'CREATE TABLE IF NOT EXISTS pages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        excerpt TEXT NULL,
        blocks TEXT NULL,
        seo TEXT NULL,
        status TEXT NOT NULL DEFAULT "draft",
        published_at TEXT NULL,
        sort_order INTEGER NOT NULL DEFAULT 100,
        updated_by INTEGER NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )',
    'categories' => 'CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        description TEXT NULL,
        seo TEXT NULL,
        status TEXT NOT NULL DEFAULT "published",
        sort_order INTEGER NOT NULL DEFAULT 10,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )',
    'services' => 'CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        excerpt TEXT NULL,
        blocks TEXT NULL,
        seo TEXT NULL,
        facts TEXT NULL,
        category_id INTEGER NULL,
        featured INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT "draft",
        published_at TEXT NULL,
        sort_order INTEGER NOT NULL DEFAULT 100,
        updated_by INTEGER NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
    )',
    'articles' => 'CREATE TABLE IF NOT EXISTS articles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        excerpt TEXT NULL,
        blocks TEXT NULL,
        seo TEXT NULL,
        author_id INTEGER NULL,
        reviewed_by INTEGER NULL,
        status TEXT NOT NULL DEFAULT "draft",
        published_at TEXT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
    )',
    'faqs' => 'CREATE TABLE IF NOT EXISTS faqs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        service_id INTEGER NULL,
        status TEXT NOT NULL DEFAULT "published",
        sort_order INTEGER NOT NULL DEFAULT 10,
        created_at TEXT NOT NULL,
        FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
    )',
    'menus' => 'CREATE TABLE IF NOT EXISTS menus (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        location TEXT NOT NULL UNIQUE,
        items TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        created_at TEXT NOT NULL
    )',
    'media' => 'CREATE TABLE IF NOT EXISTS media (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        original_name TEXT NOT NULL,
        mime TEXT NOT NULL,
        size INTEGER NOT NULL,
        width INTEGER NULL,
        height INTEGER NULL,
        alt TEXT NULL,
        credit TEXT NULL,
        created_by INTEGER NULL,
        created_at TEXT NOT NULL
    )',
    'redirects' => 'CREATE TABLE IF NOT EXISTS redirects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_path TEXT NOT NULL UNIQUE,
        target TEXT NULL,
        status INTEGER NOT NULL DEFAULT 301,
        hits INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NULL
    )',
    'revisions' => 'CREATE TABLE IF NOT EXISTS revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type TEXT NOT NULL,
        entity_id INTEGER NOT NULL,
        snapshot TEXT NOT NULL,
        note TEXT NULL,
        created_by INTEGER NULL,
        created_at TEXT NOT NULL
    )',
    'contact_messages' => 'CREATE TABLE IF NOT EXISTS contact_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NULL,
        subject TEXT NULL,
        message TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT "new",
        ip_hash TEXT NULL,
        created_at TEXT NOT NULL
    )',
];
