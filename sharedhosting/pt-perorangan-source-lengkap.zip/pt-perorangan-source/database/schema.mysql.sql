-- =============================================================
-- FILE   : database/schema.mysql.sql
-- FUNGSI : Skema database MySQL 5.7+/MariaDB untuk cPanel (charset utf8mb4).
-- UNTUK  : Diimpor lewat phpMyAdmin ATAU dibuat otomatis oleh public/install.php.
-- KENAPA : Struktur data jelas & terdokumentasi — dasar semua fitur CMS/SEO.
-- AMAN?  : PRIVAT. Tidak berisi data pengguna.
-- PEMULA : Tabel = "kumpulan data" seperti spreadsheet; kolom = atributnya.
-- JANGAN : Mengubah nama tabel/kolom tanpa mengubah Model terkait.
-- =============================================================

SET NAMES utf8mb4;

-- 1. Pengguna admin (password selalu hash bcrypt/argon2)
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          VARCHAR(20)  NOT NULL DEFAULT 'editor',
  last_login_at DATETIME     NULL,
  created_at    DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Pengaturan situs/tema (key-value per grup)
CREATE TABLE IF NOT EXISTS settings (
  sgroup VARCHAR(30)  NOT NULL,
  skey   VARCHAR(60)  NOT NULL,
  svalue TEXT         NOT NULL,
  PRIMARY KEY (sgroup, skey)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Halaman builder (beranda, tentang, panduan, halaman intent...)
CREATE TABLE IF NOT EXISTS pages (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title        VARCHAR(150) NOT NULL,
  slug         VARCHAR(150) NOT NULL,
  excerpt      VARCHAR(300) NULL,
  blocks       JSON         NULL,   -- daftar blok tervalidasi (config/blocks.php)
  seo          JSON         NULL,   -- title/description/robots/sources
  status       VARCHAR(20)  NOT NULL DEFAULT 'draft',
  published_at DATETIME     NULL,
  sort_order   INT          NOT NULL DEFAULT 100,
  updated_by   INT UNSIGNED NULL,
  created_at   DATETIME     NOT NULL,
  updated_at   DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_pages_slug (slug),
  KEY ix_pages_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Kategori layanan (struktur hub → layanan)
CREATE TABLE IF NOT EXISTS categories (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(100) NOT NULL,
  slug        VARCHAR(100) NOT NULL,
  description VARCHAR(300) NULL,
  seo         JSON         NULL,
  status      VARCHAR(20)  NOT NULL DEFAULT 'published',
  sort_order  INT          NOT NULL DEFAULT 10,
  created_at  DATETIME     NOT NULL,
  updated_at  DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categories_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Layanan (inti SEO intent; facts = fakta terstruktur)
CREATE TABLE IF NOT EXISTS services (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title        VARCHAR(150) NOT NULL,
  slug         VARCHAR(150) NOT NULL,
  excerpt      VARCHAR(300) NULL,
  blocks       JSON         NULL,
  seo          JSON         NULL,
  facts        JSON         NULL,  -- official_fee, service_fee, est_time, requirements, region
  category_id  INT UNSIGNED NULL,
  featured     TINYINT(1)   NOT NULL DEFAULT 0,
  status       VARCHAR(20)  NOT NULL DEFAULT 'draft',
  published_at DATETIME     NULL,
  sort_order   INT          NOT NULL DEFAULT 100,
  updated_by   INT UNSIGNED NULL,
  created_at   DATETIME     NOT NULL,
  updated_at   DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_services_slug (slug),
  KEY ix_services_status (status),
  KEY ix_services_category (category_id),
  CONSTRAINT fk_services_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Artikel (panduan edukasi; top of funnel SEO)
CREATE TABLE IF NOT EXISTS articles (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title        VARCHAR(150) NOT NULL,
  slug         VARCHAR(150) NOT NULL,
  excerpt      VARCHAR(300) NULL,
  blocks       JSON         NULL,
  seo          JSON         NULL,
  author_id    INT UNSIGNED NULL,
  reviewed_by  INT UNSIGNED NULL,
  status       VARCHAR(20)  NOT NULL DEFAULT 'draft',
  published_at DATETIME     NULL,
  created_at   DATETIME     NOT NULL,
  updated_at   DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_articles_slug (slug),
  KEY ix_articles_status (status),
  CONSTRAINT fk_articles_author FOREIGN KEY (author_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. FAQ (halaman FAQ + blok FAQ + JSON-LD FAQPage)
CREATE TABLE IF NOT EXISTS faqs (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  question   VARCHAR(300) NOT NULL,
  answer     TEXT         NOT NULL,
  service_id INT UNSIGNED NULL,
  status     VARCHAR(20)  NOT NULL DEFAULT 'published',
  sort_order INT          NOT NULL DEFAULT 10,
  created_at DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY ix_faqs_service (service_id),
  CONSTRAINT fk_faqs_service FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Menu navigasi (header/footer)
CREATE TABLE IF NOT EXISTS menus (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  location   VARCHAR(30)  NOT NULL,
  items      JSON         NOT NULL,
  updated_at DATETIME     NOT NULL,
  created_at DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_menus_location (location)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Media library (metadata file terunggah)
CREATE TABLE IF NOT EXISTS media (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  filename      VARCHAR(150) NOT NULL,   -- nama acak di server
  original_name VARCHAR(200) NOT NULL,
  mime          VARCHAR(80)  NOT NULL,
  size          INT UNSIGNED NOT NULL,
  width         INT UNSIGNED NULL,
  height        INT UNSIGNED NULL,
  alt           VARCHAR(200) NULL,
  credit        VARCHAR(200) NULL,
  created_by    INT UNSIGNED NULL,
  created_at    DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY ix_media_filename (filename)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Redirect 301/302/410 (kelola URL lama saat migrasi)
CREATE TABLE IF NOT EXISTS redirects (
  id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  from_path VARCHAR(300) NOT NULL,
  target    VARCHAR(300) NULL,
  status    SMALLINT     NOT NULL DEFAULT 301,
  hits      INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME    NOT NULL,
  updated_at DATETIME    NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_redirects_from (from_path(190))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Revisi konten (rollback aman; maks 20 per entitas di-prune aplikasi)
CREATE TABLE IF NOT EXISTS revisions (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  entity_type VARCHAR(20)  NOT NULL,   -- page | service | article
  entity_id   INT UNSIGNED NOT NULL,
  snapshot    JSON         NOT NULL,
  note        VARCHAR(200) NULL,
  created_by  INT UNSIGNED NULL,
  created_at  DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY ix_revisions_entity (entity_type, entity_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Pesan formulir kontak (tanpa server email — andal di shared hosting)
CREATE TABLE IF NOT EXISTS contact_messages (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL,
  phone      VARCHAR(30)  NULL,
  subject    VARCHAR(150) NULL,
  message    TEXT         NOT NULL,
  status     VARCHAR(20)  NOT NULL DEFAULT 'new',
  ip_hash    CHAR(64)     NULL,   -- privasi: hash, bukan IP mentah
  created_at DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY ix_messages_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
