<?php
/**
 * FILE   : tools/setup-local.php
 * FUNGSI : Menyiapkan lingkungan UJI LOKAL (SQLite): buat config, tabel, seed konten,
 *          dan akun admin demo. HANYA untuk pengujian — bukan jalur instalasi produksi
 *          (produksi memakai public/install.php via browser).
 * AMAN?  : PRIVAT. tools/ dilindungi .htaccess root.
 */

declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
require APP_ROOT . '/app/Core/bootstrap.php';

use App\Core\Database;
use App\Models\User;

$force = in_array('--force', $argv, true);
$configFile = CONFIG_DIR . '/config.php';

if (is_file($configFile) && !$force) {
    echo "config.php sudah ada (gunakan --force untuk menimpa)\n";
    exit(0);
}

$config = [
    'environment' => 'development',
    'base_url' => 'http://127.0.0.1:8099',
    'database' => [
        'driver' => 'sqlite',
        'host' => '', 'port' => 0, 'database' => '', 'username' => '', 'password' => '',
        'charset' => 'utf8mb4',
        'sqlite_path' => STORAGE_DIR . '/database.sqlite',
    ],
    'security' => [
        'app_key' => bin2hex(random_bytes(32)),
        'login_max_attempts' => 5,
        'login_decay_minutes' => 15,
        'session_lifetime_minutes' => 120,
    ],
    'uploads' => ['max_size_mb' => 8, 'allowed' => ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'pdf']],
    'features' => ['contact_store' => true, 'cache_enabled' => true, 'debug' => true],
    'theme' => 'pt-perorangan',
];
file_put_contents($configFile, "<?php\nreturn " . var_export($config, true) . ";\n");
echo "✓ config.php (sqlite, dev) ditulis\n";

// Hapus database lama bila force
if ($force && is_file(STORAGE_DIR . '/database.sqlite')) {
    @unlink(STORAGE_DIR . '/database.sqlite');
    echo "✓ database lama dihapus\n";
}

// Buat tabel
$schema = require APP_ROOT . '/database/schema.sqlite.php';
foreach ($schema as $ddl) {
    Database::run($ddl);
}
echo "✓ tabel dibuat (" . count($schema) . " tabel)\n";

// Seed konten (logika sama seperti installer)
try {
    seedLocal($force);
} catch (Throwable $e) {
    fwrite(STDERR, "GAGAL SEED: " . get_class($e) . ": " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n");
    exit(1);
}

function seedLocal(bool $force): void
{
    $now = date('Y-m-d H:i:s');
    $adminId = User::create('Admin Demo', 'admin@demo.local', 'SandiDemoPanjang123!', 'owner');
    echo "✓ admin demo: admin@demo.local / SandiDemoPanjang123!\n";
    $read = static function (string $name): array {
        $f = CONTENT_DIR . '/' . $name;
        return is_file($f) ? (json_decode((string) file_get_contents($f), true) ?: []) : [];
    };

    $catIds = [];
foreach ($read('categories.json') as $c) {
    $catIds[$c['slug']] = \App\Models\Category::insert([
        'name' => $c['name'], 'slug' => $c['slug'],
        'description' => (string) ($c['description'] ?? ''),
        'seo' => json_encode(['title' => $c['name']], JSON_UNESCAPED_UNICODE),
        'status' => 'published', 'sort_order' => (int) ($c['sort_order'] ?? 10),
        'created_at' => $now, 'updated_at' => $now,
    ]);
}
foreach ($read('services.json') as $s) {
    \App\Models\Service::insert([
        'title' => $s['title'], 'slug' => $s['slug'], 'excerpt' => (string) ($s['excerpt'] ?? ''),
        'blocks' => json_encode($s['blocks'] ?? [], JSON_UNESCAPED_UNICODE),
        'seo' => json_encode($s['seo'] ?? [], JSON_UNESCAPED_UNICODE),
        'facts' => json_encode($s['facts'] ?? [], JSON_UNESCAPED_UNICODE),
        'category_id' => $catIds[(string) ($s['category'] ?? '')] ?? null,
        'featured' => (int) ($s['featured'] ?? 0), 'status' => 'published', 'published_at' => $now,
        'sort_order' => (int) ($s['sort_order'] ?? 100), 'updated_by' => $adminId,
        'created_at' => $now, 'updated_at' => $now,
    ]);
}
foreach ($read('pages.json') as $p) {
    \App\Models\Page::insert([
        'title' => $p['title'], 'slug' => $p['slug'], 'excerpt' => (string) ($p['excerpt'] ?? ''),
        'blocks' => json_encode($p['blocks'] ?? [], JSON_UNESCAPED_UNICODE),
        'seo' => json_encode($p['seo'] ?? [], JSON_UNESCAPED_UNICODE),
        'status' => 'published', 'published_at' => $now,
        'updated_by' => $adminId, 'created_at' => $now, 'updated_at' => $now,
    ]);
}
foreach ($read('faq.json') as $f) {
    \App\Models\Faq::insert([
        'question' => $f['question'], 'answer' => $f['answer'],
        'status' => 'published', 'sort_order' => (int) ($f['sort_order'] ?? 10), 'created_at' => $now,
    ]);
}
$menus = $read('menus.json');
if (isset($menus['header'])) { \App\Models\Menu::saveItems('header', $menus['header']); }
if (isset($menus['footer'])) { \App\Models\Menu::saveItems('footer', $menus['footer']); }
foreach ($read('settings.json') as $group => $pairs) {
    if (in_array($group, ['FUNGSI', 'AMAN'], true)) continue;
    \App\Models\Setting::putMany((string) $group, (array) $pairs);
}
} // end seedLocal
echo "✓ konten seed dimuat\n";
echo "SELESAI. Jalankan: cd public && /home/z/my-project/tools/php -S 127.0.0.1:8099 router-dev.php\n";
