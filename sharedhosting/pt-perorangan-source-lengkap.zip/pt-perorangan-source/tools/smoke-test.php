<?php
/**
 * FILE   : tools/smoke-test.php
 * FUNGSI : Tes integrasi end-to-end (harus dijalankan saat server dev berjalan):
 *          login admin (CSRF), dasbor, editor halaman, form kontak + honeypot,
 *          redirect 301, sitemap XML valid, JSON-LD, noindex pencarian.
 * AMAN?  : PRIVAT (alat uji lokal saja).
 */

declare(strict_types=1);

$base = $argv[1] ?? 'http://127.0.0.1:8099';
$jar = '/tmp/ptper-cookies.txt';
@unlink($jar);

$pass = 0;
$fail = 0;
function t(string $name, bool $ok, string $detail = ''): void {
    global $pass, $fail;
    if ($ok) { $pass++; echo "  ✓ $name\n"; }
    else { $fail++; echo "  ✕ $name  $detail\n"; }
}

function http(string $url, string $method = 'GET', array $post = []): array {
    global $base, $jar;
    $ch = curl_init($base . $url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEJAR => $jar,
        CURLOPT_COOKIEFILE => $jar,
        CURLOPT_HEADER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_TIMEOUT => 15,
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    }
    $raw = (string) curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hsize = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    return [$code, substr($raw, 0, $hsize), substr($raw, $hsize)];
}

echo "== 1. Halaman login + CSRF ==\n";
[$code, , $body] = http('/admin/login');
preg_match('~name="_csrf" value="([^"]+)"~', $body, $m);
$csrf = $m[1] ?? '';
t('GET /admin/login = 200', $code === 200);
t('Token CSRF tersedia', $csrf !== '');

echo "== 2. Login salah ditolak ==\n";
[$code, $hdr] = http('/admin/login', 'POST', ['_csrf' => $csrf, 'email' => 'admin@demo.local', 'password' => 'SalahTotal123!']);
t('Login salah → redirect balik + flash (302)', $code === 302);

echo "== 3. Login benar ==\n";
[$code, $hdr] = http('/admin/login', 'POST', ['_csrf' => $csrf, 'email' => 'admin@demo.local', 'password' => 'SandiDemoPanjang123!']);
t('Login benar → redirect /admin', $code === 302 && (str_contains($hdr, 'Location: /admin') || str_contains($hdr, 'Location: /admin\r')));
[$code, , $body] = http('/admin');
t('Dasbor = 200 setelah login', $code === 200);
t('Dasbor menampilkan statistik', str_contains($body, 'Dasbor'));

echo "== 4. Akses admin tanpa login ditolak ==\n";
@unlink('/tmp/ptper-cookies2.txt');
$ch = curl_init($base . '/admin/halaman');
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => '/tmp/ptper-cookies2.txt', CURLOPT_COOKIEFILE => '/tmp/ptper-cookies2.txt']);
curl_exec($ch);
$code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
t('GET /admin/halaman tanpa login → 302 ke login', $code === 302);

echo "== 5. Editor halaman (membuat) ==\n";
[$code, , $body] = http('/admin/halaman/baru');
t('GET /admin/halaman/baru = 200', $code === 200);
t('Form editor berisi blockDefsJson', str_contains($body, 'blockDefsJson'));
preg_match('~name="_csrf" value="([^"]+)"~', $body, $m2);
$csrf2 = $m2[1] ?? '';

$blocks = json_encode([
    ['type' => 'hero', 'hidden' => false, 'data' => ['badge' => 'Uji', 'title' => 'Halaman Uji Quality Gate', 'subtitle' => 'Subjudul halaman uji yang cukup panjang untuk pratinjau.', 'cta_label' => 'Mulai', 'cta_url' => '/kontak', 'align' => 'center']],
    ['type' => 'richtext', 'hidden' => false, 'data' => ['html' => '<p>' . str_repeat('Konten uji bermakna untuk memenuhi gerbang kualitas halaman minimum tiga ratus karakter. ', 7) . '</p>']],
], JSON_UNESCAPED_UNICODE);

echo "== 6. Terbitkan tanpa SEO → harus DITAHAN quality gate ==\n";
[$code, $hdr, $body] = http('/admin/halaman/baru', 'POST', [
    '_csrf' => $csrf2, 'title' => 'Halaman Uji Integrasi Otomatis',
    'slug' => 'uji-integrasi', 'excerpt' => 'Uji coba',
    'blocks' => $blocks,
    'seo_title' => '', 'seo_description' => '', 'seo_robots' => 'index, follow', 'seo_sources' => '',
    'status' => 'published',
]);
t('Ditahan gate → redirect ke edit (bukan tayang)', $code === 302 && str_contains($hdr, '/edit'));
[$code, , $body] = http('/admin/halaman');
t('Halaman muncul sebagai review (bukan published)', $code === 200 && str_contains($body, 'uji-integrasi'));

echo "== 7. Lengkapi SEO → terbit ==\n";
[$code, , $body] = http('/admin/halaman');
preg_match('~/admin/halaman/(\d+)/edit~', $body, $idm);
$pageId = (int) ($idm[1] ?? 0);
t('ID halaman ditemukan', $pageId > 0);
[$code, $hdr] = http("/admin/halaman/$pageId/simpan", 'POST', [
    '_csrf' => $csrf2, 'title' => 'Halaman Uji Integrasi Otomatis',
    'slug' => 'uji-integrasi', 'excerpt' => 'Uji coba',
    'blocks' => $blocks,
    'seo_title' => 'Halaman Uji Integrasi Otomatis — PT Perorangan',
    'seo_description' => 'Deskripsi meta yang cukup panjang untuk lolos gerbang kualitas dan menjelaskan nilai halaman pengujian integrasi otomatis ini dengan baik sekali.',
    'seo_robots' => 'index, follow', 'seo_sources' => '',
    'status' => 'published',
]);
t('Publish sukses (302 tanpa error)', $code === 302);

echo "== 8. Halaman tayang publik + sitemap ==\n";
[$code, , $body] = http('/p/uji-integrasi');
t('GET /p/uji-integrasi = 200', $code === 200);
[$code, , $body] = http('/sitemap-pages.xml');
t('Sitemap berisi URL baru', $code === 200 && str_contains($body, '/p/uji-integrasi'));
[$code, , $body] = http('/p/uji-integrasi');
t('Canonical self-referencing di HTML', str_contains($body, 'rel="canonical"') && str_contains($body, '/p/uji-integrasi'));

echo "== 9. Redirect 301 + 410 ==\n";
[$code, , $body] = http('/admin/seo');
preg_match('~name="_csrf" value="([^"]+)"~', $body, $m3);
$csrf3 = $m3[1] ?? '';
[$code] = http('/admin/seo/redirect', 'POST', ['_csrf' => $csrf3, 'from_path' => '/url-lama-uji', 'target' => '/p/uji-integrasi', 'status' => '301']);
[$code, $hdr] = http('/url-lama-uji');
t('Redirect 301 bekerja', $code === 301 && str_contains($hdr, '/p/uji-integrasi'));
[$code] = http('/admin/seo/redirect', 'POST', ['_csrf' => $csrf3, 'from_path' => '/url-dihapus-uji', 'target' => '', 'status' => '410']);
[$code] = http('/url-dihapus-uji');
t('Redirect 410 → status 410', $code === 410);

echo "== 10. Formulir kontak (valid + honeypot) ==\n";
[$code, , $body] = http('/kontak');
preg_match('~name="_csrf" value="([^"]+)"~', $body, $m4);
$csrf4 = $m4[1] ?? '';
[$code] = http('/kontak', 'POST', [
    '_csrf' => $csrf4, 'website' => '', 'name' => 'Penguji Otomatis',
    'email' => 'uji@contoh.id', 'phone' => '0812', 'subject' => 'Uji', 'message' => 'Pesan uji integrasi otomatis lebih dari sepuluh karakter.',
]);
[$code, , $body] = http('/kontak');
t('Pesan tersimpan → flash sukses', str_contains($body, 'Terima kasih'));
[$code, , $body] = http('/admin/pesan');
t('Pesan muncul di dashboard admin', $code === 200 && str_contains($body, 'Penguji Otomatis'));

echo "== 11. Cari = noindex ==\n";
[$code, $hdr] = http('/cari?q=pt');
t('X-Robots/noindex pada pencarian', $code === 200 && (str_contains($hdr, 'noindex')));

echo "== 12. JSON-LD valid di layanan ==\n";
[$code, , $body] = http('/layanan/pendirian-pt-perorangan');
t('JSON-LD Service ada', str_contains($body, '"@type":"Service"'));
t('JSON-LD Breadcrumb ada', str_contains($body, '"@type":"BreadcrumbList"'));
t('Fakta biaya resmi tampil', str_contains($body, 'Rp50.000'));
t('Sumber resmi tampil', str_contains($body, 'layanan.ahu.go.id'));

echo "== 13. Logout & halaman 404 ==\n";
[$code] = http('/admin/logout');
t('Logout redirect', $code === 302);
[$code] = http('/halaman-tidak-ada');
t('404 asli (bukan 200)', $code === 404);

echo "\n==============================\n";
echo "HASIL: $pass lulus, $fail gagal\n";
exit($fail === 0 ? 0 : 1);
